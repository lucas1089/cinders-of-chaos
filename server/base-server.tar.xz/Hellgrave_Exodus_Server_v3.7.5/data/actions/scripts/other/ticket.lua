function onUse(cid, item, fromPosition, itemEx, toPosition)

if getPlayerStorageValue(cid,21026) == 500 then
	PlayerSendTextMessage(cid,18,"Congratulations! You earned the achievement \"Jinx\".")
	doPlayerAddAchievement(cid, 26)
end


local rand = math.random(1, 15)
local lotteryid = 5957

if item.itemid == lotteryid then
	if rand == 1 then
		doCreatureSay(cid, "You have a winning lottery ticket!", TALKTYPE_ORANGE_1)
		doTransformItem(item.uid, item.itemid + 1)
		PlayerSetStorageValue(cid, 21026, getPlayerStorageValue(cid, 21026) + 1)
		SendMagicEffect(fromPosition,12)
	else
		doCreatureSay(cid, "Sorry, This is not a winning lottery ticket.", TALKTYPE_ORANGE_1)
		doTransformItem(item.uid, item.itemid - 1)
		PlayerSetStorageValue(cid, 21026, getPlayerStorageValue(cid, 21026) + 1)
	end
end
return TRUE
end