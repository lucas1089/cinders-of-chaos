import sys, time; sys.path.insert(0,'/home/user/project-chaos/client/tools/sprites/cnn')
import numpy as np, torch, cnnlib as C
from PIL import Image
D=np.load('data/items.npz'); X=D['X'][:2000]
rng=np.random.default_rng(0)
t=time.time(); negs=[C.make_negative(X[i],rng,other=X[i+1],kind=i%8)[0] for i in range(800)]; print('neg/s', 800/(time.time()-t))
rows=[(C.NEG_TYPES[k],[X[i] for i in range(k*8,k*8+8)]) for k in range(8)]+[('neg '+C.NEG_TYPES[k],[negs[i] for i in range(800) if i%8==k][:8]) for k in range(8)]
C.slot_rows(rows,zoom=2).save('smoke_negs.png')
m=C.Critic(); print('critic params',sum(p.numel() for p in m.parameters()))
x=C.to_tensor(X[:256]); t=time.time(); k,r=m(x); (k.sum()+r.sum()).backward(); print('critic step 256', time.time()-t)
u=C.UNet(); print('unet params',sum(p.numel() for p in u.parameters()))
xb=C.to_diff(X[:64]); t=time.time()
for _ in range(3):
  e=u(xb, torch.randint(0,1000,(64,)), torch.randint(0,15,(64,)), torch.randint(0,11,(64,))); e.pow(2).mean().backward()
print('unet step 64', (time.time()-t)/3)
print([C.MATERIALS[C.material_code(X[i])] for i in range(20)])
