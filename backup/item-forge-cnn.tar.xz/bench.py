import sys, time; sys.path.insert(0,'/home/user/project-chaos/client/tools/sprites/cnn')
import torch, cnnlib as C
torch.set_num_threads(4)
for ch,mult,bs in [(32,(1,2,2),64),(48,(1,2,2),64),(32,(1,2,4),64),(64,(1,2,2),64)]:
  u=C.UNet(ch,mult); opt=torch.optim.Adam(u.parameters())
  xb=torch.randn(bs,4,32,32)
  for i in range(5):
    if i==2: t=time.time()
    e=u(xb, torch.randint(0,1000,(bs,)), torch.randint(0,15,(bs,)), torch.randint(0,11,(bs,))); l=e.pow(2).mean(); opt.zero_grad(); l.backward(); opt.step()
  print(ch,mult,bs,sum(p.numel() for p in u.parameters()), (time.time()-t)/3, flush=True)
