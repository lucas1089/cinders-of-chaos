import sys; sys.path.insert(0,'/home/user/project-chaos/client/tools/sprites/cnn')
import numpy as np, torch, cnnlib as C
torch.set_num_threads(1)
m=C.UNet(32,(1,2,4)); m.load_state_dict(torch.load('weights/gen_ema.pt')); m.eval()
diff=C.Diffusion()
ab=diff.ab
@torch.no_grad()
def samp(k,mm,steps,guide,fix,g):
    n=len(k); ts=torch.linspace(999,0,steps).long(); x=torch.randn(n,4,32,32,generator=g)
    kn=torch.full_like(k,C.NK); mn=torch.full_like(mm,C.NM)
    for i,t in enumerate(ts):
        tt=torch.full((n,),int(t)); e=m(torch.cat([x,x]),torch.cat([tt,tt]),torch.cat([k,kn]),torch.cat([mm,mn])); ec,eu=e.chunk(2); eps=eu+guide*(ec-eu)
        a=ab[t]; x0=((x-(1-a).sqrt()*eps)/a.sqrt()).clamp(-1,1)
        if fix: eps=(x-a.sqrt()*x0)/(1-a).sqrt()
        if i+1<len(ts): an=ab[ts[i+1]]; x=an.sqrt()*x0+(1-an).sqrt()*eps
        else: x=x0
    return x
k=torch.tensor([0]*6+[7]*6+[8]*6); mm=torch.tensor([0,1,2,5,6,8]*3)
rows=[]
for fix in (0,1):
  for steps,guide in ((40,2.0),(100,1.0),(100,3.0)):
    x=samp(k,mm,steps,guide,fix,torch.Generator().manual_seed(1))
    rows.append((f'fix{fix} s{steps} g{guide}',[C.binarize(a) for a in C.from_diff(x)]))
C.slot_rows(rows,zoom=2,label_w=120).save('dbg_fix.png')
