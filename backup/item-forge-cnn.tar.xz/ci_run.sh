set -u
cd /home/user/project-chaos
r(){ echo "== $*"; ( eval "$@" ) >/tmp/claude-0/-home-user/a624c66a-2fef-5352-b9d8-48bc1ea53968/scratchpad/cnn/ci_last.txt 2>&1 && echo OK || { echo FAIL; tail -15 /tmp/claude-0/-home-user/a624c66a-2fef-5352-b9d8-48bc1ea53968/scratchpad/cnn/ci_last.txt; }; }
r 'cd server && for t in tests/*_test.lua; do luajit "$t" >/dev/null && lua5.3 "$t" >/dev/null || { echo "$t"; exit 1; }; done'
r 'for t in client/overlay/modules/*/*_test.lua; do luajit "$t" >/dev/null && lua5.3 "$t" >/dev/null || { echo "$t"; exit 1; }; done'
r python3 -I tools/ci/check_modules.py
r python3 -I tools/ci/check_content.py
r python3 -I tools/ci/check_names.py
r python3 client/tools/make_fonts_test.py
r python3 -I client/tools/check_shaders.py
r 'python3 client/tools/gen_spell_data.py && git diff --stat -- client/overlay/modules/game_chaosspells/spelldata.lua'
r 'cd server && python3 -I tools/gen_unique_specs.py && git diff --stat -- data/lib/chaos_unique_specs.lua'
r 'cd server && luajit tools/gen_codex_data.lua && git diff --stat -- ../client/overlay/modules/game_codex/codex_data.lua'
r 'cd server && lua5.3 tools/gen_codex_data.lua --check'
r 'for f in client/tools/sprites/cnn/*.py; do python3 -m py_compile "$f" || exit 1; done'
r "cd server && luajit tools/gen_wiki_data.lua >/dev/null && lua5.3 tools/gen_wiki_data.lua --check"
