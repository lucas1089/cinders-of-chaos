import sys; sys.path.insert(0,'/home/user/project-chaos/client/tools/sprites/cnn')
import numpy as np, cnnlib as C
S='/tmp/claude-0/-home-user/a624c66a-2fef-5352-b9d8-48bc1ea53968/scratchpad/sets_v2/raw_full/'
ims=[C.load_png(S+f'sunsworn_sword/cand_{i:02d}.png') for i in range(8)]
C.slot_rows([('in',ims),('clean',[C.clean_pixel_art(x) for x in ims],[str(i) for i in range(8)])],zoom=3).save('t_clean.png')
