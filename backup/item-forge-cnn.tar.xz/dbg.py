import sys; sys.path.insert(0,'/home/user/project-chaos/client/tools/sprites/cnn')
import numpy as np, torch, cnnlib as C
torch.set_num_threads(1)
st=torch.load('weights/gen_last.pt'); print('step',st['step'])
D=np.load('data/items.npz'); X=np.stack([C.binarize(x) for x in D['X'][:16]])
diff=C.Diffusion()
for name in ('model','ema'):
  m=C.UNet(32,(1,2,4)); m.load_state_dict(st[name]); m.eval()
  x0=C.to_diff(X)
  with torch.no_grad():
    for t in (50,300,700):
      tt=torch.full((16,),t); e=torch.randn_like(x0); xt=diff.noise(x0,tt,e)
      p=m(xt,tt,torch.full((16,),C.NK),torch.full((16,),C.NM))
      print(name,t,'eps mse',float(((p-e)**2).mean()))
  g=torch.Generator().manual_seed(1)
  x=diff.sample(m,torch.tensor([0]*6+[8]*6),torch.tensor([0,1,2,5,6,8]*2),steps=40,guide=1.0,gen=g)
  C.slot_rows([(name,[C.binarize(a) for a in C.from_diff(x)])],zoom=3).save(f'dbg_{name}.png')
