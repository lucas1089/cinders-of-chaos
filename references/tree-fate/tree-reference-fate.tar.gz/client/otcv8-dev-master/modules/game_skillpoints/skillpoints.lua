-- Okno statystyk tfs1098.
-- Serwer trzyma cala logike: klient prosi o stan ({action = "refresh"}) i wysyla
-- zyczenie wydania punktu ({action = "spend", stat = <id>}), a w odpowiedzi dostaje
-- komplet danych. Nic nie liczymy tutaj - dzieki temu okno nie moze sie rozjechac
-- z serwerem. Handler po stronie serwera: data/creaturescripts/scripts/extended_opcode.lua
--
-- Kazdy wiersz ma dymek z opisem "co ta statystyka robi". Opisy atrybutow kupowanych
-- za punkty przysyla serwer (pole desc w stanie), reszte - te statystyki, ktore klient
-- zna sam - trzymamy nizej przy definicjach wierszy.

local OPCODE = 60

-- 25.00 -> "25", 25.50 -> "25.5" - liczby w oknie maja byc krotkie
function trimZeros(value)
  return (string.format('%.2f', value):gsub('%.?0+$', ''))
end

-- Wiersze procentowe (bonusy z drzewka, konwersje, odpornosci) pisza sie tak samo.
local function asPercent(value)
  return trimZeros(tonumber(value) or 0) .. '%'
end

local STATS = {
  {
    key = 'attack',
    label = 'Physical Damage',
    desc = 'Damage range of the weapon you wield. Every hit rolls evenly inside it. Strength (melee) and Dexterity (ranged) raise the whole range by 1% for every 5 points.',
    -- serwer przysyla oba konce; rowne konce pokazujemy jako jedna liczbe
    format = function(maxValue, state)
      local minValue = state.attackMin or maxValue
      if minValue == maxValue then
        return tostring(maxValue)
      end
      return minValue .. ' - ' .. maxValue
    end
  },
  {key = 'life', label = 'Life', desc = 'Maximum hit points.'},
  {key = 'mana', label = 'Mana', desc = 'Maximum mana for spells and runes.'}
}

-- Sekcje, w ktore nie da sie wlozyc punktow - licza sie same
-- z ekwipunku i skilli. Wiersze roznia sie tylko tym, skad biora liczbe:
--   id         - skill z protokolu (LocalPlayer), zawsze w procentach
--   key        - pole ze stanu, ktore przysyla serwer
--   fromPlayer - liczba z protokolu, wiec odswiezenie stanu jej nie rusza
--   value      - stala; mechaniki jeszcze nie ma, wiersz stoi na zerze

-- Offensive: wszystko, co podbija zadawane obrazenia.
-- Skille dodatkowe (id 7-12) ida protokolem, wiec czytamy je z LocalPlayer.
-- Fishing (6) swiadomie pomijamy - zostaje w natywnym oknie skilli.
local OFFENSIVE_STATS = {
  {id = Skill.CriticalChance, label = 'Critical Hit Chance', desc = 'Chance (in %) for a critical hit.'},
  {id = Skill.CriticalDamage, label = 'Critical Hit Damage', desc = 'How many percent stronger a critical hit is.'},
  {
    key = 'attackSpeedSkill',
    label = 'Attack Speed',
    desc = 'Level of the attack speed skill. It shortens the pause between attacks; you cannot buy it with points - only equipment and Fate raise it.'
  },
  {
    key = 'attackSpeed',
    label = 'Attacks per Second',
    desc = 'How many hits per second you land with your weapon. Goes up together with the Attack Speed skill.',
    -- serwer podaje interwal w ms, gracza interesuje ile ciosow na sekunde
    format = function(interval)
      interval = tonumber(interval) or 0
      if interval <= 0 then
        return '-'
      end
      return string.format('%.2f', 1000 / interval)
    end
  },
  {
    key = 'accuracy',
    label = 'Accuracy',
    desc = 'How well your attacks find their target. It is weighed against the enemy Evasion: 200 base, +2 for every point of Dexterity, plus equipment and Fate. Even a huge lead never pushes the hit chance past 95%.'
  },
  {
    key = 'physicalIncrease',
    label = 'Increased Physical Damage',
    desc = 'How many percent stronger your physical hits are. Strength (melee) and Dexterity (ranged) give 1% for every 5 points; equipment and Fate add the rest. It multiplies the damage range rolled by your weapon.',
    format = asPercent
  },
  {
    key = 'spellIncrease',
    label = 'Increased Spell Damage',
    desc = 'How many percent stronger every spell is. This is what Fate gives; on top of it each spell gets 1% for every 5 points of the attribute it uses (Strength, Dexterity or Intelligence).',
    format = asPercent
  },
  {
    key = 'castSpeed',
    label = 'Cast Speed',
    desc = 'How many percent faster you finish a cast. It divides the casting time the way movement speed works, so +100% means half the wait. Spells that are instant stay instant.',
    format = asPercent
  }
}

-- Defensive: wszystko, co scina obrazenia przychodzace - razem z energy shieldem.
local DEFENSIVE_STATS = {
  {
    key = 'armor',
    label = 'Armor',
    desc = 'Armor from the items you wear and from Fate. Each point cuts 0.01% of the damage you take, up to 80%.',
    -- ile procent obrazen scina ten armor, liczy serwer (stale siedza w const.h)
    format = function(armor, state)
      return string.format('%d (%s%%)', armor, trimZeros(state.armorReduction or 0))
    end
  },
  -- Unik i blok dzialaja jak w PoE: albo cios nie dosiega wcale, albo dochodzi caly.
  -- Obie liczby ida z ekwipunku i z drzewka, procenty z drzewka mnoza juz cala sume.
  {
    key = 'evasion',
    label = 'Evasion',
    desc = 'How well you slip out of the way. It is weighed against the attacker Accuracy, so the same rating is worth less against a stronger enemy. A dodged hit deals nothing at all.'
  },
  {
    key = 'blockChance',
    label = 'Block Chance',
    desc = 'Chance (in %) to block an incoming hit completely. Shields, affixes and Fate add up, and the total cannot pass 75%.',
    format = asPercent
  },
  {
    key = 'energyShield',
    label = 'ES',
    desc = 'Energy Shield - an extra pool that soaks damage before it reaches your hit points. This is the total from everything you wear plus Fate.',
    format = function(value)
      return trimZeros(tonumber(value) or 0)
    end
  },
  {
    key = 'energyShieldIncrease',
    label = 'ES Increased',
    desc = 'How many percent bigger your Energy Shield is. Equipment carries the flat pool, these percent come from Fate and multiply the whole total.',
    format = asPercent
  },
  {
    key = 'energyShieldRecharge',
    label = 'ES Recharge per Second',
    desc = 'How much Energy Shield comes back every second once the recharge starts.',
    format = function(value)
      return trimZeros(tonumber(value) or 0)
    end
  },
  {
    key = 'energyShieldInterval',
    label = 'ES Recharge',
    desc = 'How often the Energy Shield ticks back, in milliseconds. Base is 2500 ms and it cannot go below 500 ms, no matter how much ES Recharge Speed you stack.',
    format = function(value)
      return string.format('%d ms', tonumber(value) or 0)
    end
  },
  {
    key = 'energyShieldSpeed',
    label = 'ES Recharge Speed',
    desc = 'How many percent faster the Energy Shield ticks. It shortens the interval the way movement speed works: the base is divided, so +100% means half the interval.',
    format = function(value)
      return trimZeros(tonumber(value) or 0) .. '%'
    end
  },
  {
    key = 'energyShieldDelay',
    label = 'ES Recharge Delay',
    desc = 'How many seconds after the last hit the Energy Shield starts recharging. Every hit you take resets it.',
    format = function(value)
      return trimZeros(tonumber(value) or 0)
    end
  }
}

-- Server array uses combatTypeToIndex + 1. Healing and undefined damage are
-- not resistible elements shown in the character panel.
local RESISTANCE_STATS = {}
for _, element in ipairs({
  {1, 'Physical'},
  {4, 'Fire'},
  {3, 'Earth'},
  {2, 'Lighting'},
  {10, 'Ice'},
  {11, 'Holy'},
  {12, 'Chaos'},
  {9, 'Drown'},
  {6, 'Life Drain'},
  {7, 'Mana Drain'}
}) do
  local index, label = element[1], element[2]
  RESISTANCE_STATS[#RESISTANCE_STATS + 1] = {
    key = 'resistance' .. index,
    label = label,
    desc = 'Resistance to ' .. label .. ' damage from active equipment, affixes and Fate (in %). Every source combines multiplicatively, and Fate counts after equipment with its own 75% ceiling. Excludes armor and field-only protection; individual hits are rounded by the server.',
    format = function(_, state)
      local value = state.resistances and state.resistances[index]
      if value == nil then
        return '-'
      end
      -- Avoid displaying negative zero after rounding tiny floating point values.
      return trimZeros(math.abs(value) < 0.005 and 0 or value) .. '%'
    end
  }
end

-- Utility: reszta - poruszanie sie oraz odzyskiwanie zycia i many.
local UTILITY_STATS = {
  {
    key = 'speed',
    label = 'Speed',
    desc = 'How fast you move around the map. The percent from equipment and Fate is already counted in.',
    -- ta jedna klient dostaje protokolem, wiec nie szuka jej w stanie z serwera
    fromPlayer = true
  },
  {
    key = 'lifeIncrease',
    label = 'Increased maximum Life',
    desc = 'How many percent of maximum hit points Fate adds on top. The Life number at the top of the window already counts it - this row only shows where part of it comes from.',
    format = asPercent
  },
  {
    key = 'manaIncrease',
    label = 'Increased maximum Mana',
    desc = 'How many percent of maximum mana Fate adds on top. The Mana number at the top of the window already counts it - this row only shows where part of it comes from.',
    format = asPercent
  },
  {
    key = 'lifeRecovery',
    label = 'Life Recovery per Second',
    desc = 'How many hit points you get back every second - vocation regeneration, equipment and Fate together. The vocation part counts only while you are fed and pauses in a protection zone.',
    format = function(value)
      return trimZeros(tonumber(value) or 0)
    end
  },
  {
    key = 'manaRecovery',
    label = 'Mana Recovery per Second',
    desc = 'How much mana you get back every second - vocation regeneration, equipment and Fate together. The vocation part counts only while you are fed and pauses in a protection zone.',
    format = function(value)
      return trimZeros(tonumber(value) or 0)
    end
  },
  {
    key = 'healing',
    label = 'Healing',
    desc = 'Healing bonus. The system does not exist yet - the row shows 0 until it does.'
  },
  {id = Skill.LifeLeechChance, label = 'Life Leech Chance', desc = 'Chance (in %) to leech health from the damage you deal.'},
  {id = Skill.LifeLeechAmount, label = 'Life Leech Amount', desc = 'How much (in %) of the damage you deal comes back to you as health.'},
  {id = Skill.ManaLeechChance, label = 'Mana Leech Chance', desc = 'Chance (in %) to leech mana from the damage you deal.'},
  {id = Skill.ManaLeechAmount, label = 'Mana Leech Amount', desc = 'How much (in %) of the damage you deal comes back to you as mana.'},
  {label = 'Increased Magic Find', value = '0%', desc = 'Magic find bonus (in %).'},
  {label = 'Increased Loot Find', value = '0%', desc = 'Loot find bonus (in %).'},
  {label = 'Increased Gold Find', value = '0%', desc = 'Gold find bonus (in %).'},
  {label = 'Increased Damage to Elites', value = '0%', desc = 'Increased damage dealt to elite enemies (in %).'},
  {label = 'Reduced Damage from Elites', value = '0%', desc = 'Reduced damage taken from elite enemies (in %).'},
  {label = 'Bonus experience', value = '0%', desc = 'Experience bonus (in %).'}
}

-- Elemental: procenty obrazen zywiolem i konwersje ciosu fizycznego. Oba bonusy
-- daje dzis wylacznie drzewko Fate. Nazwy zywiolow sa takie same, jak w sekcji
-- Resistances, zeby jedno okno nie mowilo o tym samym na dwa sposoby - drzewko
-- nazywa je po swojemu (cold, lightning, poison, death), wiec dymek to prostuje.
local ELEMENTAL_STATS = {}
for _, element in ipairs({
  {label = 'Fire', increase = 'fireIncrease', conversion = 'physToFire', tree = 'fire'},
  {label = 'Ice', increase = 'coldIncrease', conversion = 'physToCold', tree = 'cold'},
  {label = 'Lighting', increase = 'lightningIncrease', conversion = 'physToLightning', tree = 'lightning'},
  {label = 'Earth', increase = 'poisonIncrease', tree = 'poison'},
  {label = 'Holy', increase = 'holyIncrease', tree = 'holy'},
  {label = 'Chaos', increase = 'deathIncrease', conversion = 'physToDeath', tree = 'death'}
}) do
  ELEMENTAL_STATS[#ELEMENTAL_STATS + 1] = {
    key = element.increase,
    label = 'Increased ' .. element.label .. ' Damage',
    desc = 'How many percent stronger everything that hits with ' .. element.label
      .. ' damage is - weapons, converted damage and spells of that element alike. '
      .. 'A hit that does not carry it gains nothing. Fate calls these nodes "'
      .. element.tree .. ' damage".',
    format = asPercent
  }
end
for _, element in ipairs({
  {label = 'Fire', key = 'physToFire'},
  {label = 'Ice', key = 'physToCold'},
  {label = 'Lighting', key = 'physToLightning'},
  {label = 'Chaos', key = 'physToDeath'}
}) do
  ELEMENTAL_STATS[#ELEMENTAL_STATS + 1] = {
    key = element.key,
    label = 'Physical Converted to ' .. element.label,
    desc = 'How many percent of every physical hit leaves as ' .. element.label
      .. ' damage instead. What is converted comes back as a second hit of that element, '
      .. 'so it takes the enemy resistance to ' .. element.label
      .. ' and your increased ' .. element.label .. ' damage. The sum of all conversions stops at 100%.',
    format = asPercent
  }
end

-- Kolejnosc sekcji w oknie Info; panel to id z info.otui.
local SECTIONS = {
  {panel = 'offensivePanel', rows = OFFENSIVE_STATS},
  {panel = 'defensivePanel', rows = DEFENSIVE_STATS},
  {panel = 'resistancesPanel', rows = RESISTANCE_STATS},
  {panel = 'utilityPanel', rows = UTILITY_STATS},
  {panel = 'elementalPanel', rows = ELEMENTAL_STATS}
}

-- Zwijanie sekcji: naglowek -> widgety, ktore chowa jego klikniecie. Attributes
-- nie ma wlasnej tabeli wierszy (buduje je serwer), wiec siedzi tylko tutaj.
-- Ukryte dziecko wypada z ukladu pionowego, wiec po sekcji nie zostaje dziura.
local COLLAPSIBLE = {
  {
    title = 'attributesTitle',
    setting = 'foldedAttributes',
    content = {'statsPanel', 'attributesSeparator', 'attributesPanel', 'resetRow'}
  },
  {title = 'offensiveTitle', setting = 'foldedOffensive', content = {'offensivePanel'}},
  {title = 'defensiveTitle', setting = 'foldedDefensive', content = {'defensivePanel'}},
  {title = 'resistancesTitle', setting = 'foldedResistances', content = {'resistancesPanel'}},
  {title = 'utilityTitle', setting = 'foldedUtility', content = {'utilityPanel'}},
  {title = 'elementalTitle', setting = 'foldedElemental', content = {'elementalPanel'}},
  {title = 'equipmentTitle', setting = 'foldedEquipment', content = {'equipmentPanel', 'inspectFateButton'}},
  {title = 'spellsTitle', setting = 'foldedSpells', content = {'spellsPanel'}}
}

-- Dymek nie zawija tekstu sam (resizeToText mierzy najdluzsza linie i tyle), wiec
-- dlugie opisy lamiemy tutaj - inaczej rozjezdzaja sie na pol ekranu.
local TOOLTIP_WIDTH = 52

local function wrap(text)
  local lines = {}
  for paragraph in text:gmatch('[^\n]+') do
    local line = ''
    for word in paragraph:gmatch('%S+') do
      if #line == 0 then
        line = word
      elseif #line + #word + 1 <= TOOLTIP_WIDTH then
        line = line .. ' ' .. word
      else
        lines[#lines + 1] = line
        line = word
      end
    end
    if #line > 0 then
      lines[#lines + 1] = line
    end
  end
  return table.concat(lines, '\n')
end

-- Pierwsza linia to nazwa statystyki, dalej opis i - przy atrybutach - aktualne liczby.
local function tooltipFor(title, ...)
  local lines = {title}
  for i = 1, select('#', ...) do
    local text = select(i, ...)
    if type(text) == 'string' and #text > 0 then
      lines[#lines + 1] = wrap(text)
    end
  end
  return table.concat(lines, '\n')
end

skillPointsWindow = nil
skillPointsButton = nil
local infoWindow = nil
local inspectWindow = nil
local inspectStateRows, inspectSkillRows = {}, {}
local inspectedId = nil
local inspectedName = nil
local inspectSerial = 0


local equipmentStyles = {
  [1] = 'HeadSlot', [2] = 'NeckSlot', [3] = 'BackSlot',
  [4] = 'BodySlot', [5] = 'RightSlot', [6] = 'LeftSlot',
  [7] = 'LegSlot', [8] = 'FeetSlot', [9] = 'FingerSlot',
  [10] = 'SecondFingerSlot', [12] = 'ExtraSlot1',
  [14] = 'ExtraSlot3', [15] = 'BeltSlot'
}

local function updateEquipmentSlot(slot, item, window, tooltipInfo)
  window = window or infoWindow
  local style = equipmentStyles[slot]
  if not window or not style then return end
  local widget = window:recursiveGetChildById('equipmentPanel'):getChildById('slot' .. slot)
  if not widget then return end
  widget:setStyle(item and 'InventoryItem' or style)
  -- Keep the Info copy display-only after every style change.
  widget:setVirtual(true)
  widget:setDraggable(false)
  if item then widget:setIcon('') end
  widget:setItem(item)
  -- Give these read-only copies their own hover owner so map movement cannot
  -- hide their tooltip. Remote icons must use the inspected item's snapshot.
  local tooltipItem = (window == infoWindow or tooltipInfo) and item or nil
  modules.game_itemtooltip.setItemPreview(widget, tooltipItem, tooltipInfo)
end

local function refreshEquipment()
  if not infoWindow then return end
  local player = g_game.getLocalPlayer()
  for slot in pairs(equipmentStyles) do
    updateEquipmentSlot(slot, player and player:getInventoryItem(slot) or nil)
  end
end

local statRows = {}
-- Wiersze pod kluczem ze stanu serwera i pod id skilla z protokolu.
local stateRows = {}
local skillRows = {}
local attributeRows = {}
local lastState = nil

-- Ktore sekcje sa zwiniete. Stan siedzi tez w ustawieniach okna (wezel MiniWindows
-- w config.otml), wiec przezywa restart klienta - zapis dziala dzieki &save: true.
local collapsed = {}

local function sectionWindow(section)
  return section.title == 'attributesTitle' and skillPointsWindow or infoWindow
end

local function applySection(section, hide)
  collapsed[section.title] = hide

  for _, id in ipairs(section.content) do
    local widget = sectionWindow(section):recursiveGetChildById(id)
    if widget then
      widget:setVisible(not hide)
    end
  end

  -- Wcisniety naglowek = sekcja schowana (stan $on w skillpoints.otui).
  local title = sectionWindow(section):recursiveGetChildById(section.title)
  if title then
    title:setOn(hide)
    title:setTooltip(hide and tr('Click to unfold this section') or tr('Click to fold this section'))
  end
end

function toggleSection(section)
  local hide = not collapsed[section.title]
  applySection(section, hide)
  skillPointsWindow:setSettings({[section.setting] = hide})
end

-- Odtworzenie stanu z poprzedniej sesji. Wolane po setup(), bo dopiero on wczytuje
-- ustawienia okna.
local function restoreSections()
  for _, section in ipairs(COLLAPSIBLE) do
    if skillPointsWindow:getSettings(section.setting) then
      applySection(section, true)
    end
  end
end

function init()
  connect(g_game, {
    onGameStart = onGameStart,
    onGameEnd = onGameEnd
  })
  connect(LocalPlayer, {
    onOutfitChange = onOutfitChange,
    onInventoryChange = onInventoryChange,
    onLevelChange = requestState,
    onSpeedChange = onSpeedChange,
    onSkillChange = onSkillChange,
    onStatesChange = onStatesChange
  })

  ProtocolGame.registerExtendedJSONOpcode(OPCODE, onStateReceived)

  skillPointsButton = modules.client_topmenu.addRightGameToggleButton('skillPointsButton',
    tr('Character'), '/images/topbuttons/attributes', toggle, false, 2)
  -- This icon has one frame; keep it visible in the retro layout's active states.
  skillPointsButton:mergeStyle({
    ['icon-clip'] = '0 0 20 20',
    ['border-width'] = 1,
    ['border-color'] = 'alpha',
    ['$on'] = {
      ['icon-clip'] = '0 0 20 20',
      ['border-color'] = '#d4af62'
    },
    ['$pressed'] = {
      ['icon-clip'] = '0 0 20 20',
      ['border-color'] = '#d4af62'
    }
  })
  skillPointsWindow = g_ui.loadUI('skillpoints', modules.game_interface.getRightPanel())
  infoWindow = g_ui.loadUI('info', rootWidget)
  infoWindow:hide()
  infoWindow:recursiveGetChildById('inspectFateButton'):destroy()
  inspectWindow = g_ui.loadUI('info', rootWidget)
  inspectWindow:setId('characterInspectWindow')
  inspectWindow:setText(tr('Inspect'))
  inspectWindow:hide()
  inspectWindow:recursiveGetChildById('inspectFateButton').onClick = function()
    local player = g_game.getLocalPlayer()
    if not player or not modules.game_fate then return end
    modules.game_fate.inspect(inspectedId or player:getId(), inspectedName or player:getName())
  end

  local statsPanel = skillPointsWindow:recursiveGetChildById('statsPanel')
  for _, stat in ipairs(STATS) do
    local row = g_ui.createWidget('SkillPointsStat', statsPanel)
    row:getChildById('name'):setText(tr(stat.label))
    row:getChildById('value'):setText('-')
    row:setTooltip(tooltipFor(tr(stat.label), stat.desc))
    statRows[stat.key] = row
  end

  for _, view in ipairs({
    {window = infoWindow, state = stateRows, skills = skillRows},
    {window = inspectWindow, state = inspectStateRows, skills = inspectSkillRows}
  }) do
    local window, stateRows, skillRows = view.window, view.state, view.skills
  for _, section in ipairs(SECTIONS) do
    local panel = window:recursiveGetChildById(section.panel)
    for _, stat in ipairs(section.rows) do
      local row = g_ui.createWidget('SkillPointsStat', panel)
      row:getChildById('name'):setText(tr(stat.label))
      if stat.id then
        row:getChildById('value'):setText('0%')
        row:setTooltip(tooltipFor(tr(stat.label), stat.desc))
        skillRows[stat.id] = row
      elseif stat.key then
        row:getChildById('value'):setText('-')
        row:setTooltip(tooltipFor(tr(stat.label), stat.desc))
        stateRows[stat.key] = row
      else
        -- wiersz bez zrodla - czeka na mechanike, stoi na wartosci z tabeli
        row:getChildById('value'):setText(stat.value)
        row:setTooltip(tooltipFor(tr(stat.label), stat.desc, tr('Not implemented yet.')))
      end
    end
  end

  end

  for _, section in ipairs(COLLAPSIBLE) do
    local title = sectionWindow(section):recursiveGetChildById(section.title)
    if title then
      title.onClick = function()
        toggleSection(section)
      end
    end
  end

  local inspectCollapsed = {}
  for _, section in ipairs(COLLAPSIBLE) do
    if section.title ~= 'attributesTitle' then
      local title = inspectWindow:recursiveGetChildById(section.title)
      title.onClick = function()
        local hide = not inspectCollapsed[section.title]
        inspectCollapsed[section.title] = hide
        for _, id in ipairs(section.content) do
          local widget = inspectWindow:recursiveGetChildById(id)
          if widget then widget:setVisible(not hide) end
        end
        title:setOn(hide)
      end
    end
  end

  -- Ikona monety przy saldzie banku. 3031 to id KLIENTA (gold coin ma na serwerze
  -- 2148) - sprawdzone w items.otb. Ustawiamy z Lua, bo tak samo robi game_itemtooltip.
  local resetButton = skillPointsWindow:recursiveGetChildById('resetButton')
  if resetButton then
    resetButton.onClick = resetPoints
  end

  local creedButton = skillPointsWindow:recursiveGetChildById('creedButton')
  if creedButton then
    creedButton.onClick = function()
      -- Modul drzewka jest osobny, wiec sprawdzamy czy w ogole jest wczytany.
      if modules.game_fate then
        modules.game_fate.toggle()
      end
    end
  end

  skillPointsWindow:recursiveGetChildById('infoButton').onClick = function()
    if infoWindow:isVisible() then
      infoWindow:hide()
    else
      refreshEquipment()
      updateLocalStats()
      requestState()
      infoWindow:show()
      infoWindow:raise()
      infoWindow:focus()
    end
  end

  updateFateButton()
  skillPointsWindow:setup()
  restoreSections()

  if g_game.isOnline() then
    onGameStart()
  end
end

function terminate()
  disconnect(g_game, {
    onGameStart = onGameStart,
    onGameEnd = onGameEnd
  })
  disconnect(LocalPlayer, {
    onOutfitChange = onOutfitChange,
    onInventoryChange = onInventoryChange,
    onLevelChange = requestState,
    onSpeedChange = onSpeedChange,
    onSkillChange = onSkillChange,
    onStatesChange = onStatesChange
  })

  ProtocolGame.unregisterExtendedJSONOpcode(OPCODE)

  infoWindow:destroy()
  infoWindow = nil
  inspectWindow:destroy()
  inspectWindow = nil
  inspectStateRows, inspectSkillRows = {}, {}
  skillPointsWindow:destroy()
  skillPointsButton:destroy()
end

function toggle()
  if skillPointsButton:isOn() then
    skillPointsWindow:close()
    skillPointsButton:setOn(false)
  else
    skillPointsWindow:open()
    skillPointsButton:setOn(true)
    requestState()
  end
end

function onMiniWindowClose()
  skillPointsButton:setOn(false)
end

local function send(data)
  local protocol = g_game.getProtocolGame()
  if protocol then
    protocol:sendExtendedJSONOpcode(OPCODE, data)
  end
end

function requestState()
  send({action = 'refresh'})
end

-- Inspect is read-only; normal Character updates must never overwrite another player.
function inspect(creature)
  if not creature or not creature:isPlayer() or not g_game.isOnline() then return end
  inspectSerial = inspectSerial + 1
  inspectedName = creature:getName()
  inspectedId = creature:getId()
  inspectWindow:setText(tr('Inspect') .. ' - ' .. inspectedName)
  for slot in pairs(equipmentStyles) do updateEquipmentSlot(slot, nil, inspectWindow) end
  for _, row in pairs(inspectStateRows) do row:getChildById('value'):setText('-') end
  for _, row in pairs(inspectSkillRows) do row:getChildById('value'):setText('-') end
  send({action = 'inspect', target = inspectedId, serial = inspectSerial})
  inspectWindow:show()
  inspectWindow:raise()
  inspectWindow:focus()
end

local function applyInfoState(state, rows)
  rows = rows or stateRows
  for _, section in ipairs(SECTIONS) do
    for _, stat in ipairs(section.rows) do
      local row = stat.key and not stat.fromPlayer and rows[stat.key]
      if row then
        local raw = state[stat.key] or 0
        row:getChildById('value'):setText(stat.format and stat.format(raw, state) or tostring(raw))
      end
    end
  end
end

-- Serwer oddaje wszystkie wydane punkty do puli i odsyla swiezy stan.
function resetPoints()
  send({action = 'reset'})
end

function setupBankIcon()
  if not skillPointsWindow then
    return
  end

  local bankIcon = skillPointsWindow:recursiveGetChildById('bankIcon')
  if bankIcon then
    bankIcon:setImageSource('/images/game/slots/gold_coin_ui')
  end
end

function onGameStart()
  inspectedId = nil
  refreshEquipment()
  updateAvatar()
  updateLocalStats()
  requestState()
  addEvent(setupBankIcon)
end

local function setStateRow(key, value)
  local row = stateRows[key]
  if row then
    row:getChildById('value'):setText(tostring(value))
  end
end

-- Reset przechodzi tylko w strefie chronionej, wiec poza nia przycisk szarzeje.
-- Stan PZ klient dostaje w protokole (PlayerStates.Pz), nie pyta o niego serwera.
-- Powod trzymamy w dymku wiersza, nie przycisku: wylaczony widget nie lapie hovera,
-- wiec jego wlasny dymek juz by sie nie pokazal.
function updateFateButton()
  local button = skillPointsWindow and skillPointsWindow:recursiveGetChildById('creedButton')
  if not button then return end
  local player = g_game.getLocalPlayer()
  local inPz = player ~= nil and bit32.band(player:getStates(), PlayerStates.Pz) ~= 0
  button:setEnabled(inPz)
  local row = skillPointsWindow:recursiveGetChildById('creedRow')
  if row then
    row:setTooltip(inPz and '' or tr('You can only open Fate inside a protection zone.'))
  end
end

function updateResetButton()
  updateFateButton()
  local button = skillPointsWindow and skillPointsWindow:recursiveGetChildById('resetButton')
  if not button then
    return
  end

  local player = g_game.getLocalPlayer()
  local inPz = player ~= nil and bit32.band(player:getStates(), PlayerStates.Pz) ~= 0
  local hasSpent = false
  for _, stat in ipairs((lastState and lastState.stats) or {}) do
    if (stat.points or 0) > 0 then
      hasSpent = true
      break
    end
  end
  button:setEnabled(inPz and hasSpent)

  local row = skillPointsWindow:recursiveGetChildById('resetRow')
  if row then
    if not inPz then
      row:setTooltip(tr('You can only reset your points inside a protection zone.'))
    elseif not hasSpent then
      row:setTooltip(tr('There are no spent points to reset.'))
    else
      row:setTooltip('')
    end
  end
end

function onStatesChange(localPlayer, now, old)
  updateResetButton()
end

function realSpeed(speed)
  if g_game.getFeature(GameNewSpeedLaw) then
    return speed * 2
  end
  return speed
end

function onSpeedChange(localPlayer, speed)
  -- Protokol 10.x (GameNewSpeedLaw) przesyla predkosc podzielona przez 2 - pokazujemy
  -- wartosc serwerowa, taka sama jak basespeed w vocations.xml.
  setStateRow('speed', realSpeed(speed))
end

function onSkillChange(localPlayer, id, level, percent)
  local row = skillRows[id]
  if row then
    row:getChildById('value'):setText(level .. '%')
  end

  -- Attack speed siedzi pod slotem 0 i tez idzie protokolem, wiec nie czekamy
  -- z nim na odswiezenie stanu z serwera.
  if id == Skill.Fist and stateRows.attackSpeedSkill then
    stateRows.attackSpeedSkill:getChildById('value'):setText(tostring(level))
  end
end

-- Wartosci startowe - zdarzenia lecą dopiero przy zmianie.
function updateLocalStats()
  local player = g_game.getLocalPlayer()
  if not player then
    return
  end

  onSpeedChange(player, player:getSpeed())
  updateResetButton()

  for id in pairs(skillRows) do
    onSkillChange(player, id, player:getSkillLevel(id))
  end

  onSkillChange(player, Skill.Fist, player:getSkillLevel(Skill.Fist))
end

function onGameEnd()
  inspectedId = nil
  inspectSerial = inspectSerial + 1
  infoWindow:hide()
  inspectWindow:hide()
  inspectedName = nil
  lastState = nil
end

function onOutfitChange(localPlayer, outfit)
  updateAvatar()
end

-- Ekwipunek zmienia Attack i armor, wiec po kazdej zmianie pytamy serwer o swieze liczby.
function onInventoryChange(localPlayer, slot, item, oldItem)
  updateEquipmentSlot(slot, item)
  requestState()
end

-- Avatar i imie klient zna sam, wiec nie zawracamy tym glowy serwerowi.
function updateAvatar()
  local player = g_game.getLocalPlayer()
  if not player then
    return
  end

  local avatar = skillPointsWindow:recursiveGetChildById('avatar')
  if avatar then
    avatar:setOutfit(player:getOutfit())
  end

  local nameLabel = skillPointsWindow:recursiveGetChildById('name')
  if nameLabel then
    nameLabel:setText(player:getName())
  end
end

local function onAddClick(statId)
  send({action = 'spend', stat = statId, amount = 1})
end

-- Buduje brakujace wiersze atrybutow; przy kolejnych odswiezeniach tylko je uzupelnia.
local function getAttributeRow(index, statId)
  local row = attributeRows[index]
  if row then
    return row
  end

  row = g_ui.createWidget('SkillPointsAttribute',
    skillPointsWindow:recursiveGetChildById('attributesPanel'))
  row:getChildById('add').onClick = function()
    onAddClick(statId)
  end

  attributeRows[index] = row
  return row
end

-- tfs1098: saldo banku pod przyciskiem z punktami. Wartosc przysyla serwer przez
-- modules/game_lootlabels (opcode 63), stamtad wolane jest setBank.
local function setHeaderLabel(id, text)
  if not skillPointsWindow then
    return
  end
  local header = skillPointsWindow:recursiveGetChildById('header')
  -- rekurencyjnie, bo saldo siedzi teraz w podpanelu bankRow (razem z ikona monety),
  -- a getChildById patrzy tylko na bezposrednie dzieci
  local label = header and header:recursiveGetChildById(id)
  if label then
    label:setText(text)
  end
end

function setBank(value)
  setHeaderLabel('bank', tr('Bank balance') .. ': ' .. comma_value(value or 0))
end

function setScrap(value)
  setHeaderLabel('scrap', tr('Scrap') .. ': ' .. comma_value(value or 0))
end

function onStateReceived(protocol, opcode, state)
  if type(state) ~= 'table' then
    return
  end

  if state.action == 'inspect' then
    if state.target ~= inspectedId or state.serial ~= inspectSerial then return end
    if state.error then
      inspectWindow:hide()
      inspectedId = nil
      return
    end
    applyInfoState(state, inspectStateRows)
    inspectStateRows.speed:getChildById('value'):setText(tostring(state.speed or 0))
    for id, row in pairs(inspectSkillRows) do
      row:getChildById('value'):setText(tostring((state.skills or {})[tostring(id)] or 0) .. '%')
    end
    for slot in pairs(equipmentStyles) do
      local entry = (state.equipment or {})[tostring(slot)]
      local item = entry and Item.create(entry.clientId, entry.count or 1) or nil
      if item then item:setCustomAttribute(1, entry.frameCode or 0) end
      updateEquipmentSlot(slot, item, inspectWindow, entry and entry.tooltipInfo)
    end
    return
  end

  lastState = state
  updateAvatar()

  local header = skillPointsWindow:recursiveGetChildById('header')
  header:getChildById('vocation'):setText(state.vocation or '')
  header:getChildById('level'):setText(tr('Level') .. ' ' .. (state.level or 0))
  -- Licznik punktow siedzi juz nie w naglowku, tylko w wierszu z przyciskiem Reset.
  skillPointsWindow:recursiveGetChildById('points'):setText((state.points or 0) .. ' ' .. tr('Points'))
  if modules.game_lootlabels and modules.game_lootlabels.getBank then
    setBank(modules.game_lootlabels.getBank())
    setScrap(modules.game_lootlabels.getBalance())
  end

  for _, stat in ipairs(STATS) do
    local row = statRows[stat.key]
    if row then
      local raw = state[stat.key] or 0
      row:getChildById('value'):setText(stat.format and stat.format(raw, state) or tostring(raw))
    end
  end

  applyInfoState(state)

  -- Reset rozdanych punktow: serwer mowi, czy gracz moze go uzyc sam. Chowamy sam
  -- przycisk - licznik punktow obok niego zostaje widoczny.
  local resetButton = skillPointsWindow:recursiveGetChildById('resetButton')
  if resetButton then
    resetButton:setVisible(state.canReset ~= false)
  end
  updateResetButton()

  local free = state.points or 0
  for index, stat in ipairs(state.stats or {}) do
    local row = getAttributeRow(index, stat.id)
    row:getChildById('name'):setText(stat.name)

    -- Z przodu poziom, ktorym gracz naprawde dysponuje, w nawiasie sam naddatek -
    -- "11 (+9)" czyta sie od razu: mam jedenascie, dziewiec z tego nie jest moje.
    -- Rozbicie tego naddatku na zrodla siedzi w dymku (serwer przysyla stat.sources).
    local effective = stat.effective or stat.level
    local bonus = effective - stat.level
    local value = tostring(effective)
    if bonus ~= 0 then
      value = value .. ' (' .. (bonus > 0 and '+' or '') .. bonus .. ')'
    end
    row:getChildById('value'):setText(value)

    local capped = stat.max and stat.max > 0 and stat.points >= stat.max
    local add = row:getChildById('add')
    add:setEnabled(free > 0 and not capped)

    -- Dymek: co statystyka robi (opis z serwera), na jakich liczbach stoi teraz
    -- i ile punktow juz w nia poszlo. Ten sam tekst na wierszu i na przycisku +,
    -- bo przycisk lapie kursor sam i inaczej dymek by znikal nad nim.
    local spent = stat.max and stat.max > 0
      and string.format('%s: %d/%d', tr('Points spent'), stat.points or 0, stat.max)
      or string.format('%s: %d', tr('Points spent'), stat.points or 0)
    local hint
    if capped then
      hint = tr('This attribute is at its maximum.')
    elseif free < 1 then
      hint = tr('No free points to spend.')
    else
      hint = tr('Click + to spend one point.')
    end

    -- Skad bierze sie naddatek. Nazwy zrodel ustala serwer (SKILL_POINTS.bonusSources),
    -- klient tylko je tlumaczy - dolozenie gemow nie wymaga tu zmiany.
    local breakdown = nil
    if bonus ~= 0 then
      local parts = {}
      for _, source in ipairs(stat.sources or {}) do
        local amount = tonumber(source.value) or 0
        if amount ~= 0 then
          parts[#parts + 1] = string.format('%s%d %s %s',
            amount > 0 and '+' or '', amount, tr('from'), tr(source.source))
        end
      end
      if #parts > 0 then
        breakdown = table.concat(parts, ', ')
      end
    end

    local tooltip = tooltipFor(stat.name, stat.desc, breakdown, stat.info, spent, hint)
    row:setTooltip(tooltip)
    add:setTooltip(tooltip)
    row:setVisible(true)
  end

  -- Gdyby serwer przyslal krotsza liste niz poprzednio - chowamy nadmiarowe wiersze.
  for index = #(state.stats or {}) + 1, #attributeRows do
    attributeRows[index]:setVisible(false)
  end
end
