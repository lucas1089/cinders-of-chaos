-- Fate / Spells - okna drzewek rozwoju postaci.
--
-- Cala tresc drzewka (wezly, pozycje, wymagania, ceny) przychodzi z serwera
-- extended opcode 62. Klient rysuje otrzymany graf, a klikniecie wezla wysyla
-- jako prosbe. Fate ma lokalny cache grafiki polaczen, sprawdzany z pozycjami
-- z serwera; nie zawiera kosztow ani zasad kupowania.
--
-- Drzewko ma ponad trzy tysiace wezlow, a extended opcode miesci najwyzej 8192
-- bajty (silnik po cichu nie wysyla wiekszych), wiec statyczny opis przychodzi
-- paczkami: "begin" -> kilka "nodes" -> "done". Sam postep, czyli punkty i listy id
-- wezlow kupionych oraz osiagalnych, to osobna, krotka wiadomosc "state" - i tylko
-- ona leci po kupieniu wezla (duzy stan tez jest dzielony na paczki). Widgetow
-- nie budujemy ponownie, a ich style aktualizujemy tylko po zmianie stanu.
--
-- Pasywy i talenty maja osobne okna. Wspolrzedne pasywow tworza konstelacje;
-- cache polaczen unika kosztownych obrotow widgetow w kolejce rysowania OTCv8.

local OPCODE = 62

local GRID_X = 68   -- odstep miedzy kolumnami w pikselach (przy zoomie 1.0)
local GRID_Y = 62   -- odstep miedzy rzedami

-- Ranga wezla ("kind" z serwera) decyduje o rozmiarze, stylu i o tym, czy wezel
-- dostaje podpis. Podpisow przy malych wezlach nie ma - 400 nazw naraz to kasza.
-- 32 dla malego wezla nie jest przypadkiem: ikony statow rysowane sa na siatce
-- 64 px, wiec przy zoomie 1.0 wypadaja dokladnie w polowie, a przy maksymalnym 1:1.
local NODE_SIZE = {small = 32, notable = 48, gate = 58, root = 58, mastery = 48}
-- Ksztalt wezla mowi, z ktorej puli punktow jest platny: kwadrat = "talent" (galezie
-- podklas), kolo = "passive" (korona). Brama i korzen maja wlasne style.
local POOL_STYLE = {
  passive = {small = 'CreedNode', notable = 'CreedNodeNotable'},
  talent = {small = 'CreedNodeRound', notable = 'CreedNodeRoundNotable'},
}
local KIND_STYLE = {gate = 'CreedNodeGate', root = 'CreedNodeRoot'}
-- Korzen podpisu nie dostaje: siedzi tuz nad brama podklasy i podpis wchodzilby na nia.
local NODE_LABEL = {notable = true, gate = true, mastery = true}
-- Ikone wezla wybiera serwer (pole "icon" - kategoria bonusu) i przysyla ja razem
-- z drzewkiem. Tutaj zostaje tylko lista tych, ktore mamy w pob/ - nieznana nazwa
-- nie moze wywolac bledu wczytania obrazka, bo serwer moze wyprzedzac klienta.
local POB_ICONS = {
  strength = true, dexterity = true, intelligence = true, life = true,
  liferegen = true, mana = true, manaleech = true, lifeleech = true,
  attackspeed = true, critchance = true, critdamage = true, physical = true,
  spell = true, armour = true, energyshield = true, fire = true, cold = true,
  lightning = true, chaos = true, movement = true,
}
local POB_ICON_DEFAULT = 'life'

-- Podsumowanie planu. Kolejnosc i tresc jak w opisach wezlow po stronie serwera
-- (DESCRIPTIONS w server/make-fate-identity.py), zeby te same bonusy czytalo sie
-- tak samo w dymku i w panelu planera.
-- Kolory obu list bonusow. Dopisek szkicu przy kupionym bonusie nosi kolor listy
-- planowanej, zeby od razu bylo widac, ktora czesc liczby jeszcze nie jest Twoja.
local ALLOCATED_COLOR, PLANNED_COLOR = '#c7bfa4', '#b6acd1'

local BONUS_LABELS = {
  {'stats', 'Strength', '%+d Strength'},
  {'stats', 'Dexterity', '%+d Dexterity'},
  {'stats', 'Intelligence', '%+d Intelligence'},
  {'stats', 'Vitality', '%+d Vitality'},
  {'stats', 'Attack Speed', '%+d Attack Speed'},
  {'mods', 'lifeIncrease', '%+d%% maximum health'},
  {'mods', 'manaIncrease', '%+d%% maximum mana'},
  {'mods', 'lifeRegen', '%+d health per second'},
  {'mods', 'manaRegen', '%+d mana per second'},
  {'mods', 'armour', '%+d armour'},
  {'mods', 'armourIncrease', '%+d%% armour'},
  {'mods', 'evasion', '%+d evasion'},
  {'mods', 'evasionIncrease', '%+d%% evasion'},
  {'mods', 'accuracy', '%+d accuracy'},
  {'mods', 'accuracyIncrease', '%+d%% accuracy'},
  {'mods', 'energyShield', '%+d energy shield'},
  {'mods', 'energyShieldIncrease', '%+d%% energy shield'},
  {'mods', 'energyShieldRecharge', '%+d%% energy shield recharge'},
  {'mods', 'physicalIncrease', '%+d%% physical damage'},
  {'mods', 'spellIncrease', '%+d%% spell damage'},
  {'mods', 'fireIncrease', '%+d%% fire damage'},
  {'mods', 'coldIncrease', '%+d%% cold damage'},
  {'mods', 'lightningIncrease', '%+d%% lightning damage'},
  {'mods', 'poisonIncrease', '%+d%% poison damage'},
  {'mods', 'deathIncrease', '%+d%% death damage'},
  {'mods', 'holyIncrease', '%+d%% holy damage'},
  {'mods', 'castSpeed', '%+d%% cast speed'},
  {'mods', 'blockChance', '%+d%% chance to block'},
  {'mods', 'physToFire', '%+d%% physical converted to fire'},
  {'mods', 'physToCold', '%+d%% physical converted to cold'},
  {'mods', 'physToLightning', '%+d%% physical converted to lightning'},
  {'mods', 'physToDeath', '%+d%% physical converted to death'},
  {'mods', 'moveSpeed', '%+d%% movement speed'},
  {'mods', 'physicalRes', '%+d%% physical reduction'},
  {'mods', 'fireRes', '%+d%% fire resistance'},
  {'mods', 'coldRes', '%+d%% cold resistance'},
  {'mods', 'lightningRes', '%+d%% lightning resistance'},
  {'mods', 'poisonRes', '%+d%% poison resistance'},
  {'mods', 'holyRes', '%+d%% holy resistance'},
  {'mods', 'chaosRes', '%+d%% death resistance'},
  {'special', 'critChance', '%+d%% critical hit chance'},
  {'special', 'critDamage', '%+d%% critical hit damage'},
  {'special', 'lifeLeechChance', '%+d%% life leech chance'},
  {'special', 'lifeLeechAmount', '%+d%% life leech amount'},
  {'special', 'manaLeechChance', '%+d%% mana leech chance'},
  {'special', 'manaLeechAmount', '%+d%% mana leech amount'},
}

-- Polaczenia tez trzymaja odcien puli - przy oddaleniu to one zajmuja wiekszosc
-- ekranu, wiec bez tego drzewko zlewaloby sie w jeden kolor.
local LINK_COLOR = {
  passive = {idle = '#363b42', active = '#5c7fa0'},
  talent = {idle = '#403a31', active = '#8a7a4a'},
}

-- Twelve matte hues, clockwise from the right-hand spoke, matching the wheel.
-- Palette resolution happens only when a tree arrives, never while panning.
local BRANCH_COLORS = {
  {style = 'FateBranchOrange', idle = '#9e7a60', active = '#c5a489'},
  {style = 'FateBranchYellow', idle = '#9a915d', active = '#c2b787'},
  {style = 'FateBranchLime', idle = '#848f61', active = '#afb68b'},
  {style = 'FateBranchGreen', idle = '#65886d', active = '#96b094'},
  {style = 'FateBranchTeal', idle = '#5b8983', active = '#8eb1a6'},
  {style = 'FateBranchCyan', idle = '#608594', active = '#91aeb5'},
  {style = 'FateBranchBlue', idle = '#64809a', active = '#95a9b9'},
  {style = 'FateBranchIndigo', idle = '#746d92', active = '#a299b3'},
  {style = 'FateBranchViolet', idle = '#87698b', active = '#b297ad'},
  {style = 'FateBranchMagenta', idle = '#926682', active = '#bb94a6'},
  {style = 'FateBranchRose', idle = '#9a6b80', active = '#c298a4'},
  {style = 'FateBranchRed', idle = '#996a66', active = '#c1978f'},
}
local function branchPalette(node)
  if node.pool == 'talent' or node.kind == 'root' then return nil end
  if node.branchPalette then return node.branchPalette end
  local angle = node.x == 0 and (node.y >= 0 and math.pi / 2 or -math.pi / 2)
                or math.atan((node.y * GRID_Y) / (node.x * GRID_X))
  if node.x < 0 then angle = angle + math.pi end
  if angle < 0 then angle = angle + 2 * math.pi end
  local spoke = math.floor((angle + math.pi / 12) / (math.pi / 6)) % 12
  return BRANCH_COLORS[spoke + 1]
end

-- Follow the graph, not the angle of each curved tip. Resolve parents first;
-- packet ordering need not match the order of nodes along a branch.
local function assignBranchPalettes(nodes)
  local byId, visiting = {}, {}
  for _, node in ipairs(nodes) do
    node.branchPalette = nil
    byId[node.id] = node
  end
  local function resolve(node)
    if node.pool == 'talent' or node.kind == 'root' then return nil end
    if node.branchPalette then return node.branchPalette end
    if visiting[node.id] then return branchPalette(node) end
    visiting[node.id] = true
    local parent = byId[(node.requires or {})[1]]
    node.branchPalette = (parent and resolve(parent)) or branchPalette(node)
    visiting[node.id] = nil
    return node.branchPalette
  end
  for _, node in ipairs(nodes) do resolve(node) end
end

local ZOOM_MIN = 0.025
-- 2.0, a nie 1.6: przy tym zoomie ikona 64 px trafia w piksele ekranu 1:1.
local ZOOM_MAX = 2.00
local ZOOM_STEP = 1.20 -- same wheel ratio as the supplied Path of Building viewer
-- Ponizej tego progu podpisy i tak sie nie mieszcza w kratce, wiec je chowamy
-- i zostaje sam dymek pod kursorem. Czcionki sa bitmapowe, nie skaluja sie.
local ZOOM_LABELS = 0.80

-- Zapas plotna wokol drzewka. Wazny, bo dziecko wystajace poza rodzica po prostu
-- nie jest rysowane - plotno musi zmiescic skrajne wezly razem z podpisami.
local CANVAS_MARGIN = 140
local CHUNK_SIZE = 512 -- world pixels, independent of zoom
local PAN_FRAME_MS = 16

local function createTreeView(viewPool, readOnly)
local inspectTarget, inspectSerial = nil, 0
local zoom = 1.0
local panX, panY = 0, 0
local panEvent, pendingPanX, pendingPanY = nil, 0, 0
local chunks, chunkByKey, spatial = {}, {}, false
local updateChunks
local planner, planPending, planMessage = nil, false, nil
local hoverPath, hoverNode = {}, nil
local searchMatches, searchText = {}, ''
-- Sumy bonusow z kupionych wezlow; liczone raz przy odswiezeniu postepu, nie przy
-- kazdym odswiezeniu panelu.
local allocatedTotals = {stats = {}, special = {}, mods = {}}
local dragging = false
local refreshPlanner, refreshVisuals

local creedWindow = nil

local canvas = nil
local viewport = nil

local tree = nil            -- {nodes = {...}, signature = '...'}
local pendingProgress = nil
local incoming = nil        -- paczki w trakcie odbierania
-- pools to lista {id, title, points} w kolejnosci z serwera - klient ich nie zna
-- z gory, tylko wypisuje, wiec dolozenie kolejnej puli nie wymaga zmian tutaj.
-- chosen: id wezla mastery (jako tekst) -> numer wybranego efektu. Bez tego panel
-- nie wiedzialby, ktory z kilku bonusow wezla naprawde dziala.
local progress = {pools = {}, vocation = '', owned = {}, available = {}, chosen = {},
                  canReset = false, hasResettableNodes = false}

-- Numer efektu wybranego przy kupnie mastery. Serwer przysyla go w postepie, bo
-- sam wezel nie wie, ktory z jego efektow dziala u tego gracza.
local function chosenIndex(node)
  local chosen = progress.chosen or {}
  local index = tonumber(chosen[tostring(node.id)] or chosen[node.id])
  if not index or not node.effects or not node.effects[index] then
    return 1
  end
  return index
end

local nodeWidgets = {}      -- id -> widget wezla
local labelWidgets = {}     -- id -> podpis pod wezlem
local links = {}            -- {from, to, sprite/image or fallback lines, active}
local decorationWidgets = {}

local function send(data)
  if readOnly and data.action ~= 'inspect' then return end
  local protocol = g_game.getProtocolGame()
  if protocol then
    protocol:sendExtendedJSONOpcode(OPCODE, data)
  end
end

local function requestState()
  if readOnly then
    if inspectTarget then send({action = 'inspect', target = inspectTarget, serial = inspectSerial}) end
  else
    send({action = 'refresh'})
  end
end

-- ------------------------------------------------------------------
-- Siatka
-- ------------------------------------------------------------------

local function gridX()
  return GRID_X * zoom
end

local function gridY()
  return GRID_Y * zoom
end

local function styleFor(node)
  if viewPool == 'passive' then return 'FatePobNode' end
  local palette = branchPalette(node)
  if palette then return palette.style end
  if node.icon then
    return 'CreedNodeIcon'
  end
  local style = KIND_STYLE[node.kind]
  if style then
    return style
  end
  local pool = POOL_STYLE[node.pool] or POOL_STYLE.passive
  return pool[node.kind] or pool.small
end

local function poolTitle(id)
  for _, pool in ipairs(progress.pools or {}) do
    if pool.id == id then
      return pool.title
    end
  end
  return nil
end

local function nodeSize(kind)
  return math.max(3, math.floor((NODE_SIZE[kind] or NODE_SIZE.small) * zoom))
end

-- Srodek plotna. Wezel (0,0) - czyli korzen drzewka - stoi wlasnie tu, a plotno
-- jest symetryczne wzgledem niego, wiec srodek nie ucieka przy zmianie zoomu.
local function canvasCenter()
  return canvas:getWidth() / 2, canvas:getHeight() / 2
end

-- Ustawia widget w miejscu (x, y) LICZONYM OD LEWEGO GORNEGO ROGU PLOTNA.
-- Przez kotwice, a nie setPosition, z dwoch powodow: setPosition operuje na
-- wspolrzednych ekranu, a dzieci bez kotwic nie przesuwaja sie razem z rodzicem -
-- czyli przeciaganie plotna zostawialoby wezly w miejscu.
local function place(widget, x, y, width, height, visible)
  if widget.fateChunk then
    -- During zoom collect exact pixel bounds before positioning the group.
    local chunk = widget.fateChunk
    x, y = math.floor(x), math.floor(y)
    widget.fateX, widget.fateY = x, y
    widget.fateWidth = width or widget:getWidth()
    widget.fateHeight = height or widget:getHeight()
    widget.fateVisible = visible
    chunk.left = math.min(chunk.left, x)
    chunk.top = math.min(chunk.top, y)
    chunk.right = math.max(chunk.right, x + widget.fateWidth)
    chunk.bottom = math.max(chunk.bottom, y + widget.fateHeight)
    return
  end
  if width then widget:setSize({width = width, height = height}) end
  if width and widget.fateHasIcon then
    local inset = math.floor(width * 0.24)
    widget:setIconRect({x = inset, y = inset, width = math.max(1, width - inset * 2), height = math.max(1, height - inset * 2)})
  end
  if visible ~= nil then widget:setVisible(visible) end
  if not widget.fateAnchored then
    widget:addAnchor(AnchorLeft, 'parent', AnchorLeft)
    widget:addAnchor(AnchorTop, 'parent', AnchorTop)
    widget.fateAnchored = true
  end
  widget:setMarginLeft(math.floor(x))
  widget:setMarginTop(math.floor(y))
end

-- The canvas is anchored at the viewport center. An unanchored canvas is
-- clamped to the parent's top-left by native onGeometryChange/onVisibilityChange,
-- which used to undo centering after opening, moving or resizing the window.
local function setPan(x, y)
  panX, panY = math.floor(x + 0.5), math.floor(y + 0.5)
  local layout = viewport:getLayout()
  local contentLayout = canvas:getLayout()
  if layout then layout:disableUpdates() end
  if contentLayout then contentLayout:disableUpdates() end
  local entering = updateChunks and updateChunks() or {}
  canvas:setMarginLeft(panX)
  canvas:setMarginTop(panY)
  if layout then layout:enableUpdates(); layout:update() end
  if contentLayout then contentLayout:enableUpdates(); contentLayout:update() end
  for _, chunk in ipairs(entering) do chunk.layout:update() end
end

local function cancelPan()
  if panEvent then removeEvent(panEvent); panEvent = nil end
  pendingPanX, pendingPanY = 0, 0
end

local function flushPan()
  local x, y = pendingPanX, pendingPanY
  cancelPan()
  if canvas and tree and creedWindow and creedWindow:isVisible() and viewport:isVisible()
    and (x ~= 0 or y ~= 0) then setPan(panX + x, panY + y) end
end

-- Przesuwa plotno tak, zeby zadany punkt plotna wypadl na srodku widoku.
local function centerOn(x, y)
  local cx, cy = canvasCenter()
  setPan(cx - x, cy - y)
end

-- Pokazuje korzen, od ktorego zaczyna sie rozwoj. Starsze drzewka bez korzenia
-- centrujemy na granicach. Oddalenie kolkiem pozwala obejrzec cala konstelacje.
local function centerTree()
  cancelPan()
  local cx, cy = canvasCenter()
  if not tree or #tree.nodes == 0 then
    return centerOn(cx, cy)
  end
  for _, node in ipairs(tree.nodes) do
    if node.kind == 'root' then
      return centerOn(cx + node.x * gridX(), cy + node.y * gridY())
    end
  end
  centerOn(cx + (tree.minX + tree.maxX) / 2 * gridX(),
           cy + (tree.minY + tree.maxY) / 2 * gridY())
end

-- Czy cokolwiek z drzewka widac w oknie. Zabezpieczenie przed "uciekniciem" widoku
-- po zoomie albo przeciagnieciu za daleko - inaczej gracz zostaje z czarnym prostokatem
-- i nie wie, ze wystarczy kliknac Center.
local function treeVisible()
  local left, top = viewport:getX(), viewport:getY()
  local right, bottom = left + viewport:getWidth(), top + viewport:getHeight()

  for _, widget in pairs(nodeWidgets) do
    if not widget.fateChunk or widget.fateChunk.visible then
      local x, y = widget:getX(), widget:getY()
      if x + widget:getWidth() > left and x < right
        and y + widget:getHeight() > top and y < bottom then
        return true
      end
    end
  end
  return false
end

-- ------------------------------------------------------------------
-- Rysowanie
-- ------------------------------------------------------------------

-- Plotno przeliczaloby uklad po kazdym z ponad tysiaca widgetow z osobna, a to
-- robota kwadratowa - na czas budowy i przestawiania drzewka przeliczanie wylaczamy.
-- getLayout() bywa nil: UIWidget zaklada layout dopiero razem z pierwszym dzieckiem.
local function pauseLayout()
  local layout = canvas:getLayout()
  if layout then
    layout:disableUpdates()
  end
  return layout
end

local function resumeLayout(layout)
  layout = layout or canvas:getLayout()
  if layout then
    layout:enableUpdates()
    layout:update()
  end
end

local function suspendChunk(chunk)
  if not chunk.suspended then
    chunk.layout:disableUpdates()
    chunk.suspended = true
  end
end

local function createTreeWidget(style, worldX, worldY, layer)
  if not spatial then return g_ui.createWidget(style, canvas) end
  local key = layer .. ':' .. math.floor(worldX / CHUNK_SIZE) .. ':' .. math.floor(worldY / CHUNK_SIZE)
  local chunk = chunkByKey[key]
  if not chunk then
    local group = g_ui.createWidget('FateChunk', canvas)
    -- Initialize the native layout before suspending it (suspensions are counted).
    g_ui.createWidget('FateLink', group):destroy()
    chunk = {widget = group, layout = group:getLayout(), members = {}, visible = false}
    suspendChunk(chunk)
    chunkByKey[key] = chunk
    chunks[#chunks + 1] = chunk
  end
  local widget = g_ui.createWidget(style, chunk.widget)
  widget.fateChunk = chunk
  chunk.members[#chunk.members + 1] = widget
  return widget
end

-- A zoom updates cheap Lua geometry for every chunk, but native widget sizes
-- and anchors are only updated for visible chunks. Offscreen chunks keep their
-- layout suspended and materialize their latest geometry when they enter view.
local function materializeChunk(chunk)
  if not chunk.geometryDirty then return end
  for _, widget in ipairs(chunk.members) do
    widget:setSize({width = widget.fateWidth, height = widget.fateHeight})
    if widget.fateHasIcon then
      local inset = math.floor(widget.fateWidth * 0.24)
      widget:setIconRect({x = inset, y = inset, width = math.max(1, widget.fateWidth - inset * 2), height = math.max(1, widget.fateHeight - inset * 2)})
    end
    if widget.fateVisible ~= nil then widget:setVisible(widget.fateVisible) end
    if not widget.fateAnchored then
      widget:addAnchor(AnchorLeft, 'parent', AnchorLeft)
      widget:addAnchor(AnchorTop, 'parent', AnchorTop)
      widget.fateAnchored = true
    end
    widget:setMarginLeft(widget.fateX - chunk.left)
    widget:setMarginTop(widget.fateY - chunk.top)
  end
  chunk.geometryDirty, chunk.geometryInitialized = false, true
end

-- Visibility is evaluated against the *next* pan before the canvas moves.
-- Hidden chunks keep their own layout suspended, so moving their parent never
-- visits thousands of offscreen nodes. Their last screen positions may be stale.
updateChunks = function()
  local entering = {}
  local cx, cy = canvasCenter()
  local left = cx - panX - viewport:getWidth() / 2
  local top = cy - panY - viewport:getHeight() / 2
  local right, bottom = left + viewport:getWidth(), top + viewport:getHeight()
  for _, chunk in ipairs(chunks) do
    local visible = chunk.right >= left and chunk.left <= right
                    and chunk.bottom >= top and chunk.top <= bottom
    if visible then
      materializeChunk(chunk)
      if chunk.suspended then
        chunk.layout:enableUpdates()
        chunk.suspended = false
        entering[#entering + 1] = chunk
      end
    else
      suspendChunk(chunk)
    end
    if chunk.visible ~= visible then
      chunk.visible = visible
      chunk.widget:setVisible(visible)
    end
  end
  return entering
end

-- Rozmiar plotna liczymy z granic drzewka, symetrycznie wzgledem korzenia. Sztywne
-- 4000x4000 wystarczalo na kilkanascie wezlow, ale nie na pelna sciezke w kazda strone.
local function resizeCanvas()
  local halfX, halfY = 0, 0
  if tree then
    halfX = math.max(math.abs(tree.minX), math.abs(tree.maxX)) * gridX()
    halfY = math.max(math.abs(tree.minY), math.abs(tree.maxY)) * gridY()
  end
  canvas:setSize({width = math.ceil(2 * halfX + 2 * CANVAS_MARGIN),
                  height = math.ceil(2 * halfY + 2 * CANVAS_MARGIN)})
end

-- Przelicza pozycje i rozmiary wszystkiego pod aktualny zoom. Wolane przy budowie
-- drzewka i przy kazdym kroku kolka - bez tworzenia widgetow od nowa.
local function placeLine(widget, x1, y1, x2, y2)
  local dx, dy = x2 - x1, y2 - y1
  local length = math.sqrt(dx * dx + dy * dy)
  widget:setSize({width = math.max(1, math.ceil(length)), height = 2})
  place(widget, (x1 + x2 - length) / 2, (y1 + y2) / 2 - 1)
  local angle = dx == 0 and (dy >= 0 and 90 or -90) or math.deg(math.atan(dy / dx))
  widget:setRotation(angle)
end

local function polarAngle(node)
  local x, y = node.x * GRID_X, node.y * GRID_Y
  local angle = x == 0 and (y >= 0 and math.pi / 2 or -math.pi / 2) or math.atan(y / x)
  if x < 0 then angle = angle + math.pi end
  return angle
end

local function applyLayout(nextPanX, nextPanY)
  if not tree then
    return
  end

  local layout = pauseLayout()
  local viewportLayout = viewport:getLayout()
  if viewportLayout then viewportLayout:disableUpdates() end
  for _, chunk in ipairs(chunks) do
    suspendChunk(chunk)
    chunk.left, chunk.top, chunk.right, chunk.bottom = math.huge, math.huge, -math.huge, -math.huge
  end

  -- Zoom already knows the final cursor-preserving pan. Commit it while both
  -- parent layouts are paused, so visible children move once instead of twice.
  if nextPanX ~= nil then
    panX, panY = math.floor(nextPanX + 0.5), math.floor(nextPanY + 0.5)
    canvas:setMarginLeft(panX)
    canvas:setMarginTop(panY)
  end
  resizeCanvas()
  local cx, cy = canvasCenter()

  for _, entry in ipairs(decorationWidgets) do
    local d = entry.data
    local size = math.max(1, math.floor(d.size * zoom))
    local height = math.max(1, math.floor((d.height or d.size) * zoom))
    place(entry.widget, cx + d.x * zoom - size / 2, cy + d.y * zoom - height / 2, size, height)
  end

  for _, node in ipairs(tree.nodes) do
    local size = nodeSize(node.visualKind or node.kind)
    local centerX, centerY = cx + node.x * gridX(), cy + node.y * gridY()

    local widget = nodeWidgets[node.id]
    place(widget, centerX - size / 2, centerY - size / 2, size, size)

    local label = labelWidgets[node.id]
    if label then
      local width = math.floor(gridX() * (viewPool == 'passive' and 2.4 or 4))
      place(label, centerX - width / 2, centerY + size / 2 + 2,
            width, label:getHeight(), zoom >= ZOOM_LABELS)
    end
  end

  for _, link in ipairs(links) do
    local x1, y1 = cx + link.from.x * gridX(), cy + link.from.y * gridY()
    local x2, y2 = cx + link.to.x * gridX(), cy + link.to.y * gridY()
    if link.sprite then
      local clip = link.sprite
      local left = math.floor(cx + clip[6] * zoom)
      local top = math.floor(cy + clip[7] * zoom)
      place(link.image, left, top,
            math.max(1, math.ceil(cx + (clip[6] + (clip[8] or clip[4])) * zoom) - left),
            math.max(1, math.ceil(cy + (clip[7] + (clip[9] or clip[5])) * zoom) - top))
    elseif link.arc then
      local radius = link.radius * zoom
      for i, segment in ipairs(link.arc) do
        local a = link.angle + link.sweep * (i - 1) / #link.arc
        local b = link.angle + link.sweep * i / #link.arc
        placeLine(segment, cx + radius * math.cos(a), cy + radius * math.sin(a),
                           cx + radius * math.cos(b), cy + radius * math.sin(b))
      end
    elseif link.line then
      placeLine(link.line, x1, y1, x2, y2)
    else
      if link.vertical then
        link.vertical:setSize({width = 2, height = math.floor(math.abs(y2 - y1))})
        place(link.vertical, (link.horizontalFirst and x2 or x1) - 1, math.min(y1, y2))
      end
      if link.horizontal then
        link.horizontal:setSize({width = math.floor(math.abs(x2 - x1)), height = 2})
        place(link.horizontal, math.min(x1, x2), (link.horizontalFirst and y1 or y2) - 1)
      end
    end
  end

  for _, chunk in ipairs(chunks) do
    chunk.widget:setSize({width = chunk.right - chunk.left, height = chunk.bottom - chunk.top})
    place(chunk.widget, chunk.left, chunk.top)
    chunk.geometryDirty = true
    -- Initialize every widget once. Subsequent zooms only touch native geometry
    -- for visible groups; every widget retains its original pair of anchors.
    if not chunk.geometryInitialized then materializeChunk(chunk) end
  end
  local entering = updateChunks()
  if viewportLayout then viewportLayout:enableUpdates(); viewportLayout:update() end
  resumeLayout(layout)
  for _, chunk in ipairs(entering) do chunk.layout:update() end
end

local function tooltipFor(node)
  local lines = {node.name}
  -- Kazdy bonus w osobnej linii: dymek nie zawija tekstu, a keystone potrafi miec
  -- cztery skladniki naraz - jedna linia rozciagnelaby go przez pol ekranu.
  for sentence in (node.info or ''):gmatch('[^.]+%.') do
    lines[#lines + 1] = sentence:match('^%s*(.-)%s*$')
  end
  -- Mastery: kupiony pokazuje swoj efekt, niekupiony cala liste do wyboru.
  if node.effects then
    if node.owned then
      local effect = node.effects[chosenIndex(node)]
      lines[#lines + 1] = tr('Chosen') .. ': ' .. (effect.name or '')
      lines[#lines + 1] = effect.info or ''
    else
      for _, effect in ipairs(node.effects) do
        lines[#lines + 1] = '- ' .. (effect.name or '') .. ': ' .. (effect.info or '')
      end
    end
  end
  if readOnly then
    lines[#lines + 1] = node.owned and tr('Unlocked') or tr('Not unlocked')
    return table.concat(lines, '\n')
  end
  if node.owned then
    lines[#lines + 1] = tr('Unlocked')
  elseif (node.cost or 1) == 0 then
    lines[#lines + 1] = tr('Free')
  else
    lines[#lines + 1] = string.format(tr('Cost') .. ': %d %s', node.cost or 1,
                                      string.lower(poolTitle(node.pool) or tr('points')))
  end
  if not node.owned and not node.available then
    lines[#lines + 1] = node.neighbors and tr('Requires an adjacent unlocked node') or tr('Requires an earlier node')
  end
  if viewPool == 'passive' and not node.owned and node.kind ~= 'root' then
    lines[#lines + 1] = tr('Click: plan the shortest path. Apply points spends them.')
  end
  return table.concat(lines, '\n')
end

-- Odswieza to, co zmienia sie przy kupowaniu: podswietlenie wezlow, aktywnosc
-- polaczen i podpis w stopce. Widgetow nie rusza.
local function refreshProgress()
  local parts = {}
  for _, pool in ipairs(progress.pools or {}) do
    if pool.id == viewPool then
      parts[#parts + 1] = string.format('%s: %d', pool.title or '?', pool.points or 0)
    end
  end
  if viewPool == 'talent' and progress.vocation and progress.vocation ~= '' then
    parts[#parts + 1] = progress.vocation
  end
  creedWindow:getChildById('footer'):getChildById('points'):setText(
    readOnly and tr('Allocated tree - view only') or table.concat(parts, '   |   '))

  local ownedIds, hasSpent = {}, false
  for _, id in ipairs(progress.owned or {}) do ownedIds[id] = true end
  for _, node in ipairs(tree and tree.nodes or {}) do
    if node.kind ~= 'root' and ownedIds[node.id] then hasSpent = true break end
  end
  local resetButton = creedWindow:getChildById('footer'):getChildById('resetButton')
  local player = g_game.getLocalPlayer()
  local inPz = player ~= nil and bit32.band(player:getStates(), PlayerStates.Pz) ~= 0
  resetButton:setVisible(not readOnly and progress.canReset ~= false)
  resetButton:setEnabled(not readOnly and inPz and hasSpent)
  if readOnly then
    resetButton:getParent():setTooltip('')
  elseif not inPz then
    resetButton:getParent():setTooltip(tr('You can only reset this tree inside a protection zone.'))
  elseif not hasSpent then
    resetButton:getParent():setTooltip(tr('There are no spent points to reset.'))
  else
    resetButton:getParent():setTooltip('')
  end

  if not tree then
    if refreshPlanner then refreshPlanner() end
    return
  end

  local owned, available = {}, {}
  for _, id in ipairs(progress.owned or {}) do
    owned[id] = true
  end
  for _, id in ipairs(progress.available or {}) do
    available[id] = true
  end
  if planner then planner:setOwned(progress.owned or {}) end

  -- Sumy kupionych bonusow zbieramy przy okazji tej petli - inaczej panel musialby
  -- przechodzic 3037 wezlow przy kazdym ruchu myszy.
  allocatedTotals = {stats = {}, special = {}, mods = {}}
  for _, node in ipairs(tree.nodes) do
    node.owned = owned[node.id] or false
    if node.owned then
      -- Mastery ma puste pola bonusow - liczy sie efekt, ktory gracz wybral przy kupnie.
      local source = node.effects and node.effects[chosenIndex(node)] or node
      for group, sums in pairs(allocatedTotals) do
        for key, amount in pairs(source[group] or {}) do
          if type(amount) == 'number' then sums[key] = (sums[key] or 0) + amount end
        end
      end
    end
    node.available = available[node.id] or false

    local widget = nodeWidgets[node.id]
    local title = poolTitle(node.pool)
    if widget.fateOwned ~= node.owned or widget.fateAvailable ~= node.available
      or widget.fatePoolTitle ~= title then
      widget:setOn(node.owned)
      -- A distant Fate node must accept Shift-click even before it is reachable.
      -- Normal clicks still require availability; the server validates purchases.
      widget:setEnabled(viewPool == 'passive' or node.owned or node.available)
      widget:setTooltip(tooltipFor(node))
      widget.fateOwned, widget.fateAvailable, widget.fatePoolTitle = node.owned, node.available, title
    end

  end

  for _, link in ipairs(viewPool == 'passive' and {} or links) do
    local active = link.from.owned and link.to.owned
    if active ~= link.active then
      link.active = active
      local palette = branchPalette(link.to) or LINK_COLOR[link.to.pool] or LINK_COLOR.passive
      local color = active and palette.active or palette.idle
      if link.image then link.image:setImageColor(color) end
      if link.arc then
        for _, segment in ipairs(link.arc) do segment:setBackgroundColor(color) end
      end
      if link.line then link.line:setBackgroundColor(color) end
      if link.vertical then
        link.vertical:setBackgroundColor(color)
      end
      if link.horizontal then
        link.horizontal:setBackgroundColor(color)
      end
    end
  end
  if refreshVisuals then refreshVisuals() end
  if refreshPlanner then refreshPlanner() end
end

-- PoB uses a camera and image batches. Here the existing atlas keeps links
-- batchable; visual state changes never rebuild widgets or move the camera.
local function setLinkColor(link, color)
  if link.pobColor == color then return end
  link.pobColor = color
  if link.image then link.image:setImageColor(color) end
  if link.line then link.line:setBackgroundColor(color) end
  for _, segment in ipairs(link.arc or {}) do segment:setBackgroundColor(color) end
end

refreshVisuals = function()
  if viewPool ~= 'passive' or not tree then return end
  for _, node in ipairs(tree.nodes) do
    local widget = nodeWidgets[node.id]
    local planned = planner and planner:isPlanned(node.id)
    local hover = hoverPath[node.id]
    local active = node.owned or planned or node.kind == 'root'
    local frame
    local kind = node.visualKind or node.kind
    if kind == 'root' or kind == 'gate' then
      frame = active and 'KeystoneFrameAllocated' or 'KeystoneFrameUnallocated'
    elseif kind == 'mastery' then
      -- Mastery ma wlasna ramke z oryginalu: inny ksztalt od razu mowi, ze ten wezel
      -- nie daje bonusu sam z siebie, tylko pyta o wybor.
      frame = active and 'MasteryFrameAllocated'
        or (hover and 'MasteryFrameCanAllocate' or 'MasteryFrameUnallocated')
    elseif kind == 'notable' then
      frame = active and 'NotableFrameAllocated' or (hover and 'NotableFrameCanAllocate' or 'NotableFrameUnallocated')
    else
      frame = active and 'PSSkillFrameActive' or (hover and 'PSSkillFrameHighlighted' or 'PSSkillFrame')
    end
    local color = searchMatches[node.id] and '#a7efff' or hover and '#bceaf2'
      or planned and '#d6bc83' or active and '#ffffff' or node.available and '#b1a38a' or '#706b63'
    if widget.pobFrame ~= frame then
      widget:setImageSource('/modules/game_fate/pob/' .. frame)
      widget.pobFrame = frame
    end
    if widget.pobColor ~= color then widget:setImageColor(color); widget.pobColor = color end
    local iconColor = active and '#ffffff' or '#96918b'
    if widget.fateHasIcon and widget.pobIconColor ~= iconColor then
      widget:setIconColor(iconColor); widget.pobIconColor = iconColor
    end
  end
  for _, link in ipairs(links) do
    local a, b = link.from.id, link.to.id
    local aPlan, bPlan = planner and planner:isPlanned(a), planner and planner:isPlanned(b)
    local aActive, bActive = link.from.owned or aPlan, link.to.owned or bPlan
    local trace = (hoverPath[a] and (hoverPath[b] or bActive)) or (hoverPath[b] and aActive)
    setLinkColor(link, trace and '#90b9c7' or (aActive and bActive and
      ((aPlan or bPlan) and '#dfc17b' or '#b88d42')) or '#443d30')
  end
end

local function passivePoints()
  for _, pool in ipairs(progress.pools or {}) do
    if pool.id == 'passive' then return pool.points or 0 end
  end
  return 0
end

refreshPlanner = function()
  if viewPool ~= 'passive' or not creedWindow then return end
  local panel = creedWindow:getChildById('plannerPanel')
  local controls = creedWindow:getChildById('planControls')
  -- Liczniki mieszkaja w stopce, a status planu przy przycisku, ktory go zatwierdza.
  local footer = creedWindow:getChildById('footer')
  local cost, count = planner and planner:getCost() or 0, planner and planner:getCount() or 0
  local available = passivePoints()
  footer:getChildById('balance'):setText(tr('Available points: %d', available))
  footer:getChildById('planCount'):setText(tr('Planned nodes: %d', count))
  footer:getChildById('planCost'):setText(tr('Plan cost: %d', cost))
  local status = readOnly and tr('Viewing allocated nodes') or planPending and tr('Applying plan...')
    or planMessage or (cost > available and tr('Need %d more points to apply', cost - available)
    or (count > 0 and tr('Ready to apply') or tr('Click a node to plan a path')))
  controls:getChildById('planStatus'):setText(status)
  local totals = {stats = {}, special = {}, mods = {}}
  if planner then
    for _, id in ipairs(planner:getIds()) do
      local node = tree.byId[id]
      for group, sums in pairs(totals) do
        for key, amount in pairs(node[group] or {}) do
          if type(amount) == 'number' then sums[key] = (sums[key] or 0) + amount end
        end
      end
    end
  end

  -- Bonus, ktory juz masz, nie powtarza sie nizej - szkic dopisuje sie do niego
  -- w nawiasie. W dolnej liscie zostaje wiec tylko to, czego jeszcze nie ma.
  -- Kupione leca kolorowanym tekstem: sama liczba dopisana przez szkic dostaje kolor
  -- listy planowanej, reszta linii zostaje w kolorze kupionych.
  local allocated, planned, allocatedLines = {}, {}, 0
  local function append(text, color)
    allocated[#allocated + 1] = text
    allocated[#allocated + 1] = color
  end
  for _, entry in ipairs(BONUS_LABELS) do
    local own = allocatedTotals[entry[1]][entry[2]]
    local draft = totals[entry[1]][entry[2]]
    if own and own ~= 0 then
      allocatedLines = allocatedLines + 1
      append((allocatedLines > 1 and '\n' or '') .. string.format(entry[3], own), ALLOCATED_COLOR)
      if draft and draft ~= 0 then
        append(string.format(' (%+d)', draft), PLANNED_COLOR)
      end
    elseif draft and draft ~= 0 then
      planned[#planned + 1] = string.format(entry[3], draft)
    end
  end

  -- Listy siedza w przewijanym panelu, wiec sa wnukami, nie dziecmi.
  local scroll = panel:getChildById('bonusesPanel')
  if allocatedLines > 0 then
    scroll:getChildById('allocated'):setColoredText(allocated)
  else
    scroll:getChildById('allocated'):setText(tr('Nothing allocated yet.'))
  end
  local hasPlan = #planned > 0
  scroll:getChildById('plannedSeparator'):setVisible(hasPlan)
  scroll:getChildById('plannedTitle'):setVisible(hasPlan)
  scroll:getChildById('bonuses'):setVisible(hasPlan)
  if hasPlan then
    scroll:getChildById('bonuses'):setText(table.concat(planned, '\n'))
  end
  controls:getChildById('undoButton'):setEnabled(planner ~= nil and not planPending and planner:canUndo())
  controls:getChildById('redoButton'):setEnabled(planner ~= nil and not planPending and planner:canRedo())
  controls:getChildById('clearButton'):setEnabled(count > 0 and not planPending)
  controls:getChildById('applyButton'):setEnabled(count > 0 and cost <= available and not planPending)
end

local function clearHover()
  hoverPath, hoverNode = {}, nil
  if refreshVisuals then refreshVisuals() end
end

local function hoverPlannerNode(node, hovered)
  if not planner or planPending or dragging then return end
  if not hovered then
    if hoverNode == node.id then clearHover() end
    return
  end
  hoverNode, hoverPath = node.id, {}
  local path = planner:pathTo(node.id)
  local cost = 0
  for _, id in ipairs(path or {}) do
    hoverPath[id] = true
    cost = cost + (tree.byId[id].cost or 1)
  end
  local detail = {node.name or '', node.info or ''}
  if node.effects and node.owned then
    local effect = node.effects[chosenIndex(node)]
    detail[#detail + 1] = tr('Chosen') .. ': ' .. (effect.name or '')
  end
  if node.owned then detail[#detail + 1] = tr('Already allocated')
  elseif planner:isPlanned(node.id) then detail[#detail + 1] = tr('Planned. Click again to remove this branch.')
  elseif path then detail[#detail + 1] = tr('%d nodes / %d points to this node', #path, cost)
  else detail[#detail + 1] = tr('No connected path') end
  creedWindow:getChildById('plannerPanel'):getChildById('nodeDetails'):setText(table.concat(detail, '\n'))
  refreshVisuals()
end

local function changePlan(action, id)
  if not planner or planPending then return end
  clearHover()
  planMessage = nil
  if action == 'toggle' then
    if planner:isPlanned(id) then planner:remove(id) else planner:add(id) end
  else
    planner[action](planner)
  end
  refreshVisuals()
  refreshPlanner()
end

-- Okno wyboru efektu mastery. Jedno na caly modul: drugie klikniecie przestawia
-- tresc zamiast otwierac kolejne okno.
local masteryWindow = nil

local function closeMasteryChoice()
  -- Okno mogl juz sprzatnac ktos inny (wyladowanie modulu, zniszczenie rodzica).
  -- Drugie destroy() na tym samym widgecie to ostrzezenie w logu klienta.
  if masteryWindow then
    if not masteryWindow:isDestroyed() then
      masteryWindow:destroy()
    end
    masteryWindow = nil
  end
end

local function openMasteryChoice(node)
  closeMasteryChoice()
  if not node.effects or #node.effects == 0 then return end
  masteryWindow = g_ui.createWidget('FateMasteryWindow', rootWidget)
  masteryWindow:getChildById('masteryName'):setText(node.name or '')
  local list = masteryWindow:getChildById('effects')
  for index, effect in ipairs(node.effects) do
    local entry = g_ui.createWidget('FateMasteryEffect', list)
    entry:getChildById('effectName'):setText(effect.name or '')
    entry:getChildById('effectInfo'):setText(effect.info or '')
    entry.onClick = function()
      closeMasteryChoice()
      if not planner or not planner:setChoice(node.id, index) then return end
      changePlan('toggle', node.id)
    end
  end
  masteryWindow:getChildById('cancelButton').onClick = closeMasteryChoice
  -- Escape zamyka wybor, tak jak w kazdym innym oknie klienta.
  masteryWindow.onEscape = closeMasteryChoice
end


-- Buduje widgety calego drzewka. Wolane tylko wtedy, gdy serwer przysle inny uklad
-- niz ten, ktory juz mamy - patrz signature w commitTree.
local function buildWidgets()
  cancelPan()
  local layout = pauseLayout()

  canvas:destroyChildren()
  nodeWidgets, labelWidgets, links, decorationWidgets = {}, {}, {}, {}
  chunks, chunkByKey, spatial = {}, {}, false

  local byId = {}
  for _, node in ipairs(tree.nodes) do
    byId[node.id] = node
  end

  -- Cached visuals are used only when the server sends the matching positions.
  -- Costs, connections, available nodes and purchases remain server-authoritative.
  local atlas = viewPool == 'passive' and FateLinkAtlas or nil
  if atlas and atlas.count == #tree.nodes then
    for _, node in ipairs(tree.nodes) do
      local position = atlas.nodes[node.id]
      if not position or math.abs(position[1] - node.x) > 0.000001
        or math.abs(position[2] - node.y) > 0.000001 then
        atlas = nil
        break
      end
    end
  else
    atlas = nil
  end
  -- Long/custom fallback connections stay in the flat renderer. Every spatial
  -- link must have exact cached bounds, including the curved circle segments.
  if atlas then
    for _, node in ipairs(tree.nodes) do
      for _, id in ipairs(node.requires or {}) do
        if not atlas.edges[id .. ':' .. node.id .. ':l'] then atlas = nil; break end
      end
      if not atlas or (node.ringPrevious and not atlas.edges[node.ringPrevious .. ':' .. node.id .. ':r']) then
        atlas = nil
        break
      end
    end
  end
  spatial = atlas ~= nil
  for _, node in ipairs(tree.nodes) do
    node.visualKind = atlas and atlas.visualKinds and atlas.visualKinds[node.id] or nil
  end
  for _, d in ipairs(atlas and atlas.decorations or {}) do
    local widget = createTreeWidget('FateDecoration', d.x, d.y, 'decor')
    widget:setImageSource('/modules/game_fate/pob/PSGroupBackground' .. d.kind .. (d.kind == 3 and 'Full' or ''))
    decorationWidgets[#decorationWidgets + 1] = {widget = widget, data = d}
  end
  local function cachedLink(link, kind)
    local clip = atlas and atlas.edges[link.from.id .. ':' .. link.to.id .. ':' .. kind]
    if not clip then return false end
    link.sprite = clip
    link.image = createTreeWidget('FateLink', clip[6] + (clip[8] or clip[4]) / 2,
      clip[7] + (clip[9] or clip[5]) / 2, 'links')
    link.image:setImageSource('/modules/game_fate/links/page-' .. clip[1] .. '.png')
    link.image:setImageClip({x = clip[2], y = clip[3], width = clip[4], height = clip[5]})
    return true
  end

  -- Najpierw polaczenia, zeby wezly rysowaly sie na nich.
  for _, node in ipairs(tree.nodes) do
    -- Wezel-klucz ma dwa wymagania i obie drogi musza wyjsc symetrycznie, inaczej
    -- to samo zakonczenie wyglada inaczej na dole drzewka niz z boku (sciezki to ta
    -- sama figura obrocona o 90 stopni). Ruszamy najpierw wzdluz tej osi, na ktorej
    -- oba ramiona maja wspolna wspolrzedna - wtedy skrety wypadaja lustrzanie.
    local horizontalFirst = false
    local requires = node.requires or {}
    if #requires > 1 then
      local first, second = byId[requires[1]], byId[requires[2]]
      horizontalFirst = first ~= nil and second ~= nil and first.x == second.x
    end

    for _, requiredId in ipairs(requires) do
      local from = byId[requiredId]
      if from then
        local link = {from = from, to = node, active = nil,
                      horizontalFirst = horizontalFirst}
        if viewPool == "passive" then
          if not cachedLink(link, 'l') then
            link.line = g_ui.createWidget('CreedLink', canvas)
          end
        elseif from.y ~= node.y then
          link.vertical = g_ui.createWidget('CreedLink', canvas)
        end
        if viewPool ~= "passive" and from.x ~= node.x then
          link.horizontal = g_ui.createWidget('CreedLink', canvas)
        end
        links[#links + 1] = link
      end
    end
  end

  if viewPool == 'passive' then
    for _, node in ipairs(tree.nodes) do
      local from = byId[node.ringPrevious]
      if from then
        local angle = polarAngle(from)
        local sweep = (polarAngle(node) - angle) % (2 * math.pi)
        local count = math.max(1, math.ceil(sweep / math.rad(2)))
        local link = {from = from, to = node, angle = angle, sweep = sweep,
                      radius = math.sqrt((node.x * GRID_X)^2 + (node.y * GRID_Y)^2)}
        if not cachedLink(link, 'r') then
          link.arc = {}
          for i = 1, count do link.arc[i] = g_ui.createWidget('CreedLink', canvas) end
        end
        links[#links + 1] = link
      end
    end
  end

  for _, node in ipairs(tree.nodes) do
    local widget = createTreeWidget(styleFor(node), node.x * GRID_X, node.y * GRID_Y, 'nodes')
    if viewPool == 'passive' and node.kind ~= 'root' then
      local icon = POB_ICONS[node.icon] and node.icon or POB_ICON_DEFAULT
      widget:setIcon('/modules/game_fate/pob/icon-' .. icon)
      widget.fateHasIcon = true
    elseif node.icon then
      widget:setImageSource('/images/ui/creed/passive/' .. node.icon)
    end
    widget.onClick = function(_, mousePos)
      if viewPool == 'passive' and g_keyboard.isCtrlPressed and g_keyboard.isCtrlPressed() then
        local pos = mousePos or {x = widget:getX() + widget:getWidth() / 2, y = widget:getY() + widget:getHeight() / 2}
        viewport.onMouseWheel(viewport, pos, MouseWheelUp)
        viewport.onMouseWheel(viewport, pos, MouseWheelUp)
        return
      end
      if readOnly or node.owned or node.kind == 'root' then return end
      if viewPool == 'passive' then
        -- Mastery wchodzi do planu dopiero z wybranym efektem, wiec zamiast od razu
        -- planowac, pytamy - chyba ze wezel juz jest w planie i klikniecie go zdejmuje.
        if node.effects and not (planner and planner:isPlanned(node.id)) then
          openMasteryChoice(node)
          return
        end
        changePlan('toggle', node.id)
      elseif node.available then
        send({action = 'buy', node = node.id})
      end
    end
    if viewPool == 'passive' then
      widget.onHoverChange = function(_, hovered) hoverPlannerNode(node, hovered) end
      -- Native dragging starts only on the pressed widget, not its parent.
      -- Forward node drags so the tree can be grabbed anywhere as in PoB.
      widget:setDraggable(true)
      widget.onDragEnter = function(_, pos) return viewport.onDragEnter(viewport, pos) end
      widget.onDragMove = function(_, pos, moved) return viewport.onDragMove(viewport, pos, moved) end
      widget.onDragLeave = function(_, target, pos) return viewport.onDragLeave(viewport, target, pos) end
    end
    nodeWidgets[node.id] = widget

    -- Podpisy dostaja tylko wezly z wlasna nazwa: notable i keystone'y. Male maja
    -- nazwe w dymku - przy 2507 sztukach podpisy zlalyby sie w kasze.
    if NODE_LABEL[node.visualKind or node.kind] then
      local label = createTreeWidget('CreedNodeLabel', node.x * GRID_X, node.y * GRID_Y, 'nodes')
      label:setText(node.name)
      labelWidgets[node.id] = label
    end
  end

  -- Keep the layout suspended until every size and anchor is ready.
  applyLayout()
  -- Native UILayout counts nested suspensions. applyLayout balances its own
  -- pause; release the outer build pause too, otherwise no node gets positioned.
  resumeLayout(layout)
end

local function clearTree()
  cancelPan()
  planner, planPending, planMessage = nil, false, nil
  hoverPath, hoverNode, searchMatches = {}, nil, {}
  tree = nil
  nodeWidgets, labelWidgets, links, decorationWidgets = {}, {}, {}, {}
  chunks, chunkByKey, spatial = {}, {}, false
  canvas:destroyChildren()
  if viewPool == 'passive' then
    local search = creedWindow:getChildById('toolbar'):getChildById('search')
    search:setText('')
    if search.onTextChange then search.onTextChange(search, '') end
  end
end

local function showMessage(text)
  local message = viewport:getChildById('message')
  message:setVisible(text ~= nil)
  if text then
    message:setText(text)
  end
end

-- ------------------------------------------------------------------
-- Odbior stanu
-- ------------------------------------------------------------------

-- Podpis ukladu: gdy sie nie zmienil, nie ma po co budowac widgetow od nowa
-- (otwarcie okna po raz drugi, ta sama wokacja).
local function signatureFor(nodes)
  local parts = {}
  for i, node in ipairs(nodes) do
    parts[i] = node.id .. ':' .. node.x .. ',' .. node.y .. ','
               .. (node.cost or 1) .. ',' .. (node.name or '') .. ','
               .. table.concat(node.requires or {}, ',') .. ',' .. (node.icon or '')
               .. ',' .. (node.sector or '') .. ',' .. (node.ringPrevious or '')
               .. ',' .. (node.kind or '') .. ',' .. (node.pool or '')
               .. ',' .. (node.info or '') .. ',' .. table.concat(node.neighbors or {}, ',')
  end
  return table.concat(parts, ';')
end

local function commitTree(allNodes)
  local nodes = {}
  for _, node in ipairs(allNodes) do
    if node.kind == 'root' or (node.pool or 'passive') == viewPool then
      nodes[#nodes + 1] = node
    end
  end
  local signature = signatureFor(nodes)
  if tree and tree.signature == signature then
    return refreshProgress()
  end

  assignBranchPalettes(nodes)
  local first = tree == nil
  tree = {nodes = nodes, signature = signature,
          byId = {}, minX = 0, maxX = 0, minY = 0, maxY = 0}
  for _, node in ipairs(nodes) do
    tree.byId[node.id] = node
    tree.minX = math.min(tree.minX, node.x)
    tree.maxX = math.max(tree.maxX, node.x)
    tree.minY = math.min(tree.minY, node.y)
    tree.maxY = math.max(tree.maxY, node.y)
  end
  planner = viewPool == 'passive' and not readOnly and FatePlanner.new(nodes) or nil
  hoverPath, hoverNode, searchMatches, planPending, planMessage = {}, nil, {}, false, nil

  showMessage(#nodes <= 1 and tr('No nodes in this tree yet.') or nil)
  if first then
    -- Fit small trees, but keep large-tree nodes readable and clickable.
    local width = (tree.maxX - tree.minX) * GRID_X + 100
    local height = (tree.maxY - tree.minY) * GRID_Y + 100
    zoom = math.max(0.35, math.min(1, (viewport:getWidth() - 30) / width,
                                      (viewport:getHeight() - 30) / height))
  end
  buildWidgets()
  refreshProgress()
  if viewPool == 'passive' then
    local toolbar = creedWindow:getChildById('toolbar')
    local search = toolbar:getChildById('search')
    search.onTextChange(search, searchText)
    toolbar:getChildById('zoomLabel'):setText(string.format('%d%%', math.floor(zoom * 100 + .5)))
  end

  -- Przy pierwszym drzewku centrujemy zawsze, potem tylko gdy go nie widac.
  if first or not treeVisible() then
    centerTree()
  end
end

local function onStateReceived(protocol, opcode, message)
  if type(message) ~= 'table' then
    return
  end

  if readOnly then
    if message.inspectTarget ~= inspectTarget or message.inspectSerial ~= inspectSerial then return end
  elseif message.inspectTarget then
    return
  end

  if message.t == 'empty' then
    pendingProgress = nil
    clearTree()
    progress = {pools = {}, vocation = message.vocation or '',
                owned = {}, available = {}, chosen = {}, canReset = false,
                hasResettableNodes = false}
    showMessage(message.message or tr('No Fate tree is available.'))
    refreshProgress()

  elseif message.t == 'begin' then
    incoming = {nodes = {}, count = message.count or 0}
    progress.vocation = message.vocation or progress.vocation

  elseif message.t == 'nodes' then
    if incoming then
      for _, node in ipairs(message.nodes or {}) do
        incoming.nodes[#incoming.nodes + 1] = node
      end
    end

  elseif message.t == 'done' then
    if incoming then
      -- Paczka po drodze nie ma prawa zginac (to jeden strumien TCP), ale gdyby
      -- serwer i klient rozjechaly sie na liczbie wezlow, lepiej to zobaczyc w logu
      -- niz rysowac polowe drzewka.
      if #incoming.nodes ~= (message.count or #incoming.nodes) then
        g_logger.warning(string.format(
          'creed: przyszlo %d wezlow zamiast %d', #incoming.nodes, message.count or -1))
      end
      commitTree(incoming.nodes)
      incoming = nil
    end

  elseif message.t == 'planResult' and viewPool == 'passive' and not readOnly then
    planPending = false
    planMessage = message.ok and tr('Plan applied') or (message.message or tr('The plan could not be applied.'))
    if message.ok and planner then planner:clear() end
    clearHover()
    refreshPlanner()

  elseif message.t == 'stateBegin' then
    pendingProgress = {pools = message.pools or {}, vocation = message.vocation,
                       canReset = message.canReset, hasResettableNodes = message.hasResettableNodes,
                       owned = {}, available = {}, chosen = message.chosen or {}}

  elseif message.t == 'stateNodes' then
    if pendingProgress and (message.list == 'owned' or message.list == 'available') then
      for _, id in ipairs(message.ids or {}) do
        local list = pendingProgress[message.list]
        list[#list + 1] = id
      end
    end

  elseif message.t == 'stateDone' then
    if pendingProgress then
      progress = pendingProgress
      pendingProgress = nil
      refreshProgress()
    end

  elseif message.t == 'state' then
    pendingProgress = nil
    progress.pools = message.pools or {}
    progress.vocation = message.vocation or progress.vocation
    progress.owned = message.owned or {}
    progress.available = message.available or {}
    progress.chosen = message.chosen or {}
    progress.canReset = message.canReset ~= false
    progress.hasResettableNodes = message.hasResettableNodes == true
    refreshProgress()
  end
end

-- ------------------------------------------------------------------
-- Okno
-- ------------------------------------------------------------------

-- Okno otwiera sie wylacznie przyciskiem Credo w oknie Character - swojej ikonki
-- w gornym menu Creed juz nie ma.
-- Zwiniecie do samego paska tytulu. Zapamietujemy wysokosc, bo okno da sie
-- rozciagac i nie ma sensu wracac do sztywnej wartosci.
local minimized = false
local savedHeight = nil
local savedPaddingBottom = nil

local function fitWindow()
  if viewPool ~= 'passive' or not creedWindow then return end
  local width = math.max(1, math.min(1120, rootWidget:getWidth() - 16))
  local height = math.max(1, math.min(720, rootWidget:getHeight() - 16))
  creedWindow:setWidth(width)
  if not minimized then creedWindow:setHeight(height) else savedHeight = height end
  local panel = creedWindow:getChildById('plannerPanel')
  panel:setWidth(width < 950 and 180 or 214)
  creedWindow:getChildById('toolbar'):getChildById('search'):setWidth(math.max(100, math.min(250, width - 580)))
end

local function toggleMinimize()
  cancelPan()
  dragging = false
  minimized = not minimized

  if minimized then
    savedHeight = creedWindow:getHeight()
    savedPaddingBottom = creedWindow:getPaddingBottom()
    viewport:hide()
    creedWindow:getChildById('footer'):hide()
    if viewPool == 'passive' then
      for _, id in ipairs({'plannerPanel', 'planControls', 'toolbar'}) do creedWindow:getChildById(id):hide() end
    end
    -- Dolne wypelnienie trzeba zdjac razem z wysokoscia. Obszar liczenia trafien
    -- to padding rect, wiec przy wysokosci 21 px i wypelnieniu 16 zostaloby z niego
    -- 5 px - przyciski byly widoczne, ale nie do klikniecia i okna nie dalo sie
    -- juz rozwinac. init() zeruje gorne wypelnienie, tu zerujemy dolne.
    creedWindow:setPaddingBottom(0)
    creedWindow:setHeight(creedWindow:getImageBorderTop() + creedWindow:getImageBorderBottom())
  else
    creedWindow:setPaddingBottom(savedPaddingBottom or 16)
    viewport:show()
    creedWindow:getChildById('footer'):show()
    if viewPool == 'passive' then
      for _, id in ipairs({'plannerPanel', 'toolbar'}) do creedWindow:getChildById(id):show() end
      creedWindow:getChildById('planControls'):setVisible(not readOnly)
    end
    creedWindow:setHeight(savedHeight or 600)
  end

  creedWindow:getChildById('minimizeButton'):setOn(minimized)
end

-- UIWindow:onDragEnter przepuszcza przeciaganie tylko gdy self.static jest falsem
local function toggleLock()
  creedWindow.static = not creedWindow.static
  creedWindow:getChildById('lockButton'):setOn(creedWindow.static)
end

local function toggle()
  if creedWindow:isVisible() then
    cancelPan()
    dragging = false
    clearHover()
    creedWindow:hide()
  else
    if not readOnly and viewPool == 'passive' then
      local player = g_game.getLocalPlayer()
      if not player or bit32.band(player:getStates(), PlayerStates.Pz) == 0 then return end
    end
    fitWindow()
    creedWindow:show()
    creedWindow:raise()
    creedWindow:focus()
    setPan(panX, panY)
    requestState()
  end
end

local function initView()
  g_ui.importStyle('fate')

  creedWindow = g_ui.createWidget(viewPool == 'passive' and 'FateWindow' or 'CreedWindow', rootWidget)
  creedWindow:hide()
  creedWindow:setId(readOnly and 'inspectFateWindow' or (viewPool == 'talent' and 'spellsWindow' or 'creedWindow'))
  creedWindow:setText(viewPool == 'talent' and tr('Spells') or tr('Fate'))
  creedWindow.onEscape = toggle

  viewport = creedWindow:getChildById('viewport')
  canvas = viewport:getChildById('canvas')

  -- UIWidget zaklada layout dopiero przy pierwszym dziecku, a bez layoutu nie da sie
  -- wylaczyc przeliczania ukladu na czas budowy drzewka - przy tysiacu widgetow to
  -- roznica miedzy mgnieniem a zawieszonym klientem. Jedno dziecko na chwile zalatwia
  -- sprawe raz na zawsze: destroyChildren layoutu juz nie kasuje.
  g_ui.createWidget('CreedLink', canvas):destroy()

  -- Swobodne przesuwanie plotna mysza. Tak samo robi to UIImageView w corelib.
  viewport.onDragEnter = function()
    flushPan()
    dragging = true
    clearHover()
    return true
  end
  viewport.onDragMove = function(widget, pos, moved)
    -- Native dragging can outlive Escape/minimize until the mouse is released.
    if not tree or not creedWindow or not creedWindow:isVisible() or not viewport:isVisible() then
      cancelPan()
      return true
    end
    pendingPanX, pendingPanY = pendingPanX + moved.x, pendingPanY + moved.y
    if not panEvent then panEvent = scheduleEvent(flushPan, PAN_FRAME_MS) end
    return true
  end
  viewport.onDragLeave = function(_, _, pos)
    flushPan()
    dragging = false
    -- Native hover callbacks fire only when the hovered widget changes. A
    -- dragged node can stay under the cursor throughout the gesture, so restore
    -- its preview on release even if no new hover event is generated.
    if pos and planner and creedWindow:isVisible() and viewport:isVisible() then
      for id, widget in pairs(nodeWidgets) do
        if (not widget.fateChunk or widget.fateChunk.visible)
          and pos.x >= widget:getX() and pos.x < widget:getX() + widget:getWidth()
          and pos.y >= widget:getY() and pos.y < widget:getY() + widget:getHeight() then
          hoverPlannerNode(tree.byId[id], true)
          break
        end
      end
    end
    return true
  end
  if viewPool == 'passive' then
    viewport.onClick = function(_, pos)
      if pos and g_keyboard.isCtrlPressed and g_keyboard.isCtrlPressed() then
        viewport.onMouseWheel(viewport, pos, MouseWheelUp)
        viewport.onMouseWheel(viewport, pos, MouseWheelUp)
      end
    end
    viewport.onMouseRelease = function(_, pos, button)
      if button == MouseButton4 then changePlan('undo'); return true end
      if button == MouseButton5 then changePlan('redo'); return true end
      if button == MouseRightButton and g_keyboard.isCtrlPressed and g_keyboard.isCtrlPressed() then
        viewport.onMouseWheel(viewport, pos, MouseWheelDown)
        viewport.onMouseWheel(viewport, pos, MouseWheelDown)
        return true
      end
      return false
    end
  end
  viewport.onGeometryChange = function()
    if tree then setPan(panX, panY) end
  end

  -- Zoom kolkiem. Punkt drzewka pod kursorem ma zostac pod kursorem, wiec po zmianie
  -- skali przesuwamy plotno tak, zeby to skompensowac - inaczej przy kazdym kliknieciu
  -- kolka drzewko uciekaloby w bok.
  viewport.onMouseWheel = function(widget, mousePos, direction)
    flushPan()
    if not tree then
      return true
    end

    local previous = zoom
    local step = ZOOM_STEP ^ (g_keyboard.isShiftPressed() and 3 or 1)
    if direction == MouseWheelUp then
      zoom = math.min(ZOOM_MAX, zoom * step)
    else
      zoom = math.max(ZOOM_MIN, zoom / step)
    end

    if zoom == previous then
      return true
    end

    -- Wspolrzedne drzewka (w kratkach) pod kursorem przed zmiana skali.
    local cx, cy = canvasCenter()
    local treeX = (mousePos.x - canvas:getX() - cx) / (GRID_X * previous)
    local treeY = (mousePos.y - canvas:getY() - cy) / (GRID_Y * previous)

    applyLayout(mousePos.x - viewport:getX() - viewport:getWidth() / 2 - treeX * gridX(),
                mousePos.y - viewport:getY() - viewport:getHeight() / 2 - treeY * gridY())
    if viewPool == 'passive' then
      creedWindow:getChildById('toolbar'):getChildById('zoomLabel'):setText(string.format('%d%%', math.floor(zoom * 100 + .5)))
    end
    return true
  end

  -- UIWidget::propagateOnMouseEvent przeglada dzieci TYLKO gdy kursor jest w
  -- padding rect rodzica. Pasek tytulu lezy nad nim, wiec przyciski wstawione w
  -- pasek byly widoczne, ale klikniecie szlo do okna zamiast do nich. Zerujemy
  -- wiec gorne wypelnienie i oddajemy je viewportowi jako margines: uklad
  -- wyglada tak samo, a pasek tytulu wchodzi w obszar trafien.
  local topPadding = creedWindow:getPaddingTop()
  local rightPadding = creedWindow:getPaddingRight()
  creedWindow:setPaddingTop(0)
  creedWindow:setPaddingRight(0)
  if viewPool == 'passive' then
    creedWindow:getChildById('toolbar'):setMarginTop(topPadding)
  else
    viewport:setMarginTop(topPadding)
  end
  viewport:setMarginRight(rightPadding)
  creedWindow:getChildById('footer'):setMarginRight(rightPadding)

  -- Wysokosc paska tytulu rozni sie miedzy layoutami (domyslny 27 px, retro 17),
  -- wiec przycisk centrujemy w nim wyliczeniem, a nie sztywna wartoscia.
  local closeButton = creedWindow:getChildById('closeButton')
  local titleBar = creedWindow:getImageBorderTop()
  closeButton:setMarginTop(math.max(1, math.floor((titleBar - closeButton:getHeight()) / 2)))

  closeButton.onClick = toggle
  creedWindow:getChildById('minimizeButton').onClick = toggleMinimize
  creedWindow:getChildById('lockButton').onClick = toggleLock

  local footer = creedWindow:getChildById('footer')
  footer:getChildById('centerButton').onClick = centerTree
  footer:getChildById('resetButton').onClick = function()
    if planPending then return end
    send({action = 'reset', pool = viewPool})
  end
  if viewPool == 'passive' then
    local controls = creedWindow:getChildById('planControls')
    controls:setVisible(not readOnly)
    controls:getChildById('undoButton').onClick = function() changePlan('undo') end
    controls:getChildById('redoButton').onClick = function() changePlan('redo') end
    controls:getChildById('clearButton').onClick = function() changePlan('clear') end
    controls:getChildById('applyButton').onClick = function()
      if not planner or planPending or planner:getCount() == 0 or planner:getCost() > passivePoints() then return end
      local encoded = planner:encode()
      if #encoded > 7600 then planMessage = tr('This plan is too large to send.'); refreshPlanner(); return end
      planPending, planMessage = true, nil
      clearHover()
      refreshPlanner()
      send({action = 'buyPlan', ranges = encoded, choices = planner:getChoices()})
    end
    footer:getChildById('fitButton').onClick = function()
      if not tree then return end
      cancelPan()
      local width = (tree.maxX - tree.minX) * GRID_X + 100
      local height = (tree.maxY - tree.minY) * GRID_Y + 100
      zoom = math.max(ZOOM_MIN, math.min(ZOOM_MAX, (viewport:getWidth() - 30) / width, (viewport:getHeight() - 30) / height))
      applyLayout(-(tree.minX + tree.maxX) * gridX() / 2, -(tree.minY + tree.maxY) * gridY() / 2)
      creedWindow:getChildById('toolbar'):getChildById('zoomLabel'):setText(string.format('%d%%', math.floor(zoom * 100 + .5)))
    end
    local toolbar = creedWindow:getChildById('toolbar')
    local searchResults, searchIndex = {}, 0
    toolbar:getChildById('search').onTextChange = function(_, text)
      searchText, searchMatches, searchResults, searchIndex = text:lower(), {}, {}, 0
      local terms = {}
      for term in searchText:gmatch('%S+') do terms[#terms + 1] = term end
      for _, node in ipairs(tree and tree.nodes or {}) do
        local haystack = ((node.name or '') .. ' ' .. (node.info or '')):lower()
        local match = #terms > 0
        for _, term in ipairs(terms) do if not haystack:find(term, 1, true) then match = false; break end end
        if match then searchMatches[node.id] = true; searchResults[#searchResults + 1] = node end
      end
      local open = 0
      for _, node in ipairs(searchResults) do
        if not node.owned then open = open + 1 end
      end
      toolbar:getChildById('searchCount'):setText(#searchResults > 0
        and tr('%d matches, %d open', #searchResults, open) or tr('%d matches', 0))
      refreshVisuals()
    end
    toolbar:getChildById('searchNext').onClick = function()
      if #searchResults == 0 then return end
      searchIndex = searchIndex % #searchResults + 1
      local node = searchResults[searchIndex]
      cancelPan()
      zoom = math.max(0.85, zoom)
      applyLayout(-node.x * gridX(), -node.y * gridY())
      toolbar:getChildById('zoomLabel'):setText(string.format('%d%%', math.floor(zoom * 100 + .5)))
    end
    if g_keyboard.bindKeyDown then
      g_keyboard.bindKeyDown('Ctrl+Z', function() changePlan('undo') end, creedWindow)
      g_keyboard.bindKeyDown('Ctrl+Y', function() changePlan('redo') end, creedWindow)
      g_keyboard.bindKeyDown('Ctrl+F', function() toolbar:getChildById('search'):focus() end, creedWindow)
      local function keyZoom(direction)
        viewport.onMouseWheel(viewport, {x = viewport:getX() + viewport:getWidth() / 2,
          y = viewport:getY() + viewport:getHeight() / 2}, direction)
      end
      g_keyboard.bindKeyDown('PageUp', function() keyZoom(MouseWheelUp) end, creedWindow)
      g_keyboard.bindKeyDown('PageDown', function() keyZoom(MouseWheelDown) end, creedWindow)
    end
    refreshPlanner()
    fitWindow()
    connect(rootWidget, {onGeometryChange = fitWindow})
  end
end

local function onGameEnd()
  closeMasteryChoice()
  inspectSerial = inspectSerial + 1
  inspectTarget = nil
  incoming = nil
  pendingProgress = nil
  if creedWindow then
    clearTree()
    if minimized then toggleMinimize() end
    creedWindow:hide()
    progress = {pools = {}, owned = {}, available = {}, chosen = {}, canReset = false}
    zoom = 1.0
  end
end

local function terminateView()
  cancelPan()
  if viewPool == 'passive' then disconnect(rootWidget, {onGeometryChange = fitWindow}) end

  if creedWindow then
    creedWindow:destroy()
    creedWindow = nil
  end
end

  local function inspect(target, name)
    if target == inspectTarget and creedWindow:isVisible() then
      toggle()
      return
    end
    inspectSerial = inspectSerial + 1
    inspectTarget = target
    incoming, pendingProgress = nil, nil
    clearTree()
    progress = {pools = {}, owned = {}, available = {}, chosen = {}, canReset = false}
    if minimized then toggleMinimize() end
    creedWindow:setText(tr('Fate') .. ' - ' .. name .. ' (' .. tr('Inspect') .. ')')
    showMessage(tr('Loading...'))
    refreshProgress()
    fitWindow()
    creedWindow:show()
    creedWindow:raise()
    creedWindow:focus()
    requestState()
  end

  initView()
  return {inspect = inspect, toggle = toggle, receive = onStateReceived, refresh = refreshProgress,
          logout = onGameEnd, destroy = terminateView}
end

local views = {}
local function onStateReceived(protocol, opcode, message)
  if type(message) ~= 'table' then return end
  if message.inspectTarget then
    if views.inspect then views.inspect.receive(protocol, opcode, message) end
  else
    views.passive.receive(protocol, opcode, message)
    views.talent.receive(protocol, opcode, message)
  end
end
local function refreshViews()
  for _, view in pairs(views) do view.refresh() end
end
function onGameEnd()
  for _, view in pairs(views) do view.logout() end
end
function toggle()
  if views.passive then views.passive.toggle() end
end
function inspect(target, name)
  if not views.inspect then views.inspect = createTreeView('passive', true) end
  views.inspect.inspect(target, name)
end
function toggleSpells()
  if views.talent then views.talent.toggle() end
end
function init()
  views.passive = createTreeView('passive')
  views.talent = createTreeView('talent')
  ProtocolGame.registerExtendedJSONOpcode(OPCODE, onStateReceived)
  connect(g_game, {onGameEnd = onGameEnd})
  connect(LocalPlayer, {onStatesChange = refreshViews})
end
function terminate()
  ProtocolGame.unregisterExtendedJSONOpcode(OPCODE)
  disconnect(g_game, {onGameEnd = onGameEnd})
  disconnect(LocalPlayer, {onStatesChange = refreshViews})
  for _, view in pairs(views) do view.destroy() end
  views = {}
end
