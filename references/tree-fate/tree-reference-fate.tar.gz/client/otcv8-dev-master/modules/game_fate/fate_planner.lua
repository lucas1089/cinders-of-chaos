-- Local Fate draft. No points are spent and no packets are sent here.
-- Keep the server's neighbor order: target-outward BFS chooses the same
-- shortest path (fewest new nodes, rather than lowest summed point cost).
FatePlanner = {}
local Model = {}
Model.__index = Model
local HISTORY_LIMIT = 64

local function validId(id)
  return type(id) == 'number' and id > 0 and id <= 2147483647 and id % 1 == 0
end

local function copySet(source)
  local result = {}
  for id in pairs(source) do result[id] = true end
  return result
end

local function sameSet(a, b)
  for id in pairs(a) do if not b[id] then return false end end
  for id in pairs(b) do if not a[id] then return false end end
  return true
end

local function pushHistory(stack, planned)
  stack[#stack + 1] = copySet(planned)
  if #stack > HISTORY_LIMIT then table.remove(stack, 1) end
end

function FatePlanner.new(nodes)
  local self = setmetatable({nodes = {}, order = {}, owned = {}, planned = {},
    undoStack = {}, redoStack = {}, count = 0, cost = 0}, Model)
  local accepted = {}
  for _, node in ipairs(type(nodes) == 'table' and nodes or {}) do
    if type(node) == 'table' and validId(node.id) and not self.nodes[node.id]
        and node.pool == 'passive' and not node.subclass
        and type(node.neighbors) == 'table' then
      local cost = node.cost == nil and 1 or node.cost
      if type(cost) == 'number' and cost >= 0 and cost < math.huge and cost % 1 == 0 then
        self.nodes[node.id] = {id = node.id, cost = cost,
          granted = node.granted == true or (node.kind == 'root' and cost == 0),
          neighbors = {}}
        self.order[#self.order + 1] = node.id
        accepted[#accepted + 1] = node
      end
    end
  end
  -- Copy graph data so presentation changes never mutate the planner. Fate
  -- supplies both directions of every edge; requires is deliberately unused.
  for _, node in ipairs(accepted) do
    local localNode, seen = self.nodes[node.id], {}
    for _, id in ipairs(node.neighbors) do
      if validId(id) and self.nodes[id] and id ~= node.id and not seen[id] then
        localNode.neighbors[#localNode.neighbors + 1] = id
        seen[id] = true
      end
    end
  end
  table.sort(self.order)
  self:setOwned({})
  return self
end

function Model:recount()
  self.count, self.cost = 0, 0
  for id in pairs(self.planned) do
    self.count = self.count + 1
    self.cost = self.cost + self.nodes[id].cost
  end
end

function Model:prune()
  local reached, queue, head = {}, {}, 1
  for _, id in ipairs(self.order) do
    if self.owned[id] then
      reached[id] = true
      queue[#queue + 1] = id
    end
  end
  while head <= #queue do
    local node = self.nodes[queue[head]]
    head = head + 1
    for _, id in ipairs(node.neighbors) do
      if not reached[id] and (self.owned[id] or self.planned[id]) then
        reached[id] = true
        queue[#queue + 1] = id
      end
    end
  end
  for id in pairs(self.planned) do
    if not reached[id] or self.owned[id] then self.planned[id] = nil end
  end
  self:recount()
end

-- Reconcile purchases/resets without losing an unrelated, connected draft.
-- Repeated identical server state leaves undo/redo history intact.
function Model:setOwned(ids)
  local owned = {}
  for _, id in ipairs(self.order) do
    if self.nodes[id].granted then owned[id] = true end
  end
  if type(ids) == 'table' then
    for key, value in pairs(ids) do
      local id = value == true and key or value
      if validId(id) and self.nodes[id] then owned[id] = true end
    end
  end
  if sameSet(self.owned, owned) then return false end
  self.owned = owned
  self:prune()
  self.undoStack, self.redoStack = {}, {}
  return true
end

-- IDs are in purchase order from the nearest owned/planned endpoint.
-- {} means the target is already selected; nil means it cannot be reached.
function Model:pathTo(id)
  if not validId(id) or not self.nodes[id] then return nil end
  if self.owned[id] or self.planned[id] then return {} end
  local queue, head, visited, nextId = {id}, 1, {[id] = true}, {}
  local endpoint
  while head <= #queue and not endpoint do
    local current = queue[head]
    head = head + 1
    for _, adjacent in ipairs(self.nodes[current].neighbors) do
      if not visited[adjacent] then
        visited[adjacent] = true
        nextId[adjacent] = current
        if self.owned[adjacent] or self.planned[adjacent] then
          endpoint = adjacent
          break
        end
        queue[#queue + 1] = adjacent
      end
    end
  end
  if not endpoint then return nil end
  local path, current = {}, nextId[endpoint]
  while current do
    path[#path + 1] = current
    current = nextId[current]
  end
  return path
end

function Model:add(id)
  local path = self:pathTo(id)
  if not path or #path == 0 then return false end
  pushHistory(self.undoStack, self.planned)
  self.redoStack = {}
  for _, selected in ipairs(path) do self.planned[selected] = true end
  self:recount()
  return true
end

function Model:remove(id)
  if not validId(id) or not self.planned[id] then return false end
  pushHistory(self.undoStack, self.planned)
  self.redoStack = {}
  self.planned[id] = nil
  self:prune()
  return true
end

function Model:clear()
  if self.count == 0 then return false end
  pushHistory(self.undoStack, self.planned)
  self.redoStack = {}
  self.planned = {}
  self:recount()
  return true
end

function Model:undo()
  if not self:canUndo() then return false end
  pushHistory(self.redoStack, self.planned)
  self.planned = table.remove(self.undoStack)
  self:recount()
  return true
end

function Model:redo()
  if not self:canRedo() then return false end
  pushHistory(self.undoStack, self.planned)
  self.planned = table.remove(self.redoStack)
  self:recount()
  return true
end

function Model:canUndo() return #self.undoStack > 0 end
function Model:canRedo() return #self.redoStack > 0 end
function Model:isPlanned(id) return validId(id) and self.planned[id] == true end

-- Wybor efektu mastery. Plan trzyma go lokalnie i oddaje przy zatwierdzeniu; wezel
-- bez wyboru serwer odrzuci, wiec planer nie pozwala go zaplanowac bez numeru.
function Model:setChoice(id, choice)
  if not validId(id) or type(choice) ~= 'number' or choice ~= math.floor(choice)
      or choice < 1 then
    return false
  end
  self.choices = self.choices or {}
  self.choices[id] = choice
  return true
end

function Model:getChoice(id)
  return validId(id) and self.choices and self.choices[id] or nil
end

-- Tylko wybory wezlow, ktore naprawde sa w planie - reszta nie ma po co jechac
-- do serwera, a po usunieciu wezla z planu jego wybor traci znaczenie.
function Model:getChoices()
  local out = {}
  for id, choice in pairs(self.choices or {}) do
    if self.planned[id] then out[tostring(id)] = choice end
  end
  return out
end
function Model:getCount() return self.count end
function Model:getCost() return self.cost end
function Model:getSummary() return {count = self.count, cost = self.cost} end

function Model:getIds()
  local ids = {}
  for _, id in ipairs(self.order) do
    if self.planned[id] then ids[#ids + 1] = id end
  end
  return ids
end

-- Ranges are convenient for complete branches; a bitmap bounds packet size
-- for fragmented plans. Each hex digit lists four IDs, low bit first.
function Model:encode()
  local ids, ranges, index = self:getIds(), {}, 1
  while index <= #ids do
    local first, last = ids[index], ids[index]
    while ids[index + 1] == last + 1 do
      index = index + 1
      last = ids[index]
    end
    ranges[#ranges + 1] = first == last and tostring(first) or (first .. '-' .. last)
    index = index + 1
  end
  local encoded = table.concat(ranges, ',')
  if #ids == 0 then return encoded end
  local base = ids[1]
  local prefix = '@' .. base .. ':'
  local digits = math.floor((ids[#ids] - base) / 4) + 1
  if #prefix + digits >= #encoded then return encoded end
  local nibbles, hex = {}, '0123456789abcdef'
  for _, id in ipairs(ids) do
    local offset = id - base
    local index = math.floor(offset / 4) + 1
    nibbles[index] = (nibbles[index] or 0) + 2 ^ (offset % 4)
  end
  local bitmap = {}
  for index = 1, digits do
    local nibble = nibbles[index] or 0
    bitmap[index] = hex:sub(nibble + 1, nibble + 1)
  end
  return prefix .. table.concat(bitmap)
end

return FatePlanner
