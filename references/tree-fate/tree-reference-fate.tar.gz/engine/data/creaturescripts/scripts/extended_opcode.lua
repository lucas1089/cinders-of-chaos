local OPCODE_LANGUAGE = 1
local OPCODE_ITEM_TOOLTIP = 61
local OPCODE_CREED = 62
local OPCODE_LOOT_RARITY = 65
local OPCODE_QUEST_DIALOG = 67
local QUEST_NPC_POSITION = Position(4134, 2948, 6)
local QUEST_TWO_STORAGE = 1002

-- Limity odpowiedzi o rzadkosci. NetworkMessage::addString po cichu NIC nie zapisuje,
-- gdy tekst przekroczy 8192 bajty - pakiet wychodzi wtedy uszkodzony i klient nie ma
-- jak tego zauwazyc. Zostawiamy zapas na obudowe wiadomosci.
local LOOT_RARITY_MAX_BYTES = 6000
local LOOT_RARITY_MAX_TILES = 24
local LOOT_RARITY_MAX_ITEMS = 8

-- Jak daleko od gracza wolno pytac o przedmiot. Pokrywa widok (32x22 kratek) z zapasem;
-- bez tego dalo by sie skanowac mape spoza pola widzenia.
local TOOLTIP_MAX_RANGE_X = 17
local TOOLTIP_MAX_RANGE_Y = 12

-- Migawki linkow sa wspolne dla graczy, ale ich zawartosc ustala tylko serwer.
local ITEM_LINK_LIMIT = 4096
local ITEM_LINK_TTL = 24 * 60 * 60
local itemLinks, itemLinkSlots, nextItemLink = {}, {}, 0
local itemLinkEpoch = tostring(os.time())
local lastItemShare = {}

-- ------------------------------------------------------------------
-- Ogranicznik drogich zadan
-- ------------------------------------------------------------------
--
-- Limit pakietow z config.lua liczy sztuki, nie koszt - a nasze wlasne opcody nie sa
-- rownej ceny. Pelny opis drzewka Fate to dzis 187 pakietow, ~877 KB i ~250 ms pracy,
-- wiec przerobiony klient moglby prosic o niego bez przerwy i zajac serwer sam jeden.
--
-- Kazde drogie zadanie dostaje wiec wlasny kubelek zetonow, liczony osobno dla kazdego
-- gracza: pojemnosc to dopuszczalna seria (klient marketu potrafi zapytac o kilkanascie
-- ofert z rzedu), a tempo dolewania - ile wolno srednio na sekunde.
local REQUEST_LIMITS = {
	-- Pelne drzewko: otwarcie obu okien z rzedu ma przejsc, reszta czeka.
	fateTree = {capacity = 2, perSecond = 0.5},
	-- Zapytania marketu ida do bazy; klient prefetchuje po kilka na raz.
	marketTooltip = {capacity = 40, perSecond = 5},
	-- Opis przedmiotu spod kursora - klient sam trzyma 500 ms odstepu.
	itemTooltip = {capacity = 10, perSecond = 4},
	-- Rzadkosc lootu na kratkach wokol gracza.
	lootRarity = {capacity = 10, perSecond = 4},
}

local requestBuckets = {}

-- Zwraca true, gdy zadanie wolno obsluzyc teraz. Przy odmowie oddaje takze czas
-- w milisekundach do nastepnego zetonu - dzieki temu wywolujacy moze zadanie
-- odlozyc zamiast je gubic.
local function allowRequest(player, kind)
	local limit = REQUEST_LIMITS[kind]
	if not limit then
		return true, 0
	end

	local bucket = requestBuckets[kind]
	if not bucket then
		bucket = {}
		requestBuckets[kind] = bucket
	end

	local id = player:getId()
	local now = os.mtime()
	local entry = bucket[id]
	if not entry then
		entry = {tokens = limit.capacity, time = now}
		bucket[id] = entry
	end

	entry.tokens = math.min(limit.capacity,
		entry.tokens + (now - entry.time) * limit.perSecond / 1000)
	entry.time = now
	if entry.tokens < 1 then
		return false, math.ceil((1 - entry.tokens) * 1000 / limit.perSecond)
	end
	entry.tokens = entry.tokens - 1
	return true, 0
end

-- Gracz wychodzi - jego kubelki nie maja po co zostawac.
function forgetRequestLimits(player)
	local id = player:getId()
	for _, bucket in pairs(requestBuckets) do
		bucket[id] = nil
	end
end

local function integer(value, minimum, maximum)
	value = tonumber(value)
	if not value or value ~= value or value < minimum or value > maximum or value % 1 ~= 0 then
		return nil
	end
	return value
end

-- Klient przysyla pozycje, id i stackpos - dokladnie to, czym posluguje sie natywne
-- "look". Dla plecaka i ekwipunku sa to pseudo-pozycje z x = 0xFFFF, wiec jedna
-- funkcja obsluguje ziemie, kontenery i sloty.
local function resolveItem(player, request)
	local x = integer(request.x, 0, 65535)
	local y = integer(request.y, 0, 65535)
	local z = integer(request.z, 0, 255)
	if not x or not y or not z then
		return nil
	end

	if x ~= 0xFFFF then
		local pos = player:getPosition()
		if pos.z ~= z or math.abs(pos.x - x) > TOOLTIP_MAX_RANGE_X
			or math.abs(pos.y - y) > TOOLTIP_MAX_RANGE_Y then
			return nil
		end

		local tile = Tile(Position(x, y, z))
		local stack = integer(request.stack or 0, 0, 255)
		return tile and stack and tile:getThing(stack)
	end

	if bit.band(y, 0x40) ~= 0 then
		local containerId = bit.band(y, 0x0F)
		local container = player:getContainerById(containerId)
		return container and container:getItem(player:getContainerIndex(containerId) + z)
	end

	return y >= CONST_SLOT_HEAD and y <= CONST_SLOT_LAST and y ~= CONST_SLOT_STORE_INBOX and player:getSlotItem(y) or nil
end

-- Podpis pod nazwa przedmiotu. Najpierw typ broni, potem slot - to, co gracz
-- najszybciej rozpoznaje.
local TOOLTIP_WEAPON_NAMES = {
	[WEAPON_SWORD] = "Sword",
	[WEAPON_CLUB] = "Club",
	[WEAPON_AXE] = "Axe",
	[WEAPON_DISTANCE] = "Distance",
	[WEAPON_SHIELD] = "Shield",
	[WEAPON_WAND] = "Wand",
	[WEAPON_AMMO] = "Ammunition"
}

local TOOLTIP_SLOT_NAMES = {
	{SLOTP_HEAD, "Helmet"},
	{SLOTP_ARMOR, "Armor"},
	{SLOTP_LEGS, "Legs"},
	{SLOTP_BELT, "Belt"},
	{SLOTP_FEET, "Boots"},
	{SLOTP_NECKLACE, "Amulet"},
	{SLOTP_RING, "Ring"},
	{SLOTP_POTION, "Potion"},
	{SLOTP_AMMO, "Ammunition"}
}

local function tooltipCategory(itemType)
	local weaponName = TOOLTIP_WEAPON_NAMES[itemType:getWeaponType()]
	if weaponName then
		return weaponName
	end

	local slot = itemType:getSlotPosition()
	for _, entry in ipairs(TOOLTIP_SLOT_NAMES) do
		if bit.band(slot, entry[1]) ~= 0 then
			return entry[2]
		end
	end

	if itemType:isContainer() then
		return "Container"
	end
	return nil
end

local function tooltipSkills(itemType)
	local abilities = itemType:getAbilities()
	if not abilities or not abilities.skills then
		return nil
	end

	local bonuses = nil
	-- tablica skills jest 1-based, wiec skill o id N siedzi pod indeksem N + 1.
	-- SKILL_FIRST/SKILL_LAST nie sa wystawione do Lua - jedziemy po konkretnych stalych.
	for skill = SKILL_ATTACKSPEED, SKILL_FISHING do
		local value = abilities.skills[skill + 1]
		if value and value ~= 0 then
			bonuses = bonuses or {}
			bonuses[#bonuses + 1] = {name = getSkillName(skill), value = value}
		end
	end
	return bonuses
end

local function buildItemTooltip(thing, key)
 local itemType = ItemType(thing:getId())
	local count = thing:getCount() or 1
	local weight = itemType:getWeight()
	if itemType:isStackable() and count > 1 then
		weight = weight * count
	end

	-- Staty czytamy z przedmiotu, nie z typu: Item:getAttack() i spolka zwracaja juz
	-- baze razem z afiksami tej sztuki (Item::getMods). Same afiksy ida osobno, jako
	-- lista linii do wypisania pod statami.
	RARITY.normalizeName(thing)
	local rarity = RARITY.describe(thing)

	return {
		key = key,
		name = thing:getName(),
		instanceId = thing:getInstanceId(),
		clientId = itemType:getClientId(),
		frameCode = thing:getClientFrame(),
		count = count,
		category = tooltipCategory(itemType),
		-- Bron zadaje obrazenia z przedzialu (model z PoE), wiec zamiast jednej liczby
		-- podajemy oba konce. Klient sklada z nich wiersz "Physical Damage  X - Y".
		attackMin = thing:getAttackMin(),
		attackMax = thing:getAttackMax(),
		defense = thing:getDefense(),
		extraDefense = thing:getExtraDefense(),
		armor = thing:getArmor(),
		skills = tooltipSkills(itemType),
		weight = weight > 0 and string.format("%.2f oz", weight / 100) or nil,
		description = itemType:getDescription(),
		rarity = rarity.key,
		rarityName = rarity.name,
		rarityColor = rarity.color,
		affixes = #rarity.lines > 0 and rarity.lines or nil
	}
end

-- Both world items and escrow snapshots pass through the same tooltip builder.
local function marketItemInfo(row, history, buyOrder)
 local itemId, amount = result.getNumber(row, "itemtype"), result.getNumber(row, "amount")
 local attributes = result.getString(row, "attributes") or ""
 local item = Game.restoreMarketItem(itemId, math.min(amount, 100), attributes)
 if not item then return nil end
 local info = buildItemTooltip(item)
 if buyOrder then
  info.instanceId = nil
  info.description = "Buy order. The exact item is determined when the order is fulfilled."
 elseif history and #attributes == 0 then
  info.instanceId = nil
  info.description = "Historical attributes were not recorded for this offer. Base item shown."
 elseif not history then
  -- Backfill existing escrow instances once, keeping the assigned identity across purchases.
  local saved = item:getSerializedAttributes()
  if saved ~= attributes then
   if not db.query("UPDATE market_offers SET attributes=" .. db.escapeString(saved) .. " WHERE id=" .. result.getNumber(row,"id")) then
    item:remove()
    return nil
   end
  end
 end
 info.count = amount
 item:remove()
 return info
end

-- Filter per recipient; shared chat snapshots must keep their original data.
local function tooltipForViewer(player, info)
 if not info or (player.getAccountType and player:getAccountType() >= ACCOUNT_TYPE_GOD) then return info end
 local public = {}
 for key, value in pairs(info) do
  if key ~= "instanceId" then public[key] = value end
 end
 return public
end

-- Strona listy ofert/historii odrzucona przez limit nie moze po prostu zniknac: klient
-- czeka na pakiet `done` i bez niego lista wisi. Odkladamy ja wiec do odnowienia
-- kubelka - jedna oczekujaca strona na gracza i rodzaj listy, ostatnia wygrywa.
local pendingMarketList = {}
local handleMarketTooltip

local function deferMarketList(player, request, wait)
 local playerId = player:getId()
 local key = playerId .. ":" .. tostring(request.kind)
 local alreadyWaiting = pendingMarketList[key] ~= nil
 pendingMarketList[key] = request
 if alreadyWaiting then return end
 addEvent(function(id, pendingKey)
  local pending = pendingMarketList[pendingKey]
  pendingMarketList[pendingKey] = nil
  local target = Player(id)
  if target and pending then handleMarketTooltip(target, pending) end
 end, math.max(50, wait), playerId, key)
end

handleMarketTooltip = function(player, request)
 local function send(data)
  data.action, data.key = request.action, request.key
  if data.info then data.info = tooltipForViewer(player, data.info) end
  if data.entry and data.entry.info then data.entry.info = tooltipForViewer(player, data.entry.info) end
  player:sendExtendedOpcode(OPCODE_ITEM_TOOLTIP, json.encode(data))
 end
 if request.action == "market" then
  -- Kazde takie zapytanie idzie do bazy, wiec ma wlasny limit. Klient prefetchuje
  -- po kilka ofert naraz - stad kubelek z zapasem zamiast sztywnego odstepu.
  if not allowRequest(player, "marketTooltip") then return end
  local timestamp, counter = integer(request.timestamp, 1, 4294967295), integer(request.counter, 0, 65535)
  if not timestamp or not counter then return end
  local created = timestamp - configManager.getNumber(configKeys.MARKET_OFFER_DURATION)
  local row = db.storeQuery("SELECT id,itemtype,amount,attributes FROM market_offers WHERE sale=1 AND created=" .. created .. " AND (id & 65535)=" .. counter .. " LIMIT 1")
  if not row then send({info={name="Offer no longer available."}}); return end
  local info = marketItemInfo(row, false)
  result.free(row)
  if info then send({info=info}) end
  return
 end
 local history = request.kind == "history"
 if not history and request.kind ~= "own" then return end
 local allowed, wait = allowRequest(player, "marketTooltip")
 if not allowed then deferMarketList(player, request, wait); return end
 local after = request.after and integer(request.after,1,4294967295)
 if request.after and not after then return end
 local tableName = history and "market_history" or "market_offers"
 local fields = history and "expires_at AS timestamp,state" or "created,anonymous"
 local query = "SELECT id,itemtype,amount,price,sale,attributes," .. fields .. " FROM " .. tableName .. " WHERE player_id=" .. player:getGuid()
 if after then query = query .. " AND id<" .. after end
 local row = db.storeQuery(query .. " ORDER BY id DESC LIMIT 100")
 local count, last = 0, nil
 if row then
  repeat
   count, last = count + 1, result.getNumber(row,"id")
   local info = marketItemInfo(row, history, not history and result.getNumber(row,"sale") == 0)
   if info then
    local timestamp = history and result.getNumber(row,"timestamp") or (result.getNumber(row,"created") + configManager.getNumber(configKeys.MARKET_OFFER_DURATION))
    send({kind=request.kind, entry={id=last, timestamp=timestamp, counter=last%65536,
     amount=result.getNumber(row,"amount"), price=result.getNumber(row,"price"),
     sale=result.getNumber(row,"sale"), state=history and result.getNumber(row,"state") or nil, info=info}})
   end
  until not result.next(row)
  result.free(row)
 end
 send({kind=request.kind, done=true, more=count==100, after=last})
end

local function handleItemTooltip(player, buffer)
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" or type(request.key) ~= "string" or #request.key > 128 then
		return
	end

	-- Najpierw rozpoznanie akcji, potem WLASCIWY kubelek. Wczesniej kazde zadanie
	-- placilo najpierw z malego itemTooltip (10 w serii), a market dopiero potem ze
	-- swojego (40) - z 40 dozwolonych zapytan marketu przechodzilo 10, a strony list
	-- gubily sie bez konczacego `done`.
	if request.action == "market" or request.action == "marketList" then
		handleMarketTooltip(player, request)
		return
	end
	if not allowRequest(player, "itemTooltip") then
		return
	end
	if request.action == "link" then
		local link = type(request.token) == "string" and itemLinks[request.token]
		if link and os.time() - link.created <= ITEM_LINK_TTL then
			player:sendExtendedOpcode(OPCODE_ITEM_TOOLTIP, json.encode({
				key = request.key, action = "link", info = tooltipForViewer(player, link.info)
			}))
		else
			player:sendExtendedOpcode(OPCODE_ITEM_TOOLTIP, json.encode({
				key = request.key, action = "link", info = {name = "Item preview expired."}
			}))
		end
		return
	end
	if request.action and request.action ~= "share" then return end
	if request.action == "share" then
		local now = os.time()
		for id, time in pairs(lastItemShare) do
			if time < now then lastItemShare[id] = nil end
		end
		if lastItemShare[player:getId()] then return end
		lastItemShare[player:getId()] = now
	end

	local thing = resolveItem(player, request)
	if not thing or not thing:isItem() then
		return
	end

	local itemType = ItemType(thing:getId())
	-- Podlogi, sciany i inne nieruchome elementy nie dostaja podpowiedzi. Klient
	-- filtruje je juz u siebie, ale nie ufamy mu na slowo.
	if not itemType:isPickupable() then
		return
	end
	if request.action == "share" and request.clientId ~= itemType:getClientId() then return end

	local info = buildItemTooltip(thing, request.key)

	if request.action == "share" then
		nextItemLink = nextItemLink + 1
		local token = itemLinkEpoch .. "-" .. nextItemLink
		local slot = (nextItemLink - 1) % ITEM_LINK_LIMIT + 1
		if itemLinkSlots[slot] then itemLinks[itemLinkSlots[slot]] = nil end
		itemLinkSlots[slot] = token
		itemLinks[token] = {created = os.time(), info = info}
		player:sendExtendedOpcode(OPCODE_ITEM_TOOLTIP, json.encode({
			action = "share", key = request.key, token = token,
			name = info.name:gsub("[%[%]\r\n]", ""):sub(1, 100)
		}))
	else
		player:sendExtendedOpcode(OPCODE_ITEM_TOOLTIP, json.encode(tooltipForViewer(player, info)))
	end
end

local function handleSkillPoints(player, buffer)
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" then
		return
	end

	if request.action == "inspect" then
		local id = integer(request.target, 1, 4294967295)
		local serial = integer(request.serial, 1, 2147483647)
		if not id or not serial then return end
		local target = Player(id)
		if not target or not player:canSee(target:getPosition()) or not player:canSeeCreature(target) then
			player:sendExtendedOpcode(SKILL_POINTS.opcode, json.encode({action = "inspect", target = id, serial = serial, error = true}))
			player:sendCancelMessage("You cannot inspect this player.")
			return
		end
		local state = target:getSkillPointsState()
		-- The public Info sheet does not expose point allocation or private balances.
		state.stats, state.points, state.canReset = nil, nil, nil
		state.action, state.target, state.serial = "inspect", id, serial
		state.speed = target:getSpeed()
		state.skills, state.equipment = {}, {}
		-- FIRST/LAST are C++ enum aliases and are not exported to Lua.
		for index, skill in ipairs({SPECIALSKILL_CRITICALHITCHANCE, SPECIALSKILL_CRITICALHITAMOUNT,
			SPECIALSKILL_LIFELEECHCHANCE, SPECIALSKILL_LIFELEECHAMOUNT,
			SPECIALSKILL_MANALEECHCHANCE, SPECIALSKILL_MANALEECHAMOUNT}) do
			-- Silnik liczy w setnych procenta, okno pokazuje pelne procenty.
			state.skills[tostring(6 + index)] = math.floor(target:getSpecialSkill(skill) / 100)
		end
		for _, slot in ipairs({1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15}) do
			local item = target:getSlotItem(slot)
			if item then
				state.equipment[tostring(slot)] = {clientId = ItemType(item:getId()):getClientId(), count = item:getSubType(), frameCode = item:getClientFrame(),
					tooltipInfo = tooltipForViewer(player, buildItemTooltip(item))}
			end
		end
		-- Thirteen complete item snapshots can exceed addString's 8192-byte
		-- limit. OTCv8's JSON handler reassembles S/P/E chunks before dispatch.
		local payload = json.encode(state)
		if #payload <= 6000 then
			player:sendExtendedOpcode(SKILL_POINTS.opcode, payload)
		else
			for offset = 1, #payload, 6000 do
				local prefix = offset == 1 and 'S' or (offset + 6000 > #payload and 'E' or 'P')
				player:sendExtendedOpcode(SKILL_POINTS.opcode, prefix .. payload:sub(offset, offset + 5999))
			end
		end
		return
	end

	if request.action == "spend" then
		local stat = SKILL_POINTS.stats[tonumber(request.stat) or 0]
		if not stat then
			return
		end

		local amount = math.floor(tonumber(request.amount) or 1)
		local spent, reason = player:spendSkillPoints(stat, math.max(1, amount))
		if spent < 1 and reason then
			player:sendCancelMessage(reason)
		end
	elseif request.action == "reset" then
		if request.pool ~= nil and not CREED.pools[request.pool] then
			return
		end
		local allowed, reason = player:canResetSkillPoints()
		if not allowed then
			player:sendCancelMessage(reason)
			return
		end
		player:resetSkillPoints()
	end

	-- Na kazde zapytanie odsylamy pelny stan - klient nie liczy niczego sam.
	player:sendSkillPointsState()
end

-- Stan drzewka: klient nie zna go wcale, wiec dostaje komplet - wezly, ich pozycje
-- na siatce, wymagania i to, ktore sa juz kupione albo osiagalne.
--
-- Drzewko ma kilkaset wezlow, a jedna wiadomosc extended opcode to najwyzej 8192 bajty:
-- NetworkMessage::addString powyzej tego **po cichu nie wysyla nic** (patrz networkmessage.cpp).
-- Statyczny opis leci wiec paczkami "nodes" miedzy "begin" a "done". To, co sie zmienia
-- przy kupowaniu - punkty i listy id: kupionych oraz osiagalnych - miesci sie zawsze
-- w jednej wiadomosci "state", wiec po kliknieciu wezla nie przesylamy calego drzewka.
local CREED_CHUNK_BYTES = 5000

local function creedNodePayload(node)
	return {
		id = node.id,
		x = node.x,
		y = node.y,
		name = node.name,
		info = node.info,
		-- Trzy rodzaje bonusow - klient sumuje je w planerze (patrz BONUS_LABELS
		-- w modules/game_fate/fate.lua). Opis w dymku bierze sie z "info".
		stats = node.stats,
		special = node.special,
		mods = node.mods,
		-- Mastery: lista efektow do wyboru. Numer na liscie jest numerem wyboru
		-- wysylanym przy kupnie, wiec kolejnosc musi byc ta sama po obu stronach.
		effects = node.effects,
		cost = node.cost or 1,
		-- Starsze drzewka nie maja "kind", wiec wyliczamy je z tego, co jest.
		kind = node.kind or (node.subclass and "gate" or "small"),
		-- Z ktorej puli platny (klient rysuje "talent" jako kwadraty, "passive" jako kola).
		pool = CREED.poolOf(node),
		-- Opcjonalna grafika przykladowego noda passive.
		icon = node.icon,
		requires = node.requires,
        neighbors = node.neighbors,
        sector = node.sector,
        ringLevel = node.ringLevel,
        ringPrevious = node.ringPrevious
	}
end

-- Sam postep, bez opisu drzewka. Dwie listy id zamiast flagi przy kazdym wezle -
-- osiagalne sa tylko te na granicy kupionych, wiec obie listy sa krotkie.
local function creedInspectionTree(player, inspection)
    local tree = CREED.getTree(player)
    if not inspection or not tree then return tree end
    local passive = {}
    for _, node in ipairs(tree) do
        if CREED.poolOf(node) == "passive" then passive[#passive + 1] = node end
    end
    return passive
end

local function creedPacketSender(player, recipient, inspection)
    return function(data)
        if inspection then
            data.inspectTarget, data.inspectSerial = inspection.target, inspection.serial
        end
        return (recipient or player):sendExtendedOpcode(OPCODE_CREED, json.encode(data))
    end
end

function Player.sendCreedUpdate(self, recipient, inspection)
    local sendPacket = creedPacketSender(self, recipient, inspection)
	local tree = creedInspectionTree(self, inspection)
	if not tree then
		return self:sendCreedState(recipient, inspection)
	end

	local owned, available = {}, {}
	-- Wybrane efekty mastery: klient musi wiedziec, ktory z nich dziala, zeby pokazac
	-- go w dymku. Kluczem jest tekst, bo json.encode gubi liczbowe klucze tablicy.
	local chosen = {}
	local hasResettableNodes = false
	for _, node in ipairs(tree) do
		if self:hasCreedNode(node) then
			owned[#owned + 1] = node.id
			if node.effects then
				local effect = self:getStorageValue(CREED.nodeStorageBase + node.id)
				chosen[tostring(node.id)] = node.effects[effect] and effect or 1
			end
			if not node.granted then
				hasResettableNodes = true
			end
		elseif not inspection and self:canReachCreedNode(tree, node) then
			available[#available + 1] = node.id
		end
	end

	-- Punkty ida jako lista pul w kolejnosci z CREED.poolOrder - klient tylko je
	-- wypisuje, wiec dolozenie trzeciej puli nie wymaga zmiany w kliencie.
	local pools = {}
	for _, pool in ipairs(CREED.poolOrder) do
		pools[#pools + 1] = {
			id = pool,
			title = CREED.pools[pool].title,
			points = self:getCreedPoints(pool)
		}
	end


    local state = {
        t = "state", pools = pools, vocation = self:getVocation():getName(),
        owned = owned, available = available, chosen = chosen,
        canReset = not inspection and CREED.allowSelfReset,
        hasResettableNodes = hasResettableNodes
    }
    local encoded = json.encode(state)
    if #encoded <= CREED_CHUNK_BYTES then
        return sendPacket(state)
    end
    -- A fully developed Fate exceeds the protocol's single-string limit.
    state.t, state.owned, state.available = "stateBegin", nil, nil
    sendPacket(state)
    for _, entry in ipairs({{"owned", owned}, {"available", available}}) do
        local chunk = {}
        for _, id in ipairs(entry[2]) do
            chunk[#chunk + 1] = id
            if #chunk == 400 then
                sendPacket({t = "stateNodes", list = entry[1], ids = chunk})
                chunk = {}
            end
        end
        if #chunk > 0 then
            sendPacket({t = "stateNodes", list = entry[1], ids = chunk})
        end
    end
    return sendPacket({t = "stateDone"})
end

function Player.sendCreedState(self, recipient, inspection)
    local sendPacket = creedPacketSender(self, recipient, inspection)
	local tree = creedInspectionTree(self, inspection)
	if not tree then
		-- Zawsze odsylamy stan, zeby okno moglo powiedziec, o co chodzi, zamiast
		-- wisiec puste. Wokacja None i kazda inna bez drzewka trafia tutaj.
		return sendPacket({
			t = "empty",
			vocation = self:getVocation():getName(),
			message = "No Fate tree is available."
		})
	end

	sendPacket({
		t = "begin",
		vocation = self:getVocation():getName(),
		count = #tree
	})

	local chunk, bytes = {}, 0
	local function flush()
		if #chunk == 0 then
			return
		end
		sendPacket({t = "nodes", nodes = chunk})
		chunk, bytes = {}, 0
	end

	for _, node in ipairs(tree) do
		local payload = creedNodePayload(node)
		local size = #json.encode(payload) + 1
		if bytes + size > CREED_CHUNK_BYTES then
			flush()
		end
		chunk[#chunk + 1] = payload
		bytes = bytes + size
	end
	flush()

	sendPacket({t = "done", count = #tree})
	-- Postep osobno - ta sama wiadomosc, ktora klient dostaje po kupieniu wezla.
	return self:sendCreedUpdate(recipient, inspection)
end

-- Pelne drzewko poza limitem nie jest gubione, tylko odkladane: klient dostanie je,
-- gdy kubelek sie odnowi. Dzieki temu okno nigdy nie zostaje puste, a serwer i tak
-- wysyla najwyzej jeden opis na okno czasu.
local pendingFateTree = {}

function sendFateTree(player)
	local id = player:getId()
	local allowed, wait = allowRequest(player, "fateTree")
	if allowed then
		pendingFateTree[id] = nil
		player:sendCreedState()
		return
	end
	if pendingFateTree[id] then
		return
	end
	pendingFateTree[id] = true
	addEvent(function(playerId)
		pendingFateTree[playerId] = nil
		local target = Player(playerId)
		if target then
			sendFateTree(target)
		end
	end, wait, id)
end

-- Inspekcja to ten sam pelny opis drzewka (setki pakietow, ok. 0,8 MB), tylko cudzy -
-- i mozna inspektowac samego siebie. Placi wiec z TEGO SAMEGO kubelka, co wlasne
-- drzewko, liczonego po PROSZACYM. Odmowa nie gubi prosby: zostaje jedna odroczona na
-- gracza (ostatnia wygrywa), tak jak przy sendFateTree.
local pendingFateInspect = {}

local function sendFateInspection(player, targetId, serial)
	local requesterId = player:getId()
	local allowed, wait = allowRequest(player, "fateTree")
	if not allowed then
		local alreadyWaiting = pendingFateInspect[requesterId] ~= nil
		pendingFateInspect[requesterId] = {target = targetId, serial = serial}
		if not alreadyWaiting then
			addEvent(function(id)
				local pending = pendingFateInspect[id]
				pendingFateInspect[id] = nil
				local requester = Player(id)
				if requester and pending then
					sendFateInspection(requester, pending.target, pending.serial)
				end
			end, wait, requesterId)
		end
		return
	end

	local target = Player(targetId)
	if not target or not player:canSee(target:getPosition()) or not player:canSeeCreature(target) then
		player:sendExtendedOpcode(OPCODE_CREED, json.encode({t = "empty", inspectTarget = targetId,
			inspectSerial = serial, message = "This player is no longer available to inspect."}))
		return
	end
	return target:sendCreedState(player, {target = targetId, serial = serial})
end

-- Akcje, ktore handler zna. Kazda inna tabela JSON przechodzila dotad cala funkcje
-- i konczyla na sendCreedUpdate + sendSkillPointsState, czyli darmowym przeliczeniu
-- stanu na zadanie.
local CREED_ACTIONS = {buy = true, buyPath = true, buyPlan = true, reset = true, refresh = true}

local function handleCreed(player, buffer)
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" then
		return
	end

	if request.action == "inspect" then
		local id = integer(request.target, 1, 4294967295)
		local serial = integer(request.serial, 1, 2147483647)
		if not id or not serial then return end
		return sendFateInspection(player, id, serial)
	end
	-- Inspection requests never spend or reset points, including forged actions.
	if request.target ~= nil then return end
	if not CREED_ACTIONS[request.action] then return end

	if request.action == "buy" then
		local bought, reason = player:buyCreedNode(tonumber(request.node) or 0, request.choice)
		if not bought and reason then
			player:sendCancelMessage(reason)
		end
	elseif request.action == "buyPath" then
		local bought, reason = player:buyCreedPath(tonumber(request.node) or 0)
		if not bought and reason then
			player:sendCancelMessage(reason)
		end
	elseif request.action == "buyPlan" then
		local ids, reason = CREED.decodePlanRanges(request.ranges)
		local bought, count, cost = false, 0, 0
		if ids then
			bought, reason, count, cost = player:buyCreedPlan(ids, request.choices)
		end
		player:sendExtendedOpcode(OPCODE_CREED, json.encode({t = "planResult", ok = bought,
			message = reason, count = count, cost = cost}))
		if not bought and reason then player:sendCancelMessage(reason) end
	elseif request.action == "reset" then
		if request.pool ~= nil and not CREED.pools[request.pool] then
			return
		end
		if not CREED.allowSelfReset then
			player:sendCancelMessage("Only a GM can reset your tree.")
			return
		end
		local tile = player:getTile()
		if not tile or not tile:hasFlag(TILESTATE_PROTECTIONZONE) then
			player:sendCancelMessage("You can only reset this tree inside a protection zone.")
			return
		end
		local tree = CREED.getTree(player)
		local hasResettableNodes = false
		for _, node in ipairs(tree or {}) do
			if not node.granted and player:hasCreedNode(node)
				and (request.pool == nil or CREED.poolOf(node) == request.pool) then
				hasResettableNodes = true
				break
			end
		end
		if not hasResettableNodes then
			player:sendCancelMessage("There are no spent points to reset.")
			return
		end
		local refunded = player:resetCreed(request.pool)
		local parts = {}
		for _, pool in ipairs(CREED.poolOrder) do
			if (refunded[pool] or 0) > 0 then
				parts[#parts + 1] = string.format("%d %s", refunded[pool],
					string.lower(CREED.pools[pool].title))
			end
		end
		player:sendTextMessage(MESSAGE_INFO_DESCR, #parts > 0
			and ("You get back " .. table.concat(parts, " and ") .. ".")
			or "There was nothing to reset.")
	end

	-- Pelny opis drzewka tylko na prosbe (otwarcie okna). Po kupieniu wezla wystarczy
	-- postep - inaczej kazde klikniecie kosztowaloby kilkadziesiat kilobajtow.
	if request.action == "refresh" then
		sendFateTree(player)
	else
		player:sendCreedUpdate()
	end
	-- Wezel moze zmienic staty albo podklase, wiec okno Character tez odswiezamy.
	player:sendSkillPointsState()
end

-- Klient potwierdza KONKRETNA sztuke (okno "Scrap ...?" albo klikniecie etykiety), a
-- adresuje ja pozycja i stackpos. Miedzy pokazaniem pytania a potwierdzeniem zawartosc
-- slotu moze sie zmienic - handler niszczyl wtedy to, co lezalo tam teraz. Klient
-- dosyla wiec typ (clientId), liczbe i ramke rzadkosci potwierdzonej sztuki, a my
-- porownujemy je tuz przed operacja. Dwie sztuki tego samego typu, liczby i rzadkosci
-- z roznymi afiksami sa dla tej kontroli nierozroznialne - do tego trzeba biletu serwera.
local function matchesConfirmedItem(item, request)
	if request.id ~= nil then
		local clientId = integer(request.id, 1, 65535)
		if not clientId or ItemType(item:getId()):getClientId() ~= clientId then
			return false
		end
	end
	if request.count ~= nil and ItemType(item:getId()):isStackable() then
		local count = integer(request.count, 1, 65535)
		if not count or item:getCount() ~= count then
			return false
		end
	end
	if request.frame ~= nil then
		local frame = integer(request.frame, 0, 65535)
		if not frame or item:getClientFrame() ~= frame then
			return false
		end
	end
	return true
end

local ITEM_CHANGED_MESSAGE = "This is not the item you selected anymore. Please try again."

-- Zlom: saldo dla klienta i reczne rozwalanie przedmiotow. Logika w data/lib/core/scrap.lua,
-- przedmiot rozwiazujemy tym samym resolveItem, co tooltip (ziemia, plecak, ekwipunek).
local function handleScrap(player, buffer)
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" then
		return
	end

	if request.action == "state" then
		player:sendScrapState(true)
	elseif request.action == "destroy" then
		local thing = resolveItem(player, request)
		if not thing or not thing:isItem() then
			player:sendCancelMessage("There is no such item here.")
			return
		end
		if not matchesConfirmedItem(thing, request) then
			player:sendCancelMessage(ITEM_CHANGED_MESSAGE)
			return
		end
		local done, reason = player:scrapItem(thing)
		if not done and reason then
			player:sendCancelMessage(reason)
		end
	elseif request.action == "pickup" then
		-- tylko z ziemi; plecak i ekwipunek nie maja czego podnosic
		if tonumber(request.x) == 0xFFFF then
			return
		end
		local thing = resolveItem(player, request)
		if not thing or not thing:isItem() then
			player:sendCancelMessage("There is no such item here.")
			return
		end
		if not matchesConfirmedItem(thing, request) then
			player:sendCancelMessage(ITEM_CHANGED_MESSAGE)
			return
		end
		local done, reason = player:pickupLoot(thing)
		if not done and reason then
			player:sendCancelMessage(reason)
		end
	end
end

-- Rzadkosc przedmiotow lezacych na kratkach, o ktore pyta modul etykiet lootu.
--
-- Klient nie widzi atrybutow przedmiotu - dla niego kazda sztuka tego samego typu
-- wyglada tak samo. Pyta wiec o kratki, na ktorych wlasnie sklada etykiety (robi to
-- tylko wtedy, gdy zawartosc kratki sie zmienila, wiec ruch jest niewielki), a my
-- odsylamy liste w tej samej kolejnosci i z tym samym filtrem, ktorego uzywa on sam:
-- przedmioty do podniesienia, bez podlogi. Kazdy wpis niesie clientId, po ktorym
-- klient sprawdza, czy trafil we wlasciwa sztuke.
local function handleLootRarity(player, buffer)
	if not allowRequest(player, "lootRarity") then
		return
	end
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" or type(request.tiles) ~= "table" then
		return
	end

	local origin = player:getPosition()
	local response = {}
	local budget = LOOT_RARITY_MAX_BYTES

	for index, entry in ipairs(request.tiles) do
		if index > LOOT_RARITY_MAX_TILES or budget <= 0 then
			break
		end

		if type(entry) ~= "table" then
			return
		end
		local x, y, z = integer(entry.x, 0, 65535), integer(entry.y, 0, 65535), integer(entry.z, 0, 15)
		local requestId = integer(entry.requestId, 1, 2147483647)
		if x and y and z and origin.z == z
			and math.abs(origin.x - x) <= TOOLTIP_MAX_RANGE_X
			and math.abs(origin.y - y) <= TOOLTIP_MAX_RANGE_Y then
			local tile = Tile(Position(x, y, z))
			if tile then
				local items = {}
				-- getItems() zwraca nil dla kratki bez wektora przedmiotow (StaticTile)
				for _, item in ipairs(tile:getItems() or {}) do
					if #items >= LOOT_RARITY_MAX_ITEMS then
						break
					end
					local itemType = ItemType(item:getId())
					if itemType:isPickupable() and not itemType:isGroundTile() then
						RARITY.normalizeName(item)
						items[#items + 1] = {
							id = itemType:getClientId(),
							tier = RARITY.tierData(RARITY.of(item)).key,
							color = DUNGEON.isMap(item) and DUNGEON.maps[item:getId()].color or nil,
							name = item:getName()
						}
					end
				end
				do
					local payload = {x = x, y = y, z = z, items = items, requestId = requestId}
					local encoded = json.encode(payload)
					-- Nie dokladamy kratki, ktora nie zmiesci sie w wiadomosci. Klient
					-- dopyta o nia przy nastepnym odswiezeniu (modules/game_lootlabels).
					if #encoded <= budget then
						budget = budget - #encoded - 1
						response[#response + 1] = payload
					end
				end
			end
		end
	end

	player:sendExtendedOpcode(OPCODE_LOOT_RARITY, json.encode({tiles = response}))
end

local function handleQuestDialog(player, buffer)
	local ok, request = pcall(json.decode, buffer)
	if not ok or type(request) ~= "table" or request.action ~= "accept" then
		return
	end

	local position = player:getPosition()
	if position.z ~= QUEST_NPC_POSITION.z
		or math.abs(position.x - QUEST_NPC_POSITION.x) > 4
		or math.abs(position.y - QUEST_NPC_POSITION.y) > 4 then
		player:sendCancelMessage("You are too far away from QUEST NPC.")
		return
	end

	if player:getStorageValue(QUEST_TWO_STORAGE) < 1 then
		player:setStorageValue(QUEST_TWO_STORAGE, 1)
		player:sendTextMessage(MESSAGE_EVENT_ADVANCE, "New quest added. Check Your quest log.")
	end

	player:sendExtendedOpcode(OPCODE_QUEST_DIALOG, json.encode({action = "accepted", questId = 2}))
end

function onExtendedOpcode(player, opcode, buffer)
	if opcode == OPCODE_LANGUAGE then
		-- otclient language
		if buffer == 'en' or buffer == 'pt' then
			-- example, setting player language, because otclient is multi-language...
			-- player:setStorageValue(SOME_STORAGE_ID, SOME_VALUE)
		end
	elseif opcode == 66 then
        local ok, request = pcall(json.decode, buffer)
        if not ok or type(request) ~= "table" then return end
        if request.action == "mount" then
            CASTING.mount(player)
        elseif request.action == "cancelMount" and CASTING.getSpellName(player) == "Mount" then
            CASTING.interrupt(player)
        end
	elseif opcode == SKILL_POINTS.opcode then
		handleSkillPoints(player, buffer)
	elseif opcode == OPCODE_ITEM_TOOLTIP then
		handleItemTooltip(player, buffer)
	elseif opcode == OPCODE_CREED then
		handleCreed(player, buffer)
	elseif opcode == SCRAP.opcode then
		handleScrap(player, buffer)
	elseif opcode == OPCODE_LOOT_RARITY then
		handleLootRarity(player, buffer)
	elseif opcode == DUNGEON.opcode then
		DUNGEON.handleOpcode(player, buffer, resolveItem)
	elseif opcode == PLAYER_TITLES.opcode then
		PLAYER_TITLES.handleOpcode(player, buffer)
	elseif opcode == OPCODE_QUEST_DIALOG then
		handleQuestDialog(player, buffer)
	else
		-- other opcodes can be ignored, and the server will just work fine...
	end
end
