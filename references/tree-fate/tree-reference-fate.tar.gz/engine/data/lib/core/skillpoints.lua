-- System punktow statystyk.
-- Za kazdy zdobyty level gracz dostaje pule punktow i rozdaje ja recznie w konkretne
-- staty (komenda !points albo okno w kliencie). Pod systemem sa: melee fighting,
-- distance fighting, magic level oraz Vitality i Spirit (maksymalne hp i mana) -
-- zaden z nich nie rosnie juz od uzywania. Samo trenuje sie jeszcze tylko fishing.
-- Shielding wypadl z puli razem z Willpower i dziala juz tylko z ekwipunku.
-- Attack speed (slot 0) wypadl z puli punktow: nie da sie go kupic, rosnie tylko
-- z ekwipunku, ale dalej nie trenuje sie od uzywania (SKILL_POINTS.fixedSkills).
-- Kolejne skille dodajemy w dwoch miejscach: wpis w SKILL_POINTS.stats ponizej
-- i isPointBoughtSkill() w src/enums.h.

SKILL_POINTS = {
	perLevel = 2,   -- punkty za kazdy level
	fromLevel = 1,  -- level, od ktorego naliczamy (przy starcie na 8 = 14 punktow)
	baseSkill = 0,  -- MINIMUM_SKILL_LEVEL z silnika: poziom statu bez wydanych punktow
	allowSelfReset = true, -- na czas testow gracz moze sam cofnac punkty (!points reset)
}

-- Staty, w ktore mozna inwestowac. "name" to nazwa wpisywana w komendzie,
-- "desc" to staly opis "co ta statystyka robi" - klient pokazuje go w dymku po
-- najechaniu na wiersz w oknie Character.
-- Opcjonalne pola wpisu: base (poziom bez punktow), getLevel/setLevel/getEffectiveLevel
-- (gdy stat nie siedzi w tablicy skilli), getMaxPoints (limit) i describe (opis
-- aktualnych liczb).
SKILL_POINTS.stats = {
	{
		name = "Strength",
		aliases = {"strength", "str", "melee", "mf"},
		skill = SKILL_MELEE,
		-- Celnosc daje wylacznie Dexterity (Player::getAccuracy) - opis nie moze jej obiecywac.
		desc = "Raises the damage of melee weapons (swords, axes, clubs, fists)."
	},
	{
		name = "Dexterity",
		aliases = {"dexterity", "dex", "distance", "dist"},
		skill = SKILL_DISTANCE,
		desc = "Raises the damage of ranged weapons (bows, crossbows, thrown weapons) and the accuracy of every weapon attack."
	},
	{
		name = "Intelligence",
		aliases = {"intelligence", "int", "magic", "ml", "mlvl"},
		skill = SKILL_MAGLEVEL,
		desc = "Magic level. Increases the power of offensive and healing spells.",
		-- Magic level startuje od zera i nie siedzi w tablicy skilli, wiec czyta sie
		-- go osobnymi metodami.
		base = 0,
		getLevel = function(self, player)
			return player:getBaseMagicLevel()
		end,
		getEffectiveLevel = function(self, player)
			return player:getMagicLevel()
		end
	},
	{
		name = "Vitality",
		aliases = {"vitality", "vit", "hp", "life"},
		desc = "Each point raises your maximum hit points by 5.",
		storage = PlayerStorageKeys.vitality,
		bonus = "health"
	},
	{
		name = "Spirit",
		aliases = {"spirit", "spr", "duch"},
		desc = "Each point raises your maximum mana by 5.",
		storage = PlayerStorageKeys.spirit,
		bonus = "mana"
	},
	-- Kolejne staty (fishing...) dopisujemy tutaj, gdy przeniesiemy je z treningu
	-- na punkty. Pamietaj o dopisaniu skilla do isPointBoughtSkill() w enums.h,
	-- inaczej dalej bedzie sie sam trenowal.
}

-- Ile hp/many daje jeden punkt w Vitality / Spirit.
SKILL_POINTS.bonusPerPoint = 5

-- Staty bez wlasnego slotu w silniku (Vitality, Spirit) trzymaja poziom w storage.
-- Gdy dostana prawdziwego skilla, wystarczy zdjac pole "storage" i dopisac "skill".
local function storageGetLevel(stat, player)
	local level = player:getStorageValue(stat.storage)
	return level < stat.base and stat.base or level
end

local function storageSetLevel(stat, player, level)
	return player:setStorageValue(stat.storage, math.max(stat.base, level))
end

-- Opis statu, ktory dosypuje hp albo mane: poziom i ile daje w sumie.
local function describeBonus(stat, player, points)
	return string.format("level %d (+%d %s)", stat.base + points,
		points * SKILL_POINTS.bonusPerPoint,
		stat.bonus == "health" and "max hp" or "max mana")
end

local function defaultGetLevel(stat, player)
	return player:getSkillLevel(stat.skill)
end

local function defaultSetLevel(stat, player, level)
	return player:setSkillLevel(stat.skill, level)
end

local function defaultGetEffectiveLevel(stat, player)
	return player:getEffectiveSkillLevel(stat.skill)
end

-- Domyslny opis statu: poziom bazowy i - jesli sie roznia - poziom z ekwipunkiem.
local function defaultDescribe(stat, player, points)
	local base = stat.base + points
	local effective = stat:getEffectiveLevel(player)
	if effective ~= base then
		return string.format("level %d (with equipment %d)", base, effective)
	end
	return string.format("level %d", base)
end

for _, stat in ipairs(SKILL_POINTS.stats) do
	stat.base = stat.base or SKILL_POINTS.baseSkill
	if stat.storage then
		-- ekwipunek nie rusza statow ze storage, wiec poziom efektywny = bazowy
		stat.getLevel = stat.getLevel or storageGetLevel
		stat.setLevel = stat.setLevel or storageSetLevel
		stat.getEffectiveLevel = stat.getEffectiveLevel or storageGetLevel
	end
	if stat.bonus then
		stat.describe = stat.describe or describeBonus
	end
	stat.getLevel = stat.getLevel or defaultGetLevel
	stat.setLevel = stat.setLevel or defaultSetLevel
	stat.getEffectiveLevel = stat.getEffectiveLevel or defaultGetEffectiveLevel
	stat.describe = stat.describe or defaultDescribe
end

function SKILL_POINTS.findStat(name)
	name = name:lower():trim()
	for _, stat in ipairs(SKILL_POINTS.stats) do
		if stat.name:lower() == name then
			return stat
		end
		for _, alias in ipairs(stat.aliases) do
			if alias == name then
				return stat
			end
		end
	end
	return nil
end

function SKILL_POINTS.statBySkill(skillId)
	for _, stat in ipairs(SKILL_POINTS.stats) do
		-- Staty bez pola skill (np. Spirit) nie moga zlapac zapytania o nil.
		if stat.skill and stat.skill == skillId then
			return stat
		end
	end
	return nil
end

-- Skille, ktorych nie kupuje sie juz za punkty, ale ktore dalej maja nie rosnac
-- od uzywania (poziom rusza tylko ekwipunek). Attack speed wypadl z puli punktow,
-- a i tak nie ma go trenowac walka.
SKILL_POINTS.fixedSkills = {SKILL_ATTACKSPEED, SKILL_SHIELD}

-- Staty wycofane z puli punktow. Postaciom, ktore zdazyly w nie zainwestowac,
-- oddajemy punkty przy najblizszym logowaniu i zbijamy skill do bazy - inaczej
-- zostalby na stale podniesiony, a punkty przepadly (!points reset nie widzi juz
-- tych statow). Gdy z puli wypadnie kolejny stat: dopisz go do listy i podbij
-- refundVersion, wtedy zwrot pojdzie jeszcze raz.
SKILL_POINTS.retiredSkills = {SKILL_ATTACKSPEED, SKILL_SHIELD}
SKILL_POINTS.refundVersion = 2

-- Odpowiednik isPointBoughtSkill() z enums.h - trzymaj obie listy zgodne.
function SKILL_POINTS.isPointBought(skillId)
	if SKILL_POINTS.statBySkill(skillId) then
		return true
	end
	for _, skill in ipairs(SKILL_POINTS.fixedSkills) do
		if skill == skillId then
			return true
		end
	end
	return false
end

-- Najwyzszy poziom skilla, jaki miesci silnik (uint16_t w Player::skills). Jedna
-- granica dla zakupu punktow, /addskill i setSkillLevel.
SKILL_POINTS.engineSkillMax = 65535

-- Ile punktow ma sens wladowac w stat; nil = bez limitu.
function SKILL_POINTS.getMaxPoints(stat, player)
	local limit = stat.getMaxPoints and stat:getMaxPoints(player) or nil
	-- Silnik zapisuje poziomy skilli jako uint16_t. Nie wolno pobrac punktow za
	-- poziom, ktory po konwersji zawinie sie do zera.
	if stat.skill then
		local engineLimit = SKILL_POINTS.engineSkillMax - stat.base
		return limit and math.min(limit, engineLimit) or engineLimit
	end
	return limit
end

function SKILL_POINTS.totalForLevel(level)
	return math.max(0, level - SKILL_POINTS.fromLevel) * SKILL_POINTS.perLevel
end

function Player.getSkillPoints(self)
	return math.max(0, self:getStorageValue(PlayerStorageKeys.skillPoints))
end

function Player.setSkillPoints(self, amount)
	return self:setStorageValue(PlayerStorageKeys.skillPoints, math.max(0, amount))
end

function Player.addSkillPoints(self, amount)
	return self:setSkillPoints(self:getSkillPoints() + amount)
end

-- Dosypuje punkty za levele, za ktore gracz jeszcze ich nie dostal. Wolane przy
-- logowaniu i po awansie, wiec dziala tez dla postaci sprzed wprowadzenia systemu.
-- Zapamietany level nigdy nie leci w dol, wiec smierc i ponowne wbicie levelu
-- nie daje punktow drugi raz.
function Player.syncSkillPoints(self)
	local level = self:getLevel()
	local paidFor = self:getStorageValue(PlayerStorageKeys.skillPointsLevel)
	if paidFor < 0 then
		paidFor = SKILL_POINTS.fromLevel
	end

	if level <= paidFor then
		return 0
	end

	local gained = SKILL_POINTS.totalForLevel(level) - SKILL_POINTS.totalForLevel(paidFor)
	self:setStorageValue(PlayerStorageKeys.skillPointsLevel, level)
	if gained > 0 then
		self:addSkillPoints(gained)
	end
	return gained
end

-- Ile punktow gracz wpakowal juz w dany stat.
function Player.getSpentSkillPoints(self, stat)
	return math.max(0, stat:getLevel(self) - stat.base)
end

-- Vitality i Spirit nie maja slotu w silniku, wiec ich bonus do maksymalnego hp
-- i many wchodzi jednym bezterminowym warunkiem CONDITION_ATTRIBUTES - tak samo
-- jak bonusy z drzewka Creed. Bezterminowy warunek nie zapisuje sie do bazy,
-- wiec trzeba go nalozyc przy kazdym logowaniu (creaturescripts/skill_points.lua).
SKILL_POINTS.bonusSubId = 7302 -- 7301 zajete przez Creed

function Player.applySkillPointBonuses(self)
	local health, mana = 0, 0
	for _, stat in ipairs(SKILL_POINTS.stats) do
		if stat.bonus then
			local gain = self:getSpentSkillPoints(stat) * SKILL_POINTS.bonusPerPoint
			if stat.bonus == "health" then
				health = health + gain
			else
				mana = mana + gain
			end
		end
	end

	-- Zdjecie starego warunku obniza maksa, a silnik przycina do niego aktualne
	-- hp/mane. Zapamietujemy je wiec przed zmiana i po nalozeniu nowego oddajemy
	-- graczowi tyle, ile mial - inaczej kazdy wydany punkt kosztowalby zycie.
	local currentHealth, currentMana = self:getHealth(), self:getMana()
	self:removeCondition(CONDITION_ATTRIBUTES, CONDITIONID_DEFAULT, SKILL_POINTS.bonusSubId)

	if health > 0 or mana > 0 then
		local condition = Condition(CONDITION_ATTRIBUTES, CONDITIONID_DEFAULT)
		condition:setParameter(CONDITION_PARAM_TICKS, -1)
		condition:setParameter(CONDITION_PARAM_SUBID, SKILL_POINTS.bonusSubId)
		condition:setParameter(CONDITION_PARAM_STAT_MAXHITPOINTS, health)
		condition:setParameter(CONDITION_PARAM_STAT_MAXMANAPOINTS, mana)
		self:addCondition(condition)
	end

	if self:getHealth() < currentHealth then
		self:addHealth(currentHealth - self:getHealth())
	end
	if self:getMana() < currentMana then
		self:addMana(currentMana - self:getMana())
	end
end

-- Wydaje punkty w stat. Zwraca ile faktycznie poszlo + powod, jesli mniej niz proszono.
function Player.spendSkillPoints(self, stat, amount)
	if type(amount) ~= "number" or amount ~= amount or amount == math.huge or amount < 1 then
		return 0, "Enter a positive number of points."
	end
	amount = math.floor(amount)

	local available = self:getSkillPoints()
	if available < 1 then
		return 0, "You have no free points."
	end

	local spent = self:getSpentSkillPoints(stat)
	local max = SKILL_POINTS.getMaxPoints(stat, self)
	if max and spent >= max then
		return 0, string.format("%s is already at its maximum (%d points).", stat.name, max)
	end

	local toSpend = math.min(amount, available, max and (max - spent) or amount)
	self:setSkillPoints(available - toSpend)
	stat:setLevel(self, stat.base + spent + toSpend)
	if stat.bonus then
		self:applySkillPointBonuses()
		-- Vitality/Spirit zmienily baze, od ktorej drzewko liczy procenty zycia/many.
		self:refreshCreedVitals()
	end
	return toSpend
end

-- Regeneracja siedzi w silniku w warunkach CONDITION_REGENERATION, po jednym na
-- zrodlo: podstawa z wokacji wisi na warunku najedzenia (CONDITIONID_DEFAULT),
-- kazdy zalozony przedmiot z ability "regeneration" dokłada wlasny warunek na
-- swoim slocie, a zaklecia typu recovery - na CONDITIONID_COMBAT. Zeby pokazac
-- graczowi ile faktycznie odnawia na sekunde, sumujemy je wszystkie.
local REGENERATION_CONDITION_IDS = {
	CONDITIONID_DEFAULT,
	CONDITIONID_COMBAT,
	CONDITIONID_HEAD,
	CONDITIONID_NECKLACE,
	CONDITIONID_BACKPACK,
	CONDITIONID_ARMOR,
	CONDITIONID_RIGHT,
	CONDITIONID_LEFT,
	CONDITIONID_LEGS,
	CONDITIONID_FEET,
	CONDITIONID_RING,
	CONDITIONID_AMMO
}

-- Zwraca hp/s i mana/s. Zero znaczy, ze gracz nic teraz nie odnawia - np. nie jest
-- najedzony, bo bez warunku najedzenia podstawa z wokacji w ogole nie tyka.
function Player.getRegenerationPerSecond(self)
	local health, mana = 0, 0

	local function add(condition)
		if not condition then
			return
		end
		-- Interwaly sa w ms; silnik nie pozwala na 0, ale warunek moze przyjsc
		-- z zapisu gracza, wiec i tak sprawdzamy przed dzieleniem.
		local healthTicks = condition:getParameter(CONDITION_PARAM_HEALTHTICKS) or 0
		local healthGain = condition:getParameter(CONDITION_PARAM_HEALTHGAIN) or 0
		if healthTicks > 0 and healthGain > 0 then
			health = health + healthGain * 1000 / healthTicks
		end

		local manaTicks = condition:getParameter(CONDITION_PARAM_MANATICKS) or 0
		local manaGain = condition:getParameter(CONDITION_PARAM_MANAGAIN) or 0
		if manaTicks > 0 and manaGain > 0 then
			mana = mana + manaGain * 1000 / manaTicks
		end
	end

	for _, conditionId in ipairs(REGENERATION_CONDITION_IDS) do
		add(self:getCondition(CONDITION_REGENERATION, conditionId))
	end

	-- Drzewko Fate wiesza swoja regeneracje na tym samym CONDITIONID_DEFAULT, ale
	-- z wlasnym subId, a getCondition porownuje takze subId - bez tego zapytania
	-- wezly "+X life regenerated per second" w ogole nie trafialyby do okna.
	if CREED and CREED.conditionSubId then
		add(self:getCondition(CONDITION_REGENERATION, CONDITIONID_DEFAULT, CREED.conditionSubId))
	end

	return health, mana
end

-- Rozpisanie naddatku ponad poziom kupiony punktami - klient pokazuje to w dymku
-- wiersza ("+9 from equipment"). Kolejnosc wpisow jest kolejnoscia wyswietlania.
--
-- Dzis zrodla sa dwa: ekwipunek i drzewko Fate. Gdy dojda gemy, wystarczy dolozyc tu
-- kolejny wpis {source = "gems", value = n} - klient rozpisze go sam, bez zmian po
-- jego stronie.
function SKILL_POINTS.bonusSources(player, stat, level, effective, fate)
	local sources = {}

	fate = fate or 0
	local equipment = effective - level - fate
	if equipment ~= 0 then
		sources[#sources + 1] = {source = "equipment", value = equipment}
	end
	if fate ~= 0 then
		sources[#sources + 1] = {source = "Fate", value = fate}
	end

	return sources
end

-- Ile punktow statu dokłada drzewko. Staty ze slotem skilla (Strength, Dexterity,
-- Intelligence) maja to juz w poziomie efektywnym - dosypuje im condition z applyCreed.
-- Vitality siedzi w storage, ktorego condition nie rusza, wiec tam trzeba doliczyc
-- bonus osobno: inaczej wiersz stalby na kupionym poziomie, choc hp z wezla juz jest.
function SKILL_POINTS.fateBonus(player, stat)
	if not (CREED and CREED.statsOf) then
		return 0
	end
	return math.floor(CREED.statsOf(player)[stat.name] or 0)
end

-- Metody z nowszych binariow serwera. data/lib da sie podmienic bez przebudowy,
-- wiec brak metody ma dac zero, a nie wywrocic cale okno (ta sama oslona, co przy
-- Player:setFateMods w creed.lua).
local function bound(player, method)
	local fn = player[method]
	return fn and fn(player) or 0
end

-- Odpornosci pokazywane w oknie: ekwipunek i drzewko. Silnik liczy je osobno i po
-- kolei (Player::blockHit: najpierw sztuki, potem drzewko na tym, co zostalo), wiec
-- obie warstwy MNOZA sie, a nie sumuja - inaczej okno obiecywaloby wiecej, niz
-- gracz dostanie. Odpornosci z drzewka maja przy tym wlasny sufit.
function SKILL_POINTS.resistances(player, mods)
	local resistances = player.getResistances and player:getResistances() or nil
	if not resistances or not (CREED and CREED.resistanceOf) then
		return resistances
	end

	for index = 0, #resistances - 1 do
		local fate = CREED.resistanceOf(mods, index)
		if fate ~= 0 then
			-- indeks silnika liczy sie od zera, tablica z getResistances od jedynki
			local remaining = (1 - (resistances[index + 1] or 0) / 100) * (1 - fate / 100)
			resistances[index + 1] = (1 - remaining) * 100
		end
	end
	return resistances
end

-- Kanal do okna w kliencie (modules/game_skillpoints). Klient prosi o stan przez
-- {action = "refresh"}, wydaje punkty przez {action = "spend", stat = <index>, amount = n}.
SKILL_POINTS.opcode = 60

function Player.getSkillPointsState(self)
	local stats = {}
	for index, stat in ipairs(SKILL_POINTS.stats) do
		local points = self:getSpentSkillPoints(stat)
		local level = stat.base + points
		local fate = SKILL_POINTS.fateBonus(self, stat)
		local effective = stat:getEffectiveLevel(self)
		if stat.storage then
			-- poziom ze storage nie zna warunkow, a wezel drzewka juz dziala
			effective = effective + fate
		end
		stats[#stats + 1] = {
			id = index,
			name = stat.name,
			points = points,
			level = level,
			effective = effective,
			sources = SKILL_POINTS.bonusSources(self, stat, level, effective, fate),
			max = SKILL_POINTS.getMaxPoints(stat, self) or 0,
			info = stat:describe(self, points),
			desc = stat.desc
		}
	end

	local armor, armorReduction = self:getArmorValue()
	local lifeRecovery, manaRecovery = self:getRegenerationPerSecond()
	-- Bonusy z drzewka, ktorych zadna inna liczba w oknie nie niesie. Nazwy pol sa
	-- te same, co klucze modow w wezlach (CREED.engineMods / CREED.luaMods) - dzieki
	-- temu widac wprost, ktory wiersz okna czyta ktory bonus.
	local mods = CREED and CREED.modsOf and CREED.modsOf(self) or {}
	local function fateMod(name)
		return math.floor(mods[name] or 0)
	end
	local function conversion(name)
		return CREED and CREED.conversionOf and CREED.conversionOf(mods, name) or 0
	end

	return {
		points = self:getSkillPoints(),
		vocation = self:getVocation():getName(),
		level = self:getLevel(),
		-- Bron zadaje obrazenia z przedzialu; oba konce sa juz po procentach ze statu
		-- i po mnozniku wokacji, wiec klient tylko je sklada.
		attack = self:getAttackValue(),
		attackMin = self:getAttackMinValue(),
		defense = self:getDefenseValue(),
		life = self:getMaxHealth(),
		mana = self:getMaxMana(),
		attackSpeed = self:getAttackSpeedValue(),
		-- System leczenia jeszcze nie istnieje - okno pokazuje 0, zeby wiersz byl
		-- na swoim miejscu, gdy dojdzie mechanika.
		healing = 0,
		armor = armor,
		-- procent obrazen scinanych przez armor - wzor siedzi w silniku (const.h),
		-- klient tylko wyswietla to, co dostanie
		armorReduction = armorReduction,
		resistances = SKILL_POINTS.resistances(self, mods),
		attackSpeedSkill = self:getEffectiveSkillLevel(SKILL_ATTACKSPEED),
		-- ile hp/many wraca na sekunde, juz po zsumowaniu wokacji i ekwipunku
		lifeRecovery = lifeRecovery,
		manaRecovery = manaRecovery,
		-- Energy shield: sufit z ekwipunku i drzewka, odstep miedzy tickami ladowania
		-- (ms, juz po procentach) i zwloka po trafieniu.
		energyShield = self:getMaxEnergyShield(),
		energyShieldRecharge = self:getEnergyShieldRechargePerSecond(),
		energyShieldInterval = self:getEnergyShieldInterval(),
		energyShieldSpeed = self:getEnergyShieldRechargeSpeed(),
		energyShieldDelay = self:getEnergyShieldDelay() / 1000,
		-- Energy shield z ekwipunku podnosi sam sufit, procenty niesie drzewko.
		energyShieldIncrease = fateMod("energyShieldIncrease"),
		-- Unik, blok i celnosc: plaskie wartosci z ekwipunku i drzewka, procenty
		-- z drzewka mnoza dopiero cale sumy (Player::getEvasion / getAccuracy).
		evasion = bound(self, "getEvasion"),
		blockChance = bound(self, "getBlockChance"),
		accuracy = bound(self, "getAccuracy"),
		-- Procenty obrazen fizycznych: staty, ekwipunek i drzewko razem - dokladnie
		-- to, czym silnik mnozy wylosowany przedzial broni.
		physicalIncrease = bound(self, "getPhysicalDamageIncrease"),
		-- Procenty maksymalnego zycia i many z drzewka. Same liczby Life i Mana wyzej
		-- juz je zawieraja (condition z applyCreed), tu chodzi o pokazanie skladnika.
		lifeIncrease = fateMod("lifeIncrease"),
		manaIncrease = fateMod("manaIncrease"),
		-- Czary: ogolny procent obrazen i skrocenie czasu rzucania.
		spellIncrease = fateMod("spellIncrease"),
		castSpeed = fateMod("castSpeed"),
		-- Procenty obrazen zywiolem - dzialaja na to, czym bron albo czar naprawde bije.
		fireIncrease = fateMod("fireIncrease"),
		coldIncrease = fateMod("coldIncrease"),
		lightningIncrease = fateMod("lightningIncrease"),
		poisonIncrease = fateMod("poisonIncrease"),
		holyIncrease = fateMod("holyIncrease"),
		deathIncrease = fateMod("deathIncrease"),
		-- Konwersje juz po sufircie sumy (CREED.conversionOf).
		physToFire = conversion("physToFire"),
		physToCold = conversion("physToCold"),
		physToLightning = conversion("physToLightning"),
		physToDeath = conversion("physToDeath"),
		canReset = SKILL_POINTS.allowSelfReset,
		stats = stats
	}
end

function Player.sendSkillPointsState(self)
	return self:sendExtendedOpcode(SKILL_POINTS.opcode, json.encode(self:getSkillPointsState()))
end

-- Jednorazowy zwrot punktow ze statow, ktore wypadly z puli (SKILL_POINTS.retiredSkills).
-- Wolane przy logowaniu, storage pilnuje, zeby nie zaplacic dwa razy.
function Player.refundRetiredSkillPoints(self)
	if self:getStorageValue(PlayerStorageKeys.skillPointsRefund) >= SKILL_POINTS.refundVersion then
		return 0
	end
	self:setStorageValue(PlayerStorageKeys.skillPointsRefund, SKILL_POINTS.refundVersion)

	local refunded = 0
	for _, skill in ipairs(SKILL_POINTS.retiredSkills) do
		-- getSkillLevel to poziom bazowy, bez bonusow z ekwipunku - zwracamy wiec
		-- dokladnie tyle, ile gracz sam wlozyl w stat.
		local spent = self:getSkillLevel(skill) - SKILL_POINTS.baseSkill
		if spent > 0 then
			self:setSkillLevel(skill, SKILL_POINTS.baseSkill)
			refunded = refunded + spent
		end
	end

	if refunded > 0 then
		self:addSkillPoints(refunded)
	end
	return refunded
end

-- Baza statow zjechala z 10 na 0 (MINIMUM_SKILL_LEVEL w src/player.h). Postaciom
-- sprzed tej zmiany trzeba zdjac te 10 poziomow, ktorych nigdy nie kupily: inaczej
-- okno pokazaloby je jako wydane punkty, a Reset oddalby za nie punkty z niczego.
-- Punktow tu nie dodajemy ani nie zabieramy - przesuwa sie sama skala.
-- Intelligence (magic level) pomijamy: zawsze stal na zerze.
SKILL_POINTS.previousBaseSkill = 10
SKILL_POINTS.rebaseVersion = 1

-- Skille trzymane w silniku, ktore stały na starej bazie. Sloty 2 i 3 (sword, axe)
-- sa martwe po zlaniu w SKILL_MELEE, ale w bazie danych dalej maja swoje kolumny.
local REBASED_SKILLS = {
	SKILL_ATTACKSPEED, SKILL_MELEE, SKILL_SWORD, SKILL_AXE,
	SKILL_DISTANCE, SKILL_SHIELD, SKILL_FISHING
}

function Player.rebaseSkillPoints(self)
	local drop = SKILL_POINTS.previousBaseSkill - SKILL_POINTS.baseSkill
	if drop <= 0 then
		return false
	end
	if self:getStorageValue(PlayerStorageKeys.skillPointsRebase) >= SKILL_POINTS.rebaseVersion then
		return false
	end
	self:setStorageValue(PlayerStorageKeys.skillPointsRebase, SKILL_POINTS.rebaseVersion)

	for _, skill in ipairs(REBASED_SKILLS) do
		local level = self:getSkillLevel(skill)
		self:setSkillLevel(skill, math.max(SKILL_POINTS.baseSkill, level - drop))
	end

	-- Spirit nie ma slotu w silniku, siedzi w storage - tez trzeba go przesunac.
	local spirit = self:getStorageValue(PlayerStorageKeys.spirit)
	if spirit > 0 then
		self:setStorageValue(PlayerStorageKeys.spirit, math.max(SKILL_POINTS.baseSkill, spirit - drop))
	end

	return true
end

-- Czy gracz moze sam cofnac punkty. Tylko w strefie chronionej - poza nia dalo by sie
-- przestawiac staty w srodku walki.
function Player.canResetSkillPoints(self)
	if not SKILL_POINTS.allowSelfReset then
		return false, "Only a GM can reset your points."
	end

	local tile = self:getTile()
	if not tile or not tile:hasFlag(TILESTATE_PROTECTIONZONE) then
		return false, "You can only reset your points inside a protection zone."
	end

	for _, stat in ipairs(SKILL_POINTS.stats) do
		if self:getSpentSkillPoints(stat) > 0 then
			return true
		end
	end

	return false, "There are no spent points to reset."
end

-- Cofa wszystkie wydane punkty i wraca je do puli.
function Player.resetSkillPoints(self)
	local refunded = 0
	for _, stat in ipairs(SKILL_POINTS.stats) do
		refunded = refunded + self:getSpentSkillPoints(stat)
		stat:setLevel(self, stat.base)
	end

	self:addSkillPoints(refunded)
	self:applySkillPointBonuses()
	-- Bez tego procent z drzewka zostawal policzony od starej, wyzszej Vitality.
	self:refreshCreedVitals()
	return refunded
end
