-- Creed - drzewko rozwoju postaci.
--
-- Osobna pula punktow niz staty z okna Character ([[skillpoints]]): tam 2 punkty za
-- level idace w Strength/Dexterity/..., tutaj 1 punkt za level idacy w wezly drzewka.
--
-- Wezel moze robic cztery rzeczy, w dowolnej kombinacji:
--   stats    = {Strength = 2}     bonus do statu (przez condition, patrz applyCreed)
--   special  = {critChance = 3}   special skille silnika (crit, leech)
--   spell    = "Berserk"          czar z needlearn="1" - silnik ma na to learnSpell
--   subclass = 10                 zmiana wokacji na podklase
--
-- Wezel z "granted = true" jest wlasnoscia gracza od poczatku - poza kupowaniem
-- i poza resetem (patrz Player.hasCreedNode).
--
-- Do tego pole "kind" mowi klientowi, jak wezel narysowac - i tylko tyle:
--   "small"   maly wezel, bez podpisu (domyslne, gdy pola nie ma)
--   "notable" wiekszy wezel z podpisem, koniec skrzydla
--   "gate"    wybor podklasy
--   "root"    srodek drzewka
--
-- WAZNE: "id" wezla jest zapisywane w storage gracza, wiec **nigdy go nie zmieniaj
-- ani nie uzywaj ponownie** po wypuszczeniu drzewka. Kolejnosc w tabeli jest dowolna,
-- pozycje x/y to kratki siatki (klient mnozy je przez odstep).
--
-- 07.09.2026: doszly Warrior (drzewko 2) i Sorcerer (7), Scion wypadl, a Witch dostala
-- Licha zamiast Elementalisty (ten przeszedl do Sorcerera). Numery drzewek ida za id
-- wokacji bazowej, wiec id wezlow w drzewkach 3-9 zostaly przenumerowane mimo zasady
-- wyzej - baza miala wtedy tylko postacie testowe, a allowSelfReset pozwala odkrecic
-- ewentualne resztki w storage. Po wypuszczeniu serwera juz tak nie mozna.

-- /reload global wykonuje ten plik ponownie. Ostatnio przeliczone mody graczy
-- (activeMods/activeStats/activeParams) musza to przezyc - condition i pakiet modow
-- w silniku zostaja, wiec pusta pamiec podreczna rozjezdzala czary, cast speed i okno
-- Character z tym, co naprawde dziala. Po wczytaniu calosci CREED.reapplyAll (wolane
-- z lib/core/core.lua) przelicza drzewko wszystkim zalogowanym na nowych definicjach.
local previousCreed = rawget(_G, "CREED")

CREED = {
	allowSelfReset = true, -- na czas testow gracz moze zresetowac drzewko
	nodeStorageBase = 40000, -- kazdy wezel zajmuje nodeStorageBase + id
	conditionSubId = 7301,   -- po tym poznajemy "nasz" condition wsrod innych
}

-- Dwie osobne pule punktow. "passive" idzie w korone (drzewko u gory), "talent"
-- w galezie podklas. Kazda trasa rozwija sie wlasnym tempem, zamiast konkurowac
-- o te same punkty - korona kosztuje 475, a galaz podklasy 153, wiec przy jednej
-- puli wejscie w podklase zawsze bylo kosztem korony.
--
-- Wezel wskazuje pule polem "pool". Bez niego nalezy do "passive" - tak dzialaja
-- jeszcze nieprzebudowane drzewka wokacji 2-9, ktore siedza na starej puli.
CREED.defaultPool = "passive"
CREED.poolOrder = {"passive", "talent"} -- kolejnosc w oknie
CREED.pools = {
	passive = {
		title = "Passive points",
		pointsPerLevel = 1,
		fromLevel = 1,
		points = PlayerStorageKeys.creedPoints,
		paidFor = PlayerStorageKeys.creedPointsLevel,
		spent = PlayerStorageKeys.creedPointsSpent,
	},
	talent = {
		title = "Talent points",
		pointsPerLevel = 1,
		fromLevel = 1,
		points = PlayerStorageKeys.creedTalentPoints,
		paidFor = PlayerStorageKeys.creedTalentPointsLevel,
		spent = PlayerStorageKeys.creedTalentPointsSpent,
	},
}

function CREED.poolOf(node)
	return CREED.pools[node.pool] and node.pool or CREED.defaultPool
end

-- Nazwa statu -> parametr condition. Trzymamy sie nazw z okna Character.
CREED.statParams = {
	["Attack Speed"] = CONDITION_PARAM_SKILL_FIST,
	["Strength"] = CONDITION_PARAM_SKILL_MELEE,
	["Dexterity"] = CONDITION_PARAM_SKILL_DISTANCE,
	-- Intelligence to magic level, a ten nie jest zwyklym skillem - stad inny parametr.
	["Intelligence"] = CONDITION_PARAM_STAT_MAGICPOINTS,
	-- Vitality tez nie ma slotu skilla: w oknie Character jest statem ze storage,
	-- ktory dosypuje maksymalne hp. Wezel daje jej "poziomy", a przelicza je statScale.
	["Vitality"] = CONDITION_PARAM_STAT_MAXHITPOINTS,
}

-- Ile parametru condition daje jeden punkt statu z wezla. Vitality liczymy tym
-- samym kursem, co punkty z okna Character - inaczej te same "+2" znaczylyby
-- w drzewku co innego niz przy rozdawaniu punktow.
CREED.statScale = {
	["Vitality"] = SKILL_POINTS.bonusPerPoint,
}

-- ------------------------------------------------------------------
-- Mody drzewka - bonusy, ktorych condition nie zna
-- ------------------------------------------------------------------
--
-- Condition potrafi tylko staty i "special skille" silnika. Armor, energy shield,
-- procenty obrazen, odpornosci i predkosc maja u nas wlasne systemy, wiec drzewko
-- podaje je osobnym kanalem. W wezle piszemy czytelne nazwy:
--
--   mods = {armour = 20, armourIncrease = 12, fireRes = 6}
--
-- a tlumaczenie na klucze silnika siedzi w tej jednej tabeli. Klucze musza zgadzac
-- sie z FateMods::parse w src/player.cpp.
CREED.engineMods = {
	armour = "armor",
	armourIncrease = "armorinc",
	energyShield = "es",
	energyShieldIncrease = "esinc",
	energyShieldRecharge = "esspeed",
	physicalIncrease = "physinc",
	moveSpeed = "speed",
	blockChance = "block",
	evasion = "eva",
	evasionIncrease = "evainc",
	accuracy = "acc",
	accuracyIncrease = "accinc",
	-- Odpornosci: numer to indeks z combatTypeToIndex (src/tools.cpp).
	physicalRes = "res0",
	lightningRes = "res1",
	poisonRes = "res2",
	fireRes = "res3",
	coldRes = "res9",
	holyRes = "res10",
	chaosRes = "res11",
	-- Procenty "increased <zywiol> Damage". Dzialaja na to, czym bron albo czar
	-- naprawde bije: bron bez zywiolu i bez konwersji nic z nich nie ma.
	lightningIncrease = "inc1",
	poisonIncrease = "inc2",
	fireIncrease = "inc3",
	coldIncrease = "inc9",
	holyIncrease = "inc10",
	deathIncrease = "inc11",
	-- Ile procent ciosu fizycznego zamienia sie w zywiol. To, co znika z obrazen
	-- fizycznych, wraca jako drugi cios - ten zywiolem.
	physToLightning = "conv1",
	physToFire = "conv3",
	physToCold = "conv9",
	physToDeath = "conv11",
}

-- Mody liczone po stronie Lua - silnik ich nie zna. Wartosc mowi, gdzie sa czytane.
CREED.luaMods = {
	lifeIncrease = "condition",  -- % maksymalnego zycia, doliczane do warunku nizej
	manaIncrease = "condition",  -- % maksymalnej many, jw.
	lifeRegen = "regeneration",  -- zycie na sekunde, osobny warunek regeneracji
	manaRegen = "regeneration",  -- mana na sekunde, jw.
	spellIncrease = "spells",    -- % obrazen czarow, czyta SPELL_DAMAGE.range
	castSpeed = "casting",       -- % szybszego rzucania, czyta CASTING.start
}

-- Sufity przepisane z src/const.h (FATE_RESISTANCE_MAX, CONVERSION_MAX). Okno
-- Character ma pokazywac to, co naprawde dziala, wiec liczy bonusy po tych samych
-- regulach, co silnik. Zgodnosci obu liczb pilnuje tests/fate_mod_keys.py.
CREED.resistanceMax = 75
CREED.conversionMax = 100

-- Ostatnio przeliczone mody gracza, po guid. Bez tego kazdy rzut czaru musialby
-- przejsc 3037 wezlow drzewka. Staty trzymamy obok, bo inaczej okno Character nie
-- wiedzialoby, ile z naddatku przy statach przyszlo z drzewka, a ile z ekwipunku.
CREED.activeMods = type(previousCreed) == "table" and previousCreed.activeMods or {}
CREED.activeStats = type(previousCreed) == "table" and previousCreed.activeStats or {}
-- Parametry condition BEZ procentow zycia/many - z nich refreshCreedVitals sklada
-- warunek od nowa, bez przechodzenia calego drzewka.
CREED.activeParams = type(previousCreed) == "table" and previousCreed.activeParams or {}
CREED.noMods = {}

function CREED.modsOf(player)
	return CREED.activeMods[player:getGuid()] or CREED.noMods
end

function CREED.statsOf(player)
	return CREED.activeStats[player:getGuid()] or CREED.noMods
end

function CREED.forgetMods(player)
	CREED.activeMods[player:getGuid()] = nil
	CREED.activeStats[player:getGuid()] = nil
	CREED.activeParams[player:getGuid()] = nil
end

-- Ile procent obrazen fizycznych zamienia sie naprawde w dany zywiol. Powyzej sufitu
-- konwersje dziela sie proporcjonalnie zamiast zjadac sie nawzajem - tak samo liczy
-- to Player::getConversion, a okno ma nie obiecywac wiecej, niz cios dostanie.
function CREED.conversionOf(mods, name)
	local share = math.max(0, math.floor(mods[name] or 0))
	local total = 0
	for key, engineKey in pairs(CREED.engineMods) do
		if engineKey:match("^conv%d+$") then
			total = total + math.max(0, math.floor(mods[key] or 0))
		end
	end
	if total <= CREED.conversionMax then
		return share
	end
	return math.floor(share * CREED.conversionMax / total)
end

-- Odpornosc z drzewka na zywiol o podanym indeksie silnika (combatTypeToIndex),
-- juz po sufircie. Silnik liczy ja raz na trafienie, po ekwipunku (Player::blockHit).
function CREED.resistanceOf(mods, index)
	for name, engineKey in pairs(CREED.engineMods) do
		if engineKey == "res" .. index then
			local value = math.floor(mods[name] or 0)
			return value > CREED.resistanceMax and CREED.resistanceMax or value
		end
	end
	return 0
end

-- Pakiet dla silnika. Metody nie ma w starym binarium, a drzewko jest wczytywane
-- z Lua - bez tej oslony podmiana samych plikow data wywracalaby kazde logowanie.
function CREED.sendEngineMods(player, packed)
	if player.setFateMods then
		player:setFateMods(packed)
	elseif not CREED.warnedMissingEngineMods then
		CREED.warnedMissingEngineMods = true
		print("[Fate] Player:setFateMods is missing - rebuild the server binary, "
			.. "otherwise armour, energy shield, damage and resistance nodes do nothing.")
	end
end

CREED.specialParams = {
	critChance = CONDITION_PARAM_SPECIALSKILL_CRITICALHITCHANCE,
	critDamage = CONDITION_PARAM_SPECIALSKILL_CRITICALHITAMOUNT,
	lifeLeechChance = CONDITION_PARAM_SPECIALSKILL_LIFELEECHCHANCE,
	lifeLeechAmount = CONDITION_PARAM_SPECIALSKILL_LIFELEECHAMOUNT,
	manaLeechChance = CONDITION_PARAM_SPECIALSKILL_MANALEECHCHANCE,
	manaLeechAmount = CONDITION_PARAM_SPECIALSKILL_MANALEECHAMOUNT,
}

-- Wezly opisuja krytyki i leech w pelnych procentach ("+8% critical hit damage" = 8),
-- a silnik trzyma special skille w setnych procenta (SPECIAL_SKILL_FULL = 10000
-- w server/src/const.h, ta sama skala co w items.xml). Przeliczenie siedzi tutaj,
-- na granicy - dane wezlow zostaja czytelne. Bez niego +50% life leech oddawalo 0,5%.
CREED.specialScale = 100

-- Drzewka trzymane sa per wokacja bazowa (fromvoc). Podklasa dziedziczy drzewko
-- swojej bazy, wiec po wyborze galezi gracz dalej widzi cale drzewo.
CREED.trees = {}

-- Marauder ma wlasny, duzy uklad (404 wezly) i mieszka w osobnym pliku:
-- data/lib/core/creed_marauder.lua, ladowanym zaraz po tym. Pozostale wokacje
-- czekaja na przebudowe w tym samym stylu.

-- Warrior: Dyscyplina i przewaga w zwarciu. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[2] = {
	{id = 201, x = 0, y = -2, name = "Drilled", cost = 1,
	 info = "+2 Strength.", stats = {Strength = 2}},
	{id = 202, x = 0, y = -1, name = "Iron Discipline", cost = 1, requires = {201},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 203, x = 0, y = 0, name = "Battle Stance", cost = 2, requires = {202},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 210, x = -2, y = 0, name = "Titan", cost = 1, requires = {203}, subclass = 13,
	 info = "You take the path of the Titan."},
	{id = 220, x = 2, y = 0, name = "Warbringer", cost = 1, requires = {203}, subclass = 14,
	 info = "You take the path of the Warbringer."},
	{id = 230, x = 0, y = 2, name = "Warlord", cost = 1, requires = {203}, subclass = 15,
	 info = "You take the path of the Warlord."},

	-- Galaz Titan (w lewo)
	{id = 211, x = -3, y = 0, name = "Colossal Frame", cost = 2, requires = {210},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
	{id = 212, x = -4, y = 0, name = "Unyielding", cost = 3, requires = {211},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},

	-- Galaz Warbringer (w prawo)
	{id = 221, x = 3, y = 0, name = "Siege Breaker", cost = 2, requires = {220},
	 info = "+4 Strength.", stats = {Strength = 4}},
	{id = 222, x = 4, y = 0, name = "Devastate", cost = 3, requires = {221},
	 info = "+8% critical hit damage.", special = {critDamage = 8}},

	-- Galaz Warlord (w dol)
	{id = 231, x = 0, y = 3, name = "Banner of War", cost = 2, requires = {230},
	 info = "+2 Strength, +2 Vitality.", stats = {Strength = 2, Vitality = 2}},
	{id = 232, x = 0, y = 4, name = "Rally", cost = 3, requires = {231},
	 info = "+5 Attack Speed.", stats = {["Attack Speed"] = 5}},
}

-- Duelist: Precyzja i tempo. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[3] = {
	{id = 301, x = 0, y = -2, name = "Sure Grip", cost = 1,
	 info = "+2 Strength.", stats = {Strength = 2}},
	{id = 302, x = 0, y = -1, name = "Quick Hands", cost = 1, requires = {301},
	 info = "+2 Attack Speed.", stats = {["Attack Speed"] = 2}},
	{id = 303, x = 0, y = 0, name = "Duelist's Poise", cost = 2, requires = {302},
	 info = "+3 Vitality.", stats = {Vitality = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 310, x = -2, y = 0, name = "Slayer", cost = 1, requires = {303}, subclass = 16,
	 info = "You take the path of the Slayer."},
	{id = 320, x = 2, y = 0, name = "Gladiator", cost = 1, requires = {303}, subclass = 17,
	 info = "You take the path of the Gladiator."},
	{id = 330, x = 0, y = 2, name = "Champion", cost = 1, requires = {303}, subclass = 18,
	 info = "You take the path of the Champion."},

	-- Galaz Slayer (w lewo)
	{id = 311, x = -3, y = 0, name = "Executioner", cost = 2, requires = {310},
	 info = "+4 Strength.", stats = {Strength = 4}},
	{id = 312, x = -4, y = 0, name = "Deep Cuts", cost = 3, requires = {311},
	 info = "+8% critical hit damage.", special = {critDamage = 8}},

	-- Galaz Gladiator (w prawo)
	{id = 321, x = 3, y = 0, name = "Arena Veteran", cost = 2, requires = {320},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
	{id = 322, x = 4, y = 0, name = "Crowd Pleaser", cost = 3, requires = {321},
	 info = "+5 Attack Speed.", stats = {["Attack Speed"] = 5}},

	-- Galaz Champion (w dol)
	{id = 331, x = 0, y = 3, name = "Perfect Form", cost = 2, requires = {330},
	 info = "+2 Strength, +2 Vitality.", stats = {Strength = 2, Vitality = 2}},
	{id = 332, x = 0, y = 4, name = "Riposte", cost = 3, requires = {331},
	 info = "+3% critical hit chance.", special = {critChance = 3}},
}

-- Ranger: Dystans i teren. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[4] = {
	{id = 401, x = 0, y = -2, name = "Steady Aim", cost = 1,
	 info = "+2 Dexterity.", stats = {Dexterity = 2}},
	{id = 402, x = 0, y = -1, name = "Field Craft", cost = 1, requires = {401},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 403, x = 0, y = 0, name = "Quick Draw", cost = 2, requires = {402},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 410, x = -2, y = 0, name = "Deadeye", cost = 1, requires = {403}, subclass = 19,
	 info = "You take the path of the Deadeye."},
	{id = 420, x = 2, y = 0, name = "Warden", cost = 1, requires = {403}, subclass = 20,
	 info = "You take the path of the Warden."},
	{id = 430, x = 0, y = 2, name = "Pathfinder", cost = 1, requires = {403}, subclass = 21,
	 info = "You take the path of the Pathfinder."},

	-- Galaz Deadeye (w lewo)
	{id = 411, x = -3, y = 0, name = "Marksman", cost = 2, requires = {410},
	 info = "+4 Dexterity.", stats = {Dexterity = 4}},
	{id = 412, x = -4, y = 0, name = "Killing Shot", cost = 3, requires = {411},
	 info = "+3% critical hit chance.", special = {critChance = 3}},

	-- Galaz Warden (w prawo)
	{id = 421, x = 3, y = 0, name = "Thick Bark", cost = 2, requires = {420},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
	{id = 422, x = 4, y = 0, name = "Nature's Gift", cost = 3, requires = {421},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},

	-- Galaz Pathfinder (w dol)
	{id = 431, x = 0, y = 3, name = "Trailblazer", cost = 2, requires = {430},
	 info = "+2 Dexterity, +2 Vitality.", stats = {Dexterity = 2, Vitality = 2}},
	{id = 432, x = 0, y = 4, name = "Swift Feet", cost = 3, requires = {431},
	 info = "+5 Attack Speed.", stats = {["Attack Speed"] = 5}},
}

-- Shadow: Skrytobojstwo i trafienia krytyczne. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[5] = {
	{id = 501, x = 0, y = -2, name = "Silent Step", cost = 1,
	 info = "+2 Dexterity.", stats = {Dexterity = 2}},
	{id = 502, x = 0, y = -1, name = "Cold Blood", cost = 1, requires = {501},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 503, x = 0, y = 0, name = "Fast Hands", cost = 2, requires = {502},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 510, x = -2, y = 0, name = "Assassin", cost = 1, requires = {503}, subclass = 22,
	 info = "You take the path of the Assassin."},
	{id = 520, x = 2, y = 0, name = "Saboteur", cost = 1, requires = {503}, subclass = 23,
	 info = "You take the path of the Saboteur."},
	{id = 530, x = 0, y = 2, name = "Trickster", cost = 1, requires = {503}, subclass = 24,
	 info = "You take the path of the Trickster."},

	-- Galaz Assassin (w lewo)
	{id = 511, x = -3, y = 0, name = "Vital Points", cost = 2, requires = {510},
	 info = "+4% critical hit chance.", special = {critChance = 4}},
	{id = 512, x = -4, y = 0, name = "Lethal Strike", cost = 3, requires = {511},
	 info = "+8% critical hit damage.", special = {critDamage = 8}},

	-- Galaz Saboteur (w prawo)
	{id = 521, x = 3, y = 0, name = "Dirty Tricks", cost = 2, requires = {520},
	 info = "+4 Dexterity.", stats = {Dexterity = 4}},
	{id = 522, x = 4, y = 0, name = "Poisoned Blade", cost = 3, requires = {521},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},

	-- Galaz Trickster (w dol)
	{id = 531, x = 0, y = 3, name = "Sleight of Hand", cost = 2, requires = {530},
	 info = "+2 Dexterity, +2 Attack Speed.", stats = {Dexterity = 2, ["Attack Speed"] = 2}},
	{id = 532, x = 0, y = 4, name = "Vanish", cost = 3, requires = {531},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
}

-- Witch: Magia i gospodarka mana. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[6] = {
	{id = 601, x = 0, y = -2, name = "Arcane Focus", cost = 1,
	 info = "+2 Intelligence.", stats = {Intelligence = 2}},
	{id = 602, x = 0, y = -1, name = "Mana Well", cost = 1, requires = {601},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 603, x = 0, y = 0, name = "Swift Casting", cost = 2, requires = {602},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 610, x = -2, y = 0, name = "Necromancer", cost = 1, requires = {603}, subclass = 25,
	 info = "You take the path of the Necromancer."},
	{id = 620, x = 2, y = 0, name = "Occultist", cost = 1, requires = {603}, subclass = 26,
	 info = "You take the path of the Occultist."},
	{id = 630, x = 0, y = 2, name = "Lich", cost = 1, requires = {603}, subclass = 27,
	 info = "You take the path of the Lich."},

	-- Galaz Necromancer (w lewo)
	{id = 611, x = -3, y = 0, name = "Grave Bond", cost = 2, requires = {610},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 612, x = -4, y = 0, name = "Soul Siphon", cost = 3, requires = {611},
	 info = "+3% mana leech chance.", special = {manaLeechChance = 3}},

	-- Galaz Occultist (w prawo)
	{id = 621, x = 3, y = 0, name = "Forbidden Lore", cost = 2, requires = {620},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 622, x = 4, y = 0, name = "Blood Pact", cost = 3, requires = {621},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},

	-- Galaz Lich (w dol)
	{id = 631, x = 0, y = 3, name = "Phylactery", cost = 2, requires = {630},
	 info = "+2 Intelligence, +2 Vitality.", stats = {Intelligence = 2, Vitality = 2}},
	{id = 632, x = 0, y = 4, name = "Soul Cage", cost = 3, requires = {631},
	 info = "+8% critical hit damage.", special = {critDamage = 8}},
}

-- Sorcerer: Zywioly i czysta moc. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[7] = {
	{id = 701, x = 0, y = -2, name = "Elemental Spark", cost = 1,
	 info = "+2 Intelligence.", stats = {Intelligence = 2}},
	{id = 702, x = 0, y = -1, name = "Deep Reserves", cost = 1, requires = {701},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 703, x = 0, y = 0, name = "Rapid Incantation", cost = 2, requires = {702},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 710, x = -2, y = 0, name = "Elementalist", cost = 1, requires = {703}, subclass = 28,
	 info = "You take the path of the Elementalist."},
	{id = 720, x = 2, y = 0, name = "Stormweaver", cost = 1, requires = {703}, subclass = 29,
	 info = "You take the path of the Stormweaver."},
	{id = 730, x = 0, y = 2, name = "Infernalist", cost = 1, requires = {703}, subclass = 30,
	 info = "You take the path of the Infernalist."},

	-- Galaz Elementalist (w lewo)
	{id = 711, x = -3, y = 0, name = "Elemental Mastery", cost = 2, requires = {710},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 712, x = -4, y = 0, name = "Overload", cost = 3, requires = {711},
	 info = "+8% critical hit damage.", special = {critDamage = 8}},

	-- Galaz Stormweaver (w prawo)
	{id = 721, x = 3, y = 0, name = "Static Charge", cost = 2, requires = {720},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 722, x = 4, y = 0, name = "Chain Lightning", cost = 3, requires = {721},
	 info = "+3% mana leech chance.", special = {manaLeechChance = 3}},

	-- Galaz Infernalist (w dol)
	{id = 731, x = 0, y = 3, name = "Inner Fire", cost = 2, requires = {730},
	 info = "+2 Intelligence, +2 Vitality.", stats = {Intelligence = 2, Vitality = 2}},
	{id = 732, x = 0, y = 4, name = "Immolate", cost = 3, requires = {731},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},
}

-- Templar: Swiety wojownik. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[8] = {
	{id = 801, x = 0, y = -2, name = "Oath of Steel", cost = 1,
	 info = "+2 Strength.", stats = {Strength = 2}},
	{id = 802, x = 0, y = -1, name = "Faith", cost = 1, requires = {801},
	 info = "+2 Intelligence.", stats = {Intelligence = 2}},
	{id = 803, x = 0, y = 0, name = "Shield Wall", cost = 2, requires = {802},
	 info = "+3 Vitality.", stats = {Vitality = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 810, x = -2, y = 0, name = "Inquisitor", cost = 1, requires = {803}, subclass = 31,
	 info = "You take the path of the Inquisitor."},
	{id = 820, x = 2, y = 0, name = "Hierophant", cost = 1, requires = {803}, subclass = 32,
	 info = "You take the path of the Hierophant."},
	{id = 830, x = 0, y = 2, name = "Guardian", cost = 1, requires = {803}, subclass = 33,
	 info = "You take the path of the Guardian."},

	-- Galaz Inquisitor (w lewo)
	{id = 811, x = -3, y = 0, name = "Zeal", cost = 2, requires = {810},
	 info = "+4 Strength.", stats = {Strength = 4}},
	{id = 812, x = -4, y = 0, name = "Purge", cost = 3, requires = {811},
	 info = "+3% critical hit chance.", special = {critChance = 3}},

	-- Galaz Hierophant (w prawo)
	{id = 821, x = 3, y = 0, name = "Sacred Word", cost = 2, requires = {820},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 822, x = 4, y = 0, name = "Blessed Vigor", cost = 3, requires = {821},
	 info = "+3% mana leech chance.", special = {manaLeechChance = 3}},

	-- Galaz Guardian (w dol)
	{id = 831, x = 0, y = 3, name = "Bulwark", cost = 2, requires = {830},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
	{id = 832, x = 0, y = 4, name = "Aegis", cost = 3, requires = {831},
	 info = "+3% life leech chance.", special = {lifeLeechChance = 3}},
}

-- Priest: Wsparcie i wiara. Pien schodzi z gory do centrum, stamtad trzy sciezki
-- rozchodza sie w lewo, w prawo i w dol.
CREED.trees[9] = {
	{id = 901, x = 0, y = -2, name = "Devotion", cost = 1,
	 info = "+2 Intelligence.", stats = {Intelligence = 2}},
	{id = 902, x = 0, y = -1, name = "Inner Calm", cost = 1, requires = {901},
	 info = "+2 Vitality.", stats = {Vitality = 2}},
	{id = 903, x = 0, y = 0, name = "Litany", cost = 2, requires = {902},
	 info = "+3 Attack Speed.", stats = {["Attack Speed"] = 3}},

	-- Rozwidlenie w centrum: trzy podklasy, kazda w innym kierunku
	{id = 910, x = -2, y = 0, name = "Seraph", cost = 1, requires = {903}, subclass = 34,
	 info = "You take the path of the Seraph."},
	{id = 920, x = 2, y = 0, name = "Oracle", cost = 1, requires = {903}, subclass = 35,
	 info = "You take the path of the Oracle."},
	{id = 930, x = 0, y = 2, name = "Zealot", cost = 1, requires = {903}, subclass = 36,
	 info = "You take the path of the Zealot."},

	-- Galaz Seraph (w lewo)
	{id = 911, x = -3, y = 0, name = "Wings of Light", cost = 2, requires = {910},
	 info = "+4 Intelligence.", stats = {Intelligence = 4}},
	{id = 912, x = -4, y = 0, name = "Grace", cost = 3, requires = {911},
	 info = "+3% mana leech chance.", special = {manaLeechChance = 3}},

	-- Galaz Oracle (w prawo)
	{id = 921, x = 3, y = 0, name = "Foresight", cost = 2, requires = {920},
	 info = "+4 Vitality.", stats = {Vitality = 4}},
	{id = 922, x = 4, y = 0, name = "Prophecy", cost = 3, requires = {921},
	 info = "+3% critical hit chance.", special = {critChance = 3}},

	-- Galaz Zealot (w dol)
	{id = 931, x = 0, y = 3, name = "Fervor", cost = 2, requires = {930},
	 info = "+2 Strength, +2 Intelligence.", stats = {Strength = 2, Intelligence = 2}},
	{id = 932, x = 0, y = 4, name = "Martyr", cost = 3, requires = {931},
	 info = "+4% life leech chance.", special = {lifeLeechChance = 4}},
}

-- ------------------------------------------------------------------
-- Wyszukiwanie
-- ------------------------------------------------------------------

local combinedTrees = {}
CREED.legacyTalentNodes = {}

function CREED.initializeFate()
    combinedTrees = {}
    CREED.legacyTalentNodes = {}
    for vocationId, nodes in pairs(CREED.trees) do
        if vocationId ~= 1 then
            for _, node in ipairs(nodes) do
                CREED.legacyTalentNodes[#CREED.legacyTalentNodes + 1] = node
                node.pool = "talent"
            end
        end
    end
end

function CREED.getTree(player)
    local vocation = player:getVocation()
    local base = vocation and (vocation:getDemotion() or vocation)
    local baseId = base and base:getId() or 0
    -- Fallback keeps older standalone consumers functional until Fate is loaded.
    if not CREED.passives then return CREED.trees[baseId] end
    if not combinedTrees[baseId] then
        local nodes = {}
        for _, node in ipairs(CREED.passives) do nodes[#nodes + 1] = node end
        for _, node in ipairs(CREED.trees[baseId] or {}) do
            if node.pool == "talent" then nodes[#nodes + 1] = node end
        end
        combinedTrees[baseId] = nodes
    end
    return combinedTrees[baseId]
end

local nodeIndexes = setmetatable({}, {__mode = "k"})

function CREED.findNode(tree, id)
	if not tree then
		return nil
	end
	local index = nodeIndexes[tree]
	if not index then
		index = {}
		for _, node in ipairs(tree) do
			index[node.id] = node
		end
		nodeIndexes[tree] = index
	end
	return index[id]
end

-- ------------------------------------------------------------------
-- Punkty i posiadane wezly
-- ------------------------------------------------------------------

function CREED.totalForLevel(pool, level)
	local cfg = CREED.pools[pool]
	return math.max(0, level - cfg.fromLevel) * cfg.pointsPerLevel
end

function Player.getCreedPoints(self, pool)
	pool = pool or CREED.defaultPool
	return math.max(0, self:getStorageValue(CREED.pools[pool].points))
end

function Player.setCreedPoints(self, pool, amount)
	return self:setStorageValue(CREED.pools[pool].points, math.max(0, amount))
end

-- Suma AKTUALNYCH cen wezlow, ktore gracz ma w danej puli.
local function ownedNodesCost(player, pool)
	local total = 0
	for _, node in ipairs(CREED.getTree(player) or {}) do
		if not node.granted and CREED.poolOf(node) == pool and player:hasCreedNode(node) then
			total = total + (node.cost or 1)
		end
	end
	return total
end

-- Zapisuje, ile punktow gracz FAKTYCZNIE zaplacil w puli. Reset oddaje te liczbe,
-- a nie sume aktualnych cen: po zmianie ceny wezla w definicjach reset dawal inna
-- pule niz ta, ktora gracz wydal (kupno za 1, podwyzka do 4, reset = +3 punkty).
-- Wolac PRZED zapisaniem nowych wezlow - postac sprzed licznika startuje od
-- aktualnych cen tego, co juz ma.
function CREED.recordSpent(player, pool, cost)
	local key = CREED.pools[pool].spent
	local stored = player:getStorageValue(key)
	if stored < 0 then
		stored = ownedNodesCost(player, pool)
	end
	player:setStorageValue(key, stored + cost)
end

-- Dosypuje punkty za levele, za ktore gracz jeszcze ich nie dostal - tak samo jak
-- punkty statow, wiec dziala tez dla postaci sprzed wprowadzenia drzewka. Kazda pula
-- ma wlasny licznik "do ktorego levelu juz zaplacono", wiec pule mozna dodawac
-- pozniej: nowa zaczyna naliczac od swojego fromLevel, nie od zera.
function Player.migrateFatePoints(self)
    local key = PlayerStorageKeys.creedFateMigration
    if self:getStorageValue(key) == 1 then return end
    local spent = 0
    for _, node in ipairs(CREED.legacyTalentNodes) do
        if not node.granted and self:hasCreedNode(node) then
            spent = spent + (node.cost or 1)
        end
    end
    if spent > 0 then
        self:setCreedPoints("passive", self:getCreedPoints("passive") + spent)
        self:setCreedPoints("talent", self:getCreedPoints("talent") - spent)
    end
    self:setStorageValue(key, 1)
end

function Player.syncCreedPoints(self)
	local level = self:getLevel()
	local gained = {}

	for pool, cfg in pairs(CREED.pools) do
		local paidFor = self:getStorageValue(cfg.paidFor)
		if paidFor < 0 then
			paidFor = cfg.fromLevel
		end

		if level > paidFor then
			local amount = CREED.totalForLevel(pool, level) - CREED.totalForLevel(pool, paidFor)
			self:setStorageValue(cfg.paidFor, level)
			if amount > 0 then
				self:setCreedPoints(pool, self:getCreedPoints(pool) + amount)
				gained[pool] = amount
			end
		end
	end

	self:migrateFatePoints()

	-- Licznik wydanych punktow (CREED.recordSpent) dla postaci, ktora go jeszcze nie
	-- ma: startuje od aktualnych cen posiadanych wezlow. Robimy to tutaj, przy
	-- logowaniu, zeby pierwszy zakup nie musial przechodzic calego drzewka.
	for pool, cfg in pairs(CREED.pools) do
		if self:getStorageValue(cfg.spent) < 0 then
			self:setStorageValue(cfg.spent, ownedNodesCost(self, pool))
		end
	end
	return gained
end

function Player.hasCreedNode(self, node)
	-- Wezel z granted = true gracz ma od wejscia do gry: nie kupuje sie go, nie
	-- kosztuje i nie da sie go zresetowac. Tak stoi korzen drzewka - inaczej gracz
	-- patrzylby na drzewko, w ktorym nie ma jeszcze ani jednego punktu zaczepienia.
	if node.granted then
		return true
	end
	return self:getStorageValue(CREED.nodeStorageBase + node.id) > 0
end

function Player.setCreedNode(self, node, owned, choice)
	-- Mastery trzyma w storage numer wybranego efektu, a nie samo "kupione". Reszta
	-- wezlow zapisuje 1, wiec hasCreedNode (> 0) dziala tak samo dla jednych i drugich.
	local value = choice and math.max(1, math.floor(choice)) or 1
	return self:setStorageValue(CREED.nodeStorageBase + node.id, owned and value or -1)
end

-- Ktory efekt mastery wybral gracz. Zwraca nil dla wezlow bez wyboru i dla
-- niekupionych; numer poza lista traktujemy jak pierwszy efekt, zeby uszkodzony
-- zapis nie zostawil wezla bez zadnego bonusu.
function CREED.chosenEffect(player, node)
	if not node.effects then
		return nil
	end
	local stored = player:getStorageValue(CREED.nodeStorageBase + node.id)
	if stored <= 0 then
		return nil
	end
	return node.effects[stored] or node.effects[1]
end

-- Czy wezel jest osiagalny: wszystkie wymagane wezly kupione. Bramy pozostalych
-- podklas przestaja byc osiagalne natychmiast po wybraniu jednej z trzech, dzieki
-- czemu klient oznacza dwa niewybrane kwadraty jako wylaczone i wyszarzone.
function Player.canReachCreedNode(self, tree, node)
	if node.subclass then
		for _, other in ipairs(tree or {}) do
			if other.id ~= node.id and other.subclass and self:hasCreedNode(other) then
				return false
			end
		end
	end

    -- Fate is an undirected network: any adjacent owned node opens the path.
    -- Spells retains its class gates and original AND prerequisites.
    if node.neighbors then
        for _, id in ipairs(node.neighbors) do
            local adjacent = CREED.findNode(tree, id)
            if adjacent and self:hasCreedNode(adjacent) then return true end
        end
        return false
    end

	for _, requiredId in ipairs(node.requires or {}) do
		local required = CREED.findNode(tree, requiredId)
		if not required or not self:hasCreedNode(required) then
			return false
		end
	end
	return true
end

-- ------------------------------------------------------------------
-- Efekty
-- ------------------------------------------------------------------

-- Naklada bezterminowy condition drzewka: stale parametry (staty, special skille)
-- plus procenty zycia/many. Procenty licza sie od maksa BEZ naszego warunku - stad
-- najpierw zdjecie starego - czyli od bazy z levela, statow i ekwipunku.
--
-- Zdjecie warunku przycina aktualne hp/mane do nizszego maksa, wiec zapamietujemy je
-- i po nalozeniu nowego oddajemy (ale nigdy ponad nowe maksimum - tego pilnuje silnik).
local function applyAttributeCondition(player, baseParams, mods)
	local currentHealth, currentMana = player:getHealth(), player:getMana()
	player:removeCondition(CONDITION_ATTRIBUTES, CONDITIONID_DEFAULT, CREED.conditionSubId)

	local params = {}
	for param, value in pairs(baseParams) do
		params[param] = value
	end
	local function addParam(param, value)
		if value ~= 0 then
			params[param] = (params[param] or 0) + value
		end
	end
	addParam(CONDITION_PARAM_STAT_MAXHITPOINTS,
		math.floor(player:getMaxHealth() * (mods.lifeIncrease or 0) / 100))
	addParam(CONDITION_PARAM_STAT_MAXMANAPOINTS,
		math.floor(player:getMaxMana() * (mods.manaIncrease or 0) / 100))

	local hasAny = false
	local condition = Condition(CONDITION_ATTRIBUTES, CONDITIONID_DEFAULT)
	condition:setParameter(CONDITION_PARAM_TICKS, -1)
	condition:setParameter(CONDITION_PARAM_SUBID, CREED.conditionSubId)
	for param, value in pairs(params) do
		if value ~= 0 then
			condition:setParameter(param, value)
			hasAny = true
		end
	end
	if hasAny then
		player:addCondition(condition)
	end

	if player:getHealth() < currentHealth then
		player:addHealth(currentHealth - player:getHealth())
	end
	if player:getMana() < currentMana then
		player:addMana(currentMana - player:getMana())
	end
end

-- Bonusy ida trzema kanalami, zaleznie od tego, kto je liczy:
--   * staty i special skille - jeden bezterminowy condition (tak bylo od poczatku),
--   * armor, energy shield, obrazenia fizyczne, odpornosci, predkosc - pakiet dla
--     silnika (Player:setFateMods, patrz FateMods w src/player.h),
--   * procenty zycia/many, regeneracja i obrazenia czarow - policzone tutaj.
-- Dzieki temu przeliczenie po zmianie balansu to samo wylogowanie: nic nie siedzi
-- w bazie poza lista kupionych wezlow.
function Player.applyCreed(self)
	local tree = CREED.getTree(self)
	if not tree then
		self:removeCondition(CONDITION_ATTRIBUTES, CONDITIONID_DEFAULT, CREED.conditionSubId)
		self:removeCondition(CONDITION_REGENERATION, CONDITIONID_DEFAULT, CREED.conditionSubId)
		CREED.forgetMods(self)
		CREED.sendEngineMods(self, "")
		return
	end

	local stats, specials, mods = {}, {}, {}
	for _, node in ipairs(tree) do
		if self:hasCreedNode(node) then
			-- Mastery daje to, co gracz wybral przy kupnie - reszta pol wezla jest pusta.
			local chosen = CREED.chosenEffect(self, node)
			if chosen then
				for name, value in pairs(chosen.stats or {}) do
					stats[name] = (stats[name] or 0) + value
				end
				for name, value in pairs(chosen.special or {}) do
					specials[name] = (specials[name] or 0) + value
				end
				for name, value in pairs(chosen.mods or {}) do
					mods[name] = (mods[name] or 0) + value
				end
			end
			for name, value in pairs(node.stats or {}) do
				stats[name] = (stats[name] or 0) + value
			end
			for name, value in pairs(node.special or {}) do
				specials[name] = (specials[name] or 0) + value
			end
			for name, value in pairs(node.mods or {}) do
				mods[name] = (mods[name] or 0) + value
			end
			if node.spell then
				self:learnSpell(node.spell)
			end
		end
	end

	CREED.activeMods[self:getGuid()] = mods
	CREED.activeStats[self:getGuid()] = stats

	-- Pakiet dla silnika. Sortujemy, zeby ten sam zestaw dawal zawsze ten sam tekst -
	-- inaczej porownanie w testach zalezaloby od kolejnosci pairs().
	local packed = {}
	for name, value in pairs(mods) do
		local key = CREED.engineMods[name]
		if key and math.floor(value) ~= 0 then
			packed[#packed + 1] = string.format("%s:%d", key, math.floor(value))
		end
	end
	table.sort(packed)
	CREED.sendEngineMods(self, table.concat(packed, ";"))

	-- Parametry zbieramy do tabeli, bo kilka zrodel trafia w ten sam parametr:
	-- Vitality i lifeIncrease oba podnosza maksymalne hp.
	local params = {}
	for name, value in pairs(stats) do
		local param = CREED.statParams[name]
		if param and value ~= 0 then
			params[param] = (params[param] or 0) + value * (CREED.statScale[name] or 1)
		end
	end
	for name, value in pairs(specials) do
		local param = CREED.specialParams[name]
		if param and value ~= 0 then
			params[param] = (params[param] or 0) + value * CREED.specialScale
		end
	end

	-- Stale parametry zostaja w pamieci: refreshCreedVitals doklada do nich swieze
	-- procenty zycia/many bez przechodzenia calego drzewka.
	CREED.activeParams[self:getGuid()] = params
	applyAttributeCondition(self, params, mods)

	-- Regeneracja to osobny typ warunku, wiec nie zmiesci sie w tym wyzej.
	self:removeCondition(CONDITION_REGENERATION, CONDITIONID_DEFAULT, CREED.conditionSubId)
	local lifeRegen, manaRegen = math.floor(mods.lifeRegen or 0), math.floor(mods.manaRegen or 0)
	if lifeRegen > 0 or manaRegen > 0 then
		local regeneration = Condition(CONDITION_REGENERATION, CONDITIONID_DEFAULT)
		regeneration:setParameter(CONDITION_PARAM_TICKS, -1)
		regeneration:setParameter(CONDITION_PARAM_SUBID, CREED.conditionSubId)
		if lifeRegen > 0 then
			regeneration:setParameter(CONDITION_PARAM_HEALTHGAIN, lifeRegen)
			regeneration:setParameter(CONDITION_PARAM_HEALTHTICKS, 1000)
		end
		if manaRegen > 0 then
			regeneration:setParameter(CONDITION_PARAM_MANAGAIN, manaRegen)
			regeneration:setParameter(CONDITION_PARAM_MANATICKS, 1000)
		end
		self:addCondition(regeneration)
	end
end

-- Procenty zycia/many z drzewka sa migawka maksimum z chwili przeliczenia: po
-- zalozeniu przedmiotu z +100 hp gracz mial 685 zamiast 700, a po resecie Vitality
-- zostawal mu caly procent starej wartosci. Ta funkcja przelicza sam warunek na
-- aktualnej bazie. Wolana po zmianie ekwipunku (Player:onInventoryUpdate, z
-- odroczeniem), po wydaniu/resecie punktow statow i po awansie.
function Player.refreshCreedVitals(self)
	local guid = self:getGuid()
	local mods = CREED.activeMods[guid]
	if not mods or ((mods.lifeIncrease or 0) == 0 and (mods.manaIncrease or 0) == 0) then
		-- bez procentow warunek nie zalezy od bazy
		return false
	end

	local params = CREED.activeParams[guid]
	if not params then
		self:applyCreed()
		return true
	end

	applyAttributeCondition(self, params, mods)
	return true
end

-- Ekwipunek zmienia sie seriami (logowanie zaklada kazdy slot po kolei), a silnik
-- wola hak w trakcie przenoszenia przedmiotu. Przeliczenie idzie wiec raz, po
-- wszystkim - jedno zdarzenie na postac.
local pendingVitalsRefresh = {}

function CREED.scheduleVitalsRefresh(player)
	local mods = CREED.activeMods[player:getGuid()]
	if not mods or ((mods.lifeIncrease or 0) == 0 and (mods.manaIncrease or 0) == 0) then
		return
	end

	local playerId = player:getId()
	if pendingVitalsRefresh[playerId] then
		return
	end
	pendingVitalsRefresh[playerId] = true
	addEvent(function(id)
		pendingVitalsRefresh[id] = nil
		local target = Player(id)
		if target then
			target:refreshCreedVitals()
		end
	end, 50, playerId)
end

-- Logowanie odtwarza bonusy do maksimum po kolei (ekwipunek, Vitality/Spirit,
-- drzewko), a kazdy krok przycina aktualne hp/mane do swojego, posredniego maksimum.
-- Zapisane 3000/3000 hp wracalo wiec jako 1500/3000. Po wszystkim oddajemy to, co
-- bylo w bazie (Player:getLoginVitals z silnika) - ale nie wiecej, wiec logowanie
-- nikogo nie leczy. Po smierci (znacznik z player_death.lua) postac wstaje z pelnymi
-- zasobami: silnik ustawia jej wtedy same bazowe healthMax/manaMax, bez bonusow.
function CREED.restoreLoginVitals(player, savedHealth, savedMana)
	local respawned = player:getStorageValue(PlayerStorageKeys.respawnFullVitals) == 1
	if respawned then
		player:setStorageValue(PlayerStorageKeys.respawnFullVitals, -1)
	end

	local targetHealth, targetMana = savedHealth, savedMana
	if respawned and player:getSkull() ~= SKULL_BLACK then
		-- black skull ma w silniku osobna regule: 40 hp i 0 many
		targetHealth, targetMana = player:getMaxHealth(), player:getMaxMana()
	end

	if targetHealth then
		targetHealth = math.min(targetHealth, player:getMaxHealth())
		if player:getHealth() < targetHealth then
			player:addHealth(targetHealth - player:getHealth())
		end
	end
	if targetMana then
		targetMana = math.min(targetMana, player:getMaxMana())
		if player:getMana() < targetMana then
			player:addMana(targetMana - player:getMana())
		end
	end
end

-- Po /reload global: definicje wezlow mogly sie zmienic, a condition i pakiet modow
-- w silniku pochodza jeszcze ze starych. Jedno przeliczenie dla kazdego zalogowanego.
function CREED.reapplyAll()
	for _, player in ipairs(Game.getPlayers()) do
		player:applyCreed()
	end
end


-- ------------------------------------------------------------------
-- Kupowanie i reset
-- ------------------------------------------------------------------

-- Zwraca true albo false + powod.
function Player.buyCreedNode(self, nodeId, choice)
	local tree = CREED.getTree(self)
	if not tree then
		return false, "Your vocation has no tree."
	end

	local node = CREED.findNode(tree, nodeId)
	if not node then
		return false, "There is no such node."
	end

	if self:hasCreedNode(node) then
		return false, "This node is already unlocked."
	end

	-- Podklase wybiera sie raz. Sprawdzamy to przed ogolnym testem osiagalnosci,
	-- aby klikniecie z nieaktualnego klienta nadal zwracalo precyzyjny powod.
	if node.subclass then
		for _, other in ipairs(tree) do
			if other.subclass and self:hasCreedNode(other) then
				return false, "You have already chosen a subclass."
			end
		end
	end

	if not self:canReachCreedNode(tree, node) then
		return false, "Unlock the nodes leading to this one first."
	end

	-- Mastery kupuje sie razem z wyborem efektu. Numer sprawdzamy tutaj, bo pozniej
	-- jest juz tylko zapis do storage - a zly numer zostawilby wezel bez bonusu.
	if node.effects then
		choice = tonumber(choice)
		if not choice or choice ~= math.floor(choice) or not node.effects[choice] then
			return false, "Choose one of this mastery's effects."
		end
	elseif choice ~= nil then
		return false, "This node has nothing to choose."
	end

	local cost = node.cost or 1
	local pool = CREED.poolOf(node)
	if self:getCreedPoints(pool) < cost then
		-- "1 talent point", a nie "1 talent points" - tytul puly jest w liczbie mnogiej.
		local title = string.lower(CREED.pools[pool].title)
		if cost == 1 then
			title = title:gsub("s$", "")
		end
		return false, string.format("You need %d %s, you have %d.", cost, title,
			self:getCreedPoints(pool))
	end

	CREED.recordSpent(self, pool, cost)
	self:setCreedPoints(pool, self:getCreedPoints(pool) - cost)
	self:setCreedNode(node, true, node.effects and choice or nil)

	if node.subclass then
		self:setVocation(Vocation(node.subclass))
	end

	self:applyCreed()
	return true
end

-- Shift-click in Fate buys the shortest route from any already owned node.
-- Search only on demand, from the target outwards: the first owned endpoint
-- gives the fewest new nodes, including shortcuts around the shared rings.
-- Validate and price the entire route before changing storage or conditions.
function Player.buyCreedPath(self, nodeId)
    local tree = CREED.passives
    local target = CREED.findNode(tree, nodeId)
    -- Mastery wymaga wyboru efektu, wiec nie da sie go kupic jednym klikiem sciezki.
    if not target or CREED.poolOf(target) ~= "passive" or not target.neighbors
        or target.subclass or target.effects then
        return false, "Path purchase is only available in Fate."
    end
    if self:hasCreedNode(target) then
        return false, "This node is already unlocked."
    end

    local queue, head = {target}, 1
    local visited, nextNode = {[target.id] = true}, {}
    local endpoint
    while head <= #queue and not endpoint do
        local node = queue[head]
        head = head + 1
        for _, id in ipairs(node.neighbors) do
            if not visited[id] then
                visited[id] = true
                local adjacent = CREED.findNode(tree, id)
                -- Sciezka omija mastery: kupno jednym klikiem nie ma jak zapytac
                -- o wybor efektu, a wezel bez wyboru nie dawalby nic.
                if adjacent and CREED.poolOf(adjacent) == "passive"
                    and adjacent.neighbors and not adjacent.subclass
                    and not adjacent.effects then
                    nextNode[id] = node
                    if self:hasCreedNode(adjacent) then
                        endpoint = adjacent
                        break
                    end
                    queue[#queue + 1] = adjacent
                end
            end
        end
    end
    if not endpoint then
        return false, "There is no path from your unlocked Fate nodes."
    end

    local path, cost, planned = {}, 0, {[endpoint.id] = true}
    local node = nextNode[endpoint.id]
    while node do
        local reachable = false
        for _, id in ipairs(node.neighbors) do
            local adjacent = CREED.findNode(tree, id)
            if planned[id] or (adjacent and self:hasCreedNode(adjacent)) then
                reachable = true
                break
            end
        end
        if not reachable then
            return false, "There is no path from your unlocked Fate nodes."
        end
        path[#path + 1] = node
        cost = cost + (node.cost or 1)
        planned[node.id] = true
        node = nextNode[node.id]
    end

    local points = self:getCreedPoints("passive")
    if points < cost then
        return false, string.format("This path needs %d passive points, you have %d. No points were spent.",
            cost, points)
    end

    CREED.recordSpent(self, "passive", cost)
    self:setCreedPoints("passive", points - cost)
    for _, selected in ipairs(path) do
        self:setCreedNode(selected, true)
    end
    self:applyCreed()
    return true, nil, #path, cost
end

local FATE_PLAN_MAX_NODES = 3152
local FATE_PLAN_MAX_BYTES = 7600

-- The request fits one extended-opcode string even for a fully planned Fate:
-- {action = "buyPlan", ranges = "1100-1136,3000-3001"}. Ranges must be ordered,
-- non-overlapping positive integers. Irregular selections can use a hex bitmap:
-- "@1000:9" selects 1000 and 1003 (low bit first in each nibble). Check expansion
-- bounds before allocating; neither representation trusts client-side pricing.
function CREED.decodePlanRanges(ranges)
    local invalid = "Invalid Fate plan. No points were spent."
    if type(ranges) ~= "string" or #ranges == 0 or #ranges > FATE_PLAN_MAX_BYTES then
        return nil, invalid
    end
    if ranges:sub(1, 1) == "@" then
        local base, hex = ranges:match("^@([1-9]%d*):([%da-fA-F]+)$")
        base = tonumber(base)
        if not base or base + #hex * 4 - 1 > 1000000 then return nil, invalid end
        local ids = {}
        for offset = 1, #hex do
            local value = tonumber(hex:sub(offset, offset), 16)
            for bit = 0, 3 do
                if value % 2 == 1 then
                    if #ids == FATE_PLAN_MAX_NODES then return nil, invalid end
                    ids[#ids + 1] = base + (offset - 1) * 4 + bit
                end
                value = math.floor(value / 2)
            end
        end
        if #ids == 0 then return nil, invalid end
        return ids
    end
    if ranges:find("[^%d,%-]") or ranges:sub(1, 1) == ","
        or ranges:sub(-1) == "," or ranges:find(",,", 1, true) then
        return nil, invalid
    end
    local ids, previous = {}, 0
    for token in ranges:gmatch("[^,]+") do
        local first, last = token:match("^([1-9]%d*)%-([1-9]%d*)$")
        if first then
            first, last = tonumber(first), tonumber(last)
            if not first or not last or last <= first then return nil, invalid end
        else
            first = token:match("^[1-9]%d*$") and tonumber(token)
            last = first
        end
        if not first or first <= previous or last > 2147483647
            or #ids + last - first + 1 > FATE_PLAN_MAX_NODES then
            return nil, invalid
        end
        for id = first, last do ids[#ids + 1] = id end
        previous = last
    end
    return ids
end

-- A plan is one transaction: price and validate the whole induced undirected
-- network before writing any player storage. Already owned IDs are accepted
-- without another charge, allowing retries and plans from a stale client.
-- Duplicate IDs inside the same request are malformed and are rejected.
function Player.buyCreedPlan(self, nodeIds, choices)
    local invalid = "Invalid Fate plan. No points were spent."
    if type(nodeIds) ~= "table" then return false, invalid end
    -- choices przychodzi prosto z pakietu klienta: liczba albo true wywracaly
    -- indeksowanie choices[id] bledem Lua zamiast zwyklej odmowy planu.
    if choices ~= nil and type(choices) ~= "table" then return false, invalid end
    local count, lastIndex = 0, 0
    for index in pairs(nodeIds) do
        if type(index) ~= "number" or index < 1 or index > FATE_PLAN_MAX_NODES
            or index ~= math.floor(index) then
            return false, invalid
        end
        count, lastIndex = count + 1, math.max(lastIndex, index)
    end
    if count == 0 or count ~= lastIndex then return false, invalid end

    local tree = CREED.passives
    if not tree then return false, "No Fate tree is available." end
    local selected, ownership, newNodes, cost = {}, {}, {}, 0
    for _, id in ipairs(nodeIds) do
        if type(id) ~= "number" or id ~= id or id < 1 or id > 2147483647
            or id ~= math.floor(id) or selected[id] then
            return false, invalid
        end
        local node = CREED.findNode(tree, id)
        if not node or CREED.poolOf(node) ~= "passive" or type(node.neighbors) ~= "table"
            or node.subclass or node.granted or node.kind == "root" then
            return false, "Only paid Fate passive nodes can be planned. No points were spent."
        end
        -- Mastery wchodzi do planu razem z wyborem efektu. Bez niego wezel wpadlby
        -- do drzewka bez zadnego bonusu, wiec caly plan jest odrzucany.
        if node.effects then
            local choice = tonumber(choices and (choices[id] or choices[tostring(id)]))
            if not choice or choice ~= math.floor(choice) or not node.effects[choice] then
                return false, "Every planned mastery needs a chosen effect. No points were spent."
            end
        end
        selected[id] = true
        ownership[id] = self:hasCreedNode(node)
        if not ownership[id] then
            newNodes[#newNodes + 1] = node
            cost = cost + (node.cost or 1)
        end
    end

    local points = self:getCreedPoints("passive")
    if cost > points then
        return false, string.format("This plan needs %d passive points, you have %d. No points were spent.",
            cost, points)
    end
    if #newNodes == 0 then return true, nil, 0, 0 end

    local allowed, edges, reached, queue = {}, {}, {}, {}
    for _, node in ipairs(tree) do
        if CREED.poolOf(node) == "passive" and type(node.neighbors) == "table" and not node.subclass then
            local owned = ownership[node.id]
            if owned == nil then owned = self:hasCreedNode(node) end
            if owned or selected[node.id] then
                allowed[node.id], edges[node.id] = node, {}
                if owned then
                    reached[node.id] = true
                    queue[#queue + 1] = node.id
                end
            end
        end
    end
    -- Treat either neighbor declaration as the same edge. All allowed nodes
    -- are passive, so a class talent cannot bridge otherwise isolated islands.
    for id, node in pairs(allowed) do
        for _, neighbor in ipairs(node.neighbors) do
            if allowed[neighbor] then
                edges[id][#edges[id] + 1] = neighbor
                edges[neighbor][#edges[neighbor] + 1] = id
            end
        end
    end
    local head = 1
    while head <= #queue do
        local id = queue[head]
        head = head + 1
        for _, neighbor in ipairs(edges[id]) do
            if not reached[neighbor] then
                reached[neighbor] = true
                queue[#queue + 1] = neighbor
            end
        end
    end
    for _, node in ipairs(newNodes) do
        if not reached[node.id] then
            return false, "The plan must connect to your unlocked Fate nodes. No points were spent."
        end
    end

    CREED.recordSpent(self, "passive", cost)
    self:setCreedPoints("passive", points - cost)
    for _, node in ipairs(newNodes) do
        local choice = node.effects
            and tonumber(choices and (choices[node.id] or choices[tostring(node.id)]))
        self:setCreedNode(node, true, choice)
    end
    self:applyCreed()
    return true, nil, #newNodes, cost
end

-- Reset wybranej puli (lub obu przy braku argumentu dla starszych klientow).
-- Podklasa wraca do bazy tylko przy resecie jej wezla. Zwraca {pula = zwrot}.
function Player.resetCreed(self, selectedPool)
	if selectedPool ~= nil and not CREED.pools[selectedPool] then
		return {}
	end
	local tree = CREED.getTree(self)
	if not tree then
		return {}
	end

	-- Stan licznikow wydanych punktow sprzed kasowania wezlow.
	local recorded = {}
	for pool, cfg in pairs(CREED.pools) do
		recorded[pool] = self:getStorageValue(cfg.spent)
	end

	local refunded = {}
	local hadSubclass = false
	for _, node in ipairs(tree) do
		if not node.granted and self:hasCreedNode(node)
			and (selectedPool == nil or CREED.poolOf(node) == selectedPool) then
			local pool = CREED.poolOf(node)
			refunded[pool] = (refunded[pool] or 0) + (node.cost or 1)
			self:setCreedNode(node, false)
			if node.spell then
				self:forgetSpell(node.spell)
			end
			if node.subclass then
				hadSubclass = true
			end
		end
	end

	if hadSubclass then
		local base = self:getVocation():getDemotion()
		if base then
			self:setVocation(base)
		end
	end

	for pool, amount in pairs(refunded) do
		-- Zwrot to zapisana kwota wydana, nie suma dzisiejszych cen. Postac sprzed
		-- licznika (-1) dostaje po staremu aktualne ceny.
		if recorded[pool] >= 0 then
			amount = recorded[pool]
			refunded[pool] = amount
		end
		self:setStorageValue(CREED.pools[pool].spent, 0)
		self:setCreedPoints(pool, self:getCreedPoints(pool) + amount)
	end

	self:applyCreed()
	return refunded
end
