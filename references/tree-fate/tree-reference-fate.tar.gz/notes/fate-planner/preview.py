#!/usr/bin/env python3
"""Render a standalone preview from real Fate/PoB geometry and unchanged assets.

Run from any directory: python3 /path/to/tfs1098/notes/fate-planner/preview.py
This is a data preview, never a captured or emulated game-client screenshot.
Only the two preview artifacts in this directory are written.
"""
from collections import Counter, deque
from pathlib import Path
import base64
import ctypes
import ctypes.util
import html
import math
import os
import runpy
import struct

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ASSETS = ROOT / 'client/otcv8-dev-master/modules/game_fate/pob'
WIDTH, HEIGHT = 1120, 752
ZOOM = .4
VIEW = (238, 74, 866, 562)
SIZES = {'small': 32, 'notable': 48, 'root': 58, 'gate': 58}
# Ikone i opis wezla podaje generator - te same, ktore dostaje klient.
IDENTITY = runpy.run_path(str(Path(__file__).resolve().parents[2] / 'server/make-fate-identity.py'))
ICON_DEFAULT = 'life'


def point(x, y):
    return VIEW[0] + VIEW[2] / 2 + x * ZOOM, VIEW[1] + VIEW[3] / 2 + y * ZOOM


def intersects(left, top, right, bottom):
    x, y, width, height = VIEW
    return left <= x + width and right >= x and top <= y + height and bottom >= y


def route(by_id, target):
    """Target-outward BFS, matching the native Lua planner's neighbor order."""
    queue, seen, next_id = deque([target]), {target}, {}
    while queue:
        current = queue.popleft()
        for neighbor in by_id[current]['neighbors']:
            if neighbor in seen:
                continue
            seen.add(neighbor)
            next_id[neighbor] = current
            if neighbor == 1000:
                result, current = [], next_id[1000]
                while current is not None:
                    result.append(current)
                    current = next_id.get(current)
                return result
            queue.append(neighbor)
    raise ValueError('Preview target is unreachable')


def asset_definition(path):
    data = path.read_bytes()
    width, height = struct.unpack('>II', data[16:24])
    encoded = base64.b64encode(data).decode('ascii')
    return (f'<symbol id="{path.stem}" viewBox="0 0 {width} {height}">'
            f'<image width="{width}" height="{height}" xlink:href="data:image/png;base64,{encoded}"/>'
            '</symbol>')


def use(asset, x, y, width, height, extra=''):
    return (f'<use xlink:href="#{asset}" x="{x:.3f}" y="{y:.3f}" '
            f'width="{width:.3f}" height="{height:.3f}" {extra}/>')


def label(x, y, text, color='#bfbab0', size=11, extra=''):
    return (f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" {extra}>'
            f'{html.escape(str(text))}</text>')


def button(x, y, width, text, primary=False, enabled=True):
    fill, stroke = ('#454234', '#8e7950') if primary else ('#303331', '#51524b')
    return (f'<g opacity="{1 if enabled else .45}">'
            f'<rect x="{x}" y="{y}" width="{width}" height="23" rx="2" fill="{fill}" stroke="{stroke}"/>'
            + label(x + width / 2, y + 15, text, '#ded7c3', extra='text-anchor="middle"') + '</g>')


def build_svg(nodes, decorations):
    by_id = {node['id']: node for node in nodes}
    target = min((n for n in nodes if n['id'] != 1000),
                 key=lambda n: (n['x'] * 68 - 760) ** 2 + (n['y'] * 62 + 160) ** 2)
    planned_ids = route(by_id, target['id'])
    planned, active = set(planned_ids), set(planned_ids) | {1000}
    cost = sum(by_id[nid]['cost'] for nid in planned)
    summary = {}
    for nid in planned:
        node = by_id[nid]
        for group in ('stats', 'special', 'mods'):
            for key, value in node.get(group, {}).items():
                totals = summary.setdefault(group, Counter())
                totals[key] += value
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}">',
             '<title>Fate — podgląd planera na podstawie danych</title>',
             '<desc>Podgląd z danych, nie zrzut klienta. Rzeczywiste współrzędne, połączenia, koszty i bonusy z server/make-fate-pob.py; niezmienione grafiki z modułu game_fate/pob. Przykładowy plan lokalny, 40% powiększenia.</desc>',
             '<defs>', *(asset_definition(p) for p in sorted(ASSETS.glob('*.png'))),
             f'<clipPath id="viewport"><rect x="{VIEW[0]}" y="{VIEW[1]}" width="{VIEW[2]}" height="{VIEW[3]}"/></clipPath>',
             '<pattern id="background" width="256" height="256" patternUnits="userSpaceOnUse">'
             + use('Background2', 0, 0, 256, 256) + '</pattern>',
             '<filter id="idle"><feColorMatrix type="matrix" values=".44 0 0 0 0  0 .42 0 0 0  0 0 .39 0 0  0 0 0 1 0"/></filter>',
             '<filter id="planned"><feColorMatrix type="matrix" values=".84 0 0 0 0  0 .74 0 0 0  0 0 .51 0 0  0 0 0 1 0"/></filter>',
             '</defs>', '<g font-family="Verdana, DejaVu Sans, sans-serif">',
             '<rect width="1120" height="752" fill="#101313"/>',
             '<rect x="1" y="1" width="1118" height="718" rx="4" fill="#242724" stroke="#6a685c"/>',
             '<path d="M2 27H1118" stroke="#494a40"/>',
             label(560, 19, 'Fate', '#dfdfdf', 12, 'text-anchor="middle"'),
             label(1058, 19, '−   ×', '#d5d2c7', 15),
             '<rect x="16" y="36" width="1088" height="30" fill="#191c1c"/>',
             label(28, 55, 'PASSIVE TREE', '#c1ac80'),
             '<rect x="230" y="39" width="250" height="24" fill="#101414" stroke="#555447"/>',
             label(240, 55, 'Search nodes or bonuses...', '#787d78'),
             label(490, 55, '0 matches', '#9d9b95'), button(585, 39, 52, 'Next'),
             label(1092, 55, '40%', '#c1ac80', extra='text-anchor="end"'),
             '<rect x="16" y="74" width="214" height="598" fill="#161a1b"/>',
             label(28, 100, 'BONUSES', '#cfb77c')]
    # Lewa kolumna to dzis dwie listy: u gory to, co juz kupione, pod separatorem szkic.
    # Liczniki punktow zeszly do stopki, a opis wezla pod kursorem siedzi przy jej dole.
    planned_bonus = {group: dict(totals) for group, totals in summary.items()}
    parts.append(label(28, 124, 'Nothing allocated yet.', '#c7bfa4'))
    parts.append('<path d="M28 146H218" stroke="#494a40"/>')
    parts.append(label(28, 172, 'PLANNED', '#cfb77c'))
    for index, line in enumerate(IDENTITY['describe'](planned_bonus).rstrip('.').split('. ')[:18]):
        parts.append(label(28, 196 + index * 18, line, '#b6acd1'))
    parts.append('<path d="M28 552H218" stroke="#494a40"/>')
    # Klient zawija ten tekst sam (text-wrap), podglad dzieli go recznie.
    for index, text in enumerate(('Hover a node to see its path', 'and cost.', '',
                                  'Click to plan, click again to', 'remove. Points are spent only',
                                  'with Apply points.')):
        parts.append(label(28, 576 + index * 18, text, '#c7c1b4'))
    parts += [f'<g clip-path="url(#viewport)"><rect x="{VIEW[0]}" y="{VIEW[1]}" width="{VIEW[2]}" height="{VIEW[3]}" fill="url(#background)"/>']
    for decoration in decorations:
        x, y = point(decoration['x'], decoration['y'])
        w, h = decoration['size'] * ZOOM, decoration['height'] * ZOOM
        if intersects(x - w / 2, y - h / 2, x + w / 2, y + h / 2):
            asset = 'PSGroupBackground3Full' if decoration['kind'] == 3 else f"PSGroupBackground{decoration['kind']}"
            parts.append(use(asset, x - w / 2, y - h / 2, w, h))
    links_drawn = 0
    for node in nodes:
        for parent, geometry in node['linkPoints'].items():
            points = [point(*p) for p in geometry]
            if not intersects(min(x for x, _ in points), min(y for _, y in points),
                              max(x for x, _ in points), max(y for _, y in points)):
                continue
            first, last = points[0], points[-1]
            arc = node['linkArc'].get(parent)
            if arc:
                r = arc['r'] * ZOOM
                path = (f'M{first[0]:.3f},{first[1]:.3f} A{r:.3f},{r:.3f} 0 '
                        f'{int(abs(arc["sweep"]) > math.pi)},{int(arc["sweep"] > 0)} {last[0]:.3f},{last[1]:.3f}')
            else:
                path = f'M{first[0]:.3f},{first[1]:.3f} L{last[0]:.3f},{last[1]:.3f}'
            selected = node['id'] in active and parent in active
            color = '#dfc17b' if selected else '#443d30'
            parts.append(f'<path d="{path}" fill="none" stroke="{color}" stroke-width="{1.25 if selected else .9}"/>')
            links_drawn += 1
    visible = 0
    for node in nodes:
        x, y = point(node['x'] * 68, node['y'] * 62)
        kind = node.get('visualKind', node['kind'])
        size = max(3, math.floor(SIZES.get(kind, 32) * ZOOM))
        if not intersects(x - size / 2, y - size / 2, x + size / 2, y + size / 2):
            continue
        selected = node['id'] in active
        if kind in ('root', 'gate'):
            asset = 'KeystoneFrameAllocated' if selected else 'KeystoneFrameUnallocated'
        elif kind == 'notable':
            asset = 'NotableFrameAllocated' if selected else 'NotableFrameUnallocated'
        else:
            asset = 'PSSkillFrameActive' if selected else 'PSSkillFrame'
        tint = ' filter="url(#planned)"' if node['id'] in planned else ('' if selected else ' filter="url(#idle)"')
        parts.append('<g><title>' + html.escape(f"{node['name']} · {node['cost']} points · ID {node['id']}") + '</title>')
        parts.append(use(asset, x - size / 2, y - size / 2, size, size, tint))
        if node['kind'] != 'root':
            icon = node.get('icon') or ICON_DEFAULT
            inset = math.floor(size * .24)
            icon_size = size - inset * 2
            parts.append(use('icon-' + icon, x - size / 2 + inset, y - size / 2 + inset,
                             icon_size, icon_size, '' if selected else 'opacity=".59"'))
        parts.append('</g>')
        visible += 1
    parts += ['</g>', button(238, 645, 65, 'Undo'), button(309, 645, 65, 'Redo', enabled=False),
              button(380, 645, 82, 'Clear plan'),
              label(972, 651, 'Ready to apply', '#a8b7b8', extra='text-anchor="end"'),
              button(984, 645, 120, 'Apply points', primary=True),
              label(16, 697, 'Passive points: 30', '#b8ac91'),
              label(150, 697, 'Available points: 30', '#bfbab0'),
              label(295, 697, f'Planned nodes: {len(planned)}', '#bfbab0'),
              label(420, 697, f'Plan cost: {cost}', '#ddc689'),
              button(861, 681, 75, 'Full tree'), button(942, 681, 66, 'Center'),
              button(1014, 681, 90, 'Reset spent', enabled=False),
              label(16, 742, 'Podgląd z danych, nie zrzut klienta', '#a3aba9', 12),
              label(1104, 742, f'{len(nodes)} węzłów · przykładowy plan · zoom 40%', '#798581', 10, 'text-anchor="end"'),
              '</g></svg>']
    return '\n'.join(parts), dict(nodes=len(nodes), visible=visible, links=links_drawn,
                                  planned=len(planned), cost=cost, target=target['id'])


def rasterize(svg_path, png_path):
    """Use installed librsvg/Cairo; no network or extra packages are required."""
    rsvg_name, cairo_name = ctypes.util.find_library('rsvg-2'), ctypes.util.find_library('cairo')
    if not rsvg_name or not cairo_name:
        return False
    rsvg, cairo = ctypes.CDLL(rsvg_name), ctypes.CDLL(cairo_name)
    pointer = ctypes.c_void_p
    rsvg.rsvg_handle_new_from_file.argtypes = [ctypes.c_char_p, pointer]
    rsvg.rsvg_handle_new_from_file.restype = pointer
    rsvg.rsvg_handle_render_cairo.argtypes = [pointer, pointer]
    rsvg.rsvg_handle_render_cairo.restype = ctypes.c_int
    cairo.cairo_image_surface_create.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
    cairo.cairo_image_surface_create.restype = pointer
    cairo.cairo_create.argtypes = [pointer]
    cairo.cairo_create.restype = pointer
    cairo.cairo_surface_write_to_png.argtypes = [pointer, ctypes.c_char_p]
    cairo.cairo_surface_write_to_png.restype = ctypes.c_int
    cairo.cairo_destroy.argtypes = [pointer]
    cairo.cairo_surface_destroy.argtypes = [pointer]
    handle = rsvg.rsvg_handle_new_from_file(os.fsencode(svg_path), None)
    if not handle:
        raise RuntimeError('librsvg could not parse the SVG preview')
    surface = cairo.cairo_image_surface_create(0, WIDTH, HEIGHT)
    context = cairo.cairo_create(surface)
    try:
        if not rsvg.rsvg_handle_render_cairo(handle, context):
            raise RuntimeError('librsvg could not render the SVG preview')
        if cairo.cairo_surface_write_to_png(surface, os.fsencode(png_path)):
            raise RuntimeError('Cairo could not save the PNG preview')
    finally:
        cairo.cairo_destroy(context)
        cairo.cairo_surface_destroy(surface)
        gobject = ctypes.CDLL(ctypes.util.find_library('gobject-2.0'))
        gobject.g_object_unref.argtypes = [pointer]
        gobject.g_object_unref(handle)
    return True


def main():
    os.chdir(ROOT)  # The existing Fate gameplay generator uses root-relative paths.
    geometry = runpy.run_path(str(ROOT / 'server/make-fate-pob.py'))
    svg, summary = build_svg(geometry['build'](), geometry['decorations']())
    path = HERE / 'preview.svg'
    path.write_text(svg)
    png = rasterize(path, HERE / 'preview.png')
    print(f'Wrote {path}; PNG: {png}; {summary}')


if __name__ == '__main__':
    main()
