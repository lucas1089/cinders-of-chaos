# Podgląd planera Fate

**Podgląd z danych, nie zrzut klienta.** `preview.svg` i `preview.png` przedstawiają układ nowego okna przy powiększeniu 40%. Geometria, łuki połączeń, grupy, identyfikatory, koszty i bonusy pochodzą z `server/make-fate-pob.py`. Grafiki są osadzone z plików modułu `game_fate/pob`; SVG nie wymaga dostępu do serwera ani zewnętrznych obrazów.

Pokazany plan jest przykładową najkrótszą ścieżką od korzenia Fate do węzła 3711. Saldo 30 punktów jest wartością demonstracyjną, nie odczytem danych postaci. Podgląd nie uruchamia pliku EXE i nie potwierdza wyglądu renderera Windows; elementy okna są odtworzone według układu OTUI.

Odtworzenie podglądu:

```sh
python3 notes/fate-planner/preview.py
```

Generator zapisuje samodzielny SVG i, jeśli dostępne są biblioteki systemowe librsvg oraz Cairo, również PNG. Nie zmienia plików gry ani jej zasobów graficznych.

Zasoby modułu można odtworzyć z dostarczonego ZIP-a poleceniem `python3 client/make-fate-pob-assets.py /ścieżka/PathOfBuilding-dev.zip`. Ramki i tło pochodzą z archiwum, a dziewięć ikon statystyk wycięto według oryginalnych współrzędnych sprite’ów i przeskalowano do 64 × 64, zachowując ten sam rysunek. Taki rozmiar pozwala natywnemu rendererowi OTCv8 korzystać z cache także przy przybliżaniu. `PSGroupBackground3Full` odtwarza dwie lustrzane połówki rysowane przez PoB.
